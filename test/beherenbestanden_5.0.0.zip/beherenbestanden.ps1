﻿<# 
Beherenbestanden.ps1
Programma om bestanden op pc's in een netwerk te beheren, dus bestanden klaarzetten, back-uppen, verplaatsen of wissen
Zie voor versienummer hier onder de comments.
Versienummer wordt volgens Semantic Versioning uitgevoerd (zie https://semver.org/lang/nl/)
Dit programma is beschermt met auteursplicht door middel van de GNU GPL (https://www.gnu.org/licenses)
Lees ook de README.md en LICENSE op https://github.com/examencentrumtcr/beherenbestanden 
Auteur: Benvindo Neves
#>

# Hier worden de programma variabelen gedeclareerd.

<# $global:programma is een object met alle variabelen die het programma beschrijven. 
   versie wordt aangepast als er een nieuwe versie is.
   extralabel wordt aangepast (de datum) als het programma is gewijzigd. 
   mode wordt aangepast afhankelijk van wat je wil testen of als er een nieuwe versie is.
   naam is de naam van het script. Deze wordt gebruikt in de titelbalk van het hoofdvenster.
   github is de locatie waar de updates vandaan gehaald worden. Dit is altijd hetzelfde.
   icoon is de naam van het gebruikte icoon in de titelbalk bij alle vensters.

   Mode kan de volgende waarden hebben:
    alpha      : Logbestanden verwijderen is uit, Automatisch updates is uit, Lokale mappen worden gebruikt en Console blijft open
    beta       : Automatisch updates is uit en Console blijft open
    rc         : Updates worden gedownload vanuit de prerelease pagina van Github. Dit is een release candidate dus alles moet getest worden.
    release    : Normale gebruik

    De modus hoeven niet persé allemaal doorlopen te worden!
    Bij het opstarten krijg je een melding als je in de fase alpha, beta of rc zit.

#>
# startmap van het programma bepalen
$startmap=Split-Path -Parent $PSCommandPath

# map met png icoontjes bepalen
$icoontjesmap = -join ("$startmap","\","png")

# map met gif afbeeldingen bepalen
$gifjesmap = -join ("$startmap","\","png")

# map voor logbestanden bepalen
$logmap = -join ("$startmap","\","log")

$global:programma = @{
    versie = '5.0.0'
    extralabel = '189.261027.sharepoint' # buildnummer + datum + eventuele branch
    mode = 'beta' # alpha, beta, rc of release. Afhankelijk van welke fase je zit of wat je wil testen.
    naam = 'Beherenbestanden'
    github = "https://api.github.com/repos/examencentrumtcr/beherenbestanden/contents/"
    icoon = -join ($icoontjesmap, "\", "script_icoon.ico")
}

$scriptnaam = $global:programma.naam
write-host ""
write-host "** Programma $scriptnaam " -f Green
write-host "** Versie is "$global:programma.versie -f Green
write-host "** Werkt met PowerShell versie "$PSVersionTable.PSVersion -f Green
write-host ""
write-host "Initialiseren van het programma."


<# Manier om console af te sluiten en weer te openen.
   Het sluiten wordt uitgevoerd voor het starten van de hoofdscherm.
#>
$code = '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);'
$ShowWindowAsync = Add-Type -MemberDefinition $code -Name myAPI -PassThru
$hwnd = (Get-Process -PID $pid).MainWindowHandle

# toevoegen .NET framework klassen ---------------------------------------------------------
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

# VisualStyles aan zetten ------------------------------------------------------------------
[System.Windows.Forms.Application]::EnableVisualStyles()

# Comparator Class toevoegen voor sorteren van listview. Zie functie SortListView.
Add-Type -ReferencedAssemblies @(
    'System.Windows.Forms',
    'System'
) -TypeDefinition @"
using System;
using System.Collections;
using System.Globalization;
using System.Windows.Forms;

public class ListViewItemComparer : IComparer
{
    private int col;
    private SortOrder order;

    public ListViewItemComparer(int column, SortOrder sortOrder)
    {
        col = column;
        order = sortOrder;
    }

    public int Compare(object x, object y)
    {
        ListViewItem itemX = (ListViewItem)x;
        ListViewItem itemY = (ListViewItem)y;

        string a = itemX.SubItems[col].Text;
        string b = itemY.SubItems[col].Text;

        int result = 0;

        // Kolom 1 = datum
        if (col == 1)
        {
            DateTime da, db;
            if (DateTime.TryParse(a, out da) && DateTime.TryParse(b, out db))
                result = DateTime.Compare(da, db);
            else
                result = String.Compare(a, b, true);
        }

        // Kolom 2 = grootte
        else if (col == 2)
        {
            long sa = ParseSize(a);
            long sb = ParseSize(b);
            result = sa.CompareTo(sb);
        }

        // Overige kolommen = tekst
        else
        {
            result = String.Compare(a, b, true);
        }

        if (order == SortOrder.Descending)
            result = -result;

        return result;
    }

    private long ParseSize(string text)
    {
        if (String.IsNullOrWhiteSpace(text))
            return -1; // lege grootte (mappen)

        text = text.Replace("kB", "").Replace("KB", "").Trim();

        double value;
        if (Double.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out value))
            return (long)(value * 1024);

        return 0;
    }
}
"@

# tijdelijke logbestand voor foutmeldingen
$foutmeldingsbestand = -join ("$logmap","\","Foutmeldingen.txt")

<# object met alle variabelen die in initialisatiebestand bewaard worden. Dit zijn de instellingen die gewijzigd kunnen worden.
   Zie ook functie gebruikersinstellingen onder sectie "Functions" #>
$Global:init=@{}

# de 3 bestanden met info voor venster informatieprogramma
$readmebestand="readme.md"
$changelogbestand="changelog.md"
$licensebestand="license"

# nodig voor werken met hashtabels. zie functies uitvoerentaken en overzichttaken
$uitvoeren = [hashtable]::Synchronized(@{})

# nodig voor informatie baloon 
$global:tooltip1 = New-Object System.Windows.Forms.ToolTip

# Afbeeldingen voor het hoofdmenu
$global:afbeeldingen = @(
    [PSCustomObject]@{
        naam = 'Automatiseren'
        bestand = 'automatiseren.gif'
    },
    [PSCustomObject]@{
        naam = 'Beoordelen'
        bestand = 'beoordelen.gif'
    },
    [PSCustomObject]@{
        naam = 'Controleren'
        bestand = 'controleren.gif'
    },
    [PSCustomObject]@{
        naam = 'Overwerken'
        bestand = 'overwerken.gif'
    },
    [PSCustomObject]@{
        naam = 'Archieveren'
        bestand = 'overzetten.gif'
    },
    [PSCustomObject]@{
        naam = 'Samenwerken'
        bestand = 'samenwerken.gif'
    },
    [PSCustomObject]@{
        naam = 'Thuiswerken'
        bestand = 'thuiswerken.gif'
    }
)

# Websites met moppen
$Global:Moppen = @(
    [PSCustomObject]@{
        naam = 'Appspot.com'
        url = 'https://official-joke-api.appspot.com/jokes/random'
        taal = 'Engels'
    },
    [PSCustomObject]@{
        naam = 'Apekool.nl'
        url = 'http://api.apekool.nl/services/jokes/getjoke.php' 
        taal = 'Nederlands'
    },
    [PSCustomObject]@{
        naam = 'Icanhazdadjoke.com'
        url = 'http://icanhazdadjoke.com/' 
        taal = 'Engels'
    }
)

# Beheerinstellingen. Dit zijn de instellingen die niet gewijzigd kunnen worden.
# Locaties worden hier gedefinieerd. Deze worden gebruikt bij het aanmaken van de lijst met rpc-nummers.
$PAL = @{
    naam = 'Prins Alexanderlaan'
    eerstenr = 1
    laatstenr= 60
}
$SHW = @{
    naam = 'Schiedamseweg'
    eerstenr = 131
    laatstenr= 180
}
$JLS = @{
    naam = 'Jan Ligthartstraat'
    eerstenr = 201
    laatstenr= 240
}
$locaties = @{
    PAL = $PAL
    SHW = $SHW
    JLS = $JLS
    }
$examenmappen = @{
    digitalebestanden = '/gedeelde documenten/Examendocumenten'
    homemapstudenten  = 'Y:\RPC'
    backupmap         = '/gedeelde documenten/Backup kandidaten'
}

$global:beheer = @{
    examenmappen      = $examenmappen
    locaties          = $locaties
    opschonen         = $opschonen
    dagenbewarenbackup = 730
    }

# lokale mappen worden gebruikt als programma.mode is alpha.
$lokalemappen = @{
    digitalebestanden = "/gedeelde documenten/Examendocumenten"
    homemapstudenten  = "C:\Users\$env:username\testwerking\doel"
    backupmap         = "/gedeelde documenten/Backup kandidaten"
}
if ($global:programma.mode -eq "alpha") {
        $global:beheer.examenmappen = $lokalemappen
        }
# Mappen in Sharepoint van team RPCPAL_55-TestRPC. Deze worden gebruikt bij het inlezen van bestanden uit Sharepoint.
$global:Sharepoint = @{
    Organisatie = "https://o365zadkine.sharepoint.com"
    Team        = "/teams/RPCtestsiteexaminering"
}
# Url kan pas worden gedefinieerd nadat de andere variabelen zijn gedefinieerd. Anders krijg je een foutmelding dat $global:Sharepoint.Team nog niet bestaat.
$global:Sharepoint.Url = -join(
    $global:Sharepoint.Organisatie,
    $global:Sharepoint.Team
)

# variabelen voor Sharepoint client id en app id. Deze zijn nodig voor het inlezen van bestanden uit Sharepoint. 
$env:ENTRAID_CLIENT_ID = "db02e749-4ffc-4ba4-aa01-3691640f308b"
$env:ENTRAID_APP_ID = "db02e749-4ffc-4ba4-aa01-3691640f308b"

# Lijst met bestandsformaten die worden herkend als afbeelding. Deze worden gebruikt bij functies Bestanden kopieren en Verkenner.
$global:bestandsformaten = @(
    [PSCustomObject]@{
        naam = 'Explorer'
        icoon = 'explorer-icoon.png'
        typen = @('folder')
       },
    [PSCustomObject]@{
        naam = 'Tekst'
        icoon = 'file-icoon.png'
        typen = @('txt', 'log', 'ini', 'json', 'md')
    },
    [PSCustomObject]@{
        naam = 'Word'
        icoon = 'file-icoon-word.png'
        typen = @('doc', 'docx')
    },
    [PSCustomObject]@{
        naam = 'Excel'
        icoon = 'file-icoon-excel.png'
        typen = @('xls', 'xlsx')
    },
    [PSCustomObject]@{
        naam = 'PDF'
        icoon = 'file-icoon-pdf.png'
        typen = @('pdf')
    },
    [PSCustomObject]@{
        naam = 'Visio'
        icoon = 'file-icoon-visio.png'
        typen = @('vsd', 'vss', 'vst', 'vsdx', 'vssx', 'vstx')
    },
    [PSCustomObject]@{
        naam = 'Afbeeldingen'
        icoon = 'file-icoon-afbeelding.png'
        typen = @('png', 'jpg', 'jpeg', 'bmp', 'gif')
    },
    [PSCustomObject]@{
        naam = 'Uitvoerbaar'
        icoon = 'file-icoon-exe.png'
        typen = @('exe', 'msi')
    },
    [PSCustomObject]@{
        naam = 'Snelkoppelingen'
        icoon = 'file-icoon-link.png'
        typen = @('lnk', 'url')
    },
    [PSCustomObject]@{
        naam = 'Muziek'
        icoon = 'file-icoon-muziek.png'
        typen = @('mp3', 'wav', 'flac', 'aac', 'wma')
    },
    [PSCustomObject]@{
        naam = 'Packettracert'
        icoon = 'file-icoon-pka.png'
        typen = @('pka','pkt')
    },
    [PSCustomObject]@{
        naam = 'Sjablonen'
        icoon = 'file-icoon-sjabloon.png'
        typen = @('dotx')
    },
    [PSCustomObject]@{
        naam = 'Video'
        icoon = 'file-icoon-video.png'
        typen = @('mp4', 'avi', 'mkv', 'mov', 'wmv', 'flv', 'mpeg', 'mpg')
    },
    [PSCustomObject]@{
        naam = 'Gecomprimeerd'
        icoon = 'file-icoon-zip.png'
        typen = @('zip', 'rar', '7z')
    },
    [PSCustomObject]@{
        naam = 'PowerPoint'
        icoon = 'file-icoon-powerpoint.png'
        typen = @('ppt', 'pptx')
    },
    [PSCustomObject]@{
        naam = 'Websites'
        icoon = 'file-icoon-website.png'
        typen = @('php', 'html', 'htm', 'css', 'xml', 'asp', 'aspx', 'jsp', 'xps')
    },
    [PSCustomObject]@{
        naam = 'scripts'
        icoon = 'file-icoon-programmeren.png'
        typen = @('ps1', 'psm1', 'py', 'js', 'vbs', 'bat', 'cmd')
    },
    [PSCustomObject]@{
        naam = 'databases'
        icoon = 'file-icoon-database.png'
        typen = @('sql', 'db', 'mdb', 'accdb')
    }

)

# Einde declareren variabelen


# functions ---------------------------------------------------------------------------------
# hieronder de kleine functies die door andere functies gebruikt worden ---------------------

function Toonofverbergconsole($mode) {
  
  if ($hwnd -ne [System.IntPtr]::Zero) {
    # When you got HWND of the console window:
    # (It would appear that Windows Console Host is the default terminal application)
    $null = $ShowWindowAsync::ShowWindowAsync($hwnd, $mode)
  } else {
    # When you failed to get HWND of the console window:
    # (It would appear that Windows Terminal is the default terminal application)

    # Mark the current console window with a unique string.
    # $UniqueWindowTitle = New-Guid
    $UniqueWindowTitle = [guid]::NewGuid().ToString()
    $Host.UI.RawUI.WindowTitle = $UniqueWindowTitle
    # $StringBuilder = New-Object System.Text.StringBuilder 1024

    # Search the process that has the window title generated above.
    $TerminalProcess = (Get-Process | Where-Object { $_.MainWindowTitle -eq $UniqueWindowTitle })
    # Get the window handle of the terminal process.
    # Note that GetConsoleWindow() in Win32 API returns the HWND of
    # powershell.exe itself rather than the terminal process.
    # When you call ShowWindowAsync(HWND, 0) with the HWND from GetConsoleWindow(),
    # the Windows Terminal window will be just minimized rather than hidden.
    $hwnd = $TerminalProcess.MainWindowHandle
    if ($hwnd -ne [System.IntPtr]::Zero) {
      # afsluiten terminal. Met $null zie je ook geen resultaat op he scherm. dus het woord "true" verschijnt niet.  
      $null = $ShowWindowAsync::ShowWindowAsync($hwnd, $mode) 
      
    } else {
      Write-Host "Niet gelukt om de status van de console window te wijzigen naar waarde $mode." -ForegroundColor Red
    }
  }
} # einde Toonofverbergconsole

Function declareren_standaardvenster ($titel, $pos_x, $pos_y)
{
$StandaardForm                            = New-Object system.Windows.Forms.Form
$StandaardForm.MaximumSize = New-Object System.Drawing.size($pos_x,$pos_y)
$StandaardForm.MinimumSize = New-Object System.Drawing.size($pos_x,$pos_y)
$StandaardForm.text                       = $titel
$StandaardForm.TopMost                    = $false
$StandaardForm.StartPosition              = 'CenterScreen'
$StandaardForm.BackColor = "white"
$StandaardForm.MaximizeBox = $False
$StandaardForm.Icon                       = [System.Drawing.Icon]::ExtractAssociatedIcon($global:programma.icoon)

return $StandaardForm
}

function bepaallognaam ($invoer) {
<# de lognaam wordt bepaald adhv de invoer. dit is een datum in de format yyyy-mm-dd. Zie ook function Bepaaldatum.
   functie "bepaaldatumuitlognaam" doet het omgekeerde, dus een verandering hier moet ook in deze functie worden aangepast.
#>

# haal de personeelnr uit de beheervariabele $env:username
$personeelsnr = $env:username

$jaar = $invoer.substring(6, 4)
$maand = $invoer.substring(3, 2)
$dag = $invoer.substring(0, 2)
$datumintekst = -join ($jaar,'-',$maand,'-',$dag)
$lognaam = -join ("$logmap","\log_","$datumintekst",'_',$personeelsnr,".txt")

return $lognaam
}

Function bepaaleigenlogbestanden
{
$personeelsnr = $env:username

$uitvoer = "$logmap\*$personeelsnr.txt"

return $uitvoer
}


Function Logbestandtoevoegen ($logbestand) 
{
# tijdelijke log toevoegen aan eigen logbestand als deze al bestaat. bestand hernoemen wordt altijd gedaan.

# datum bepalen
$datumvandaag = bepaaldatum;

$logvanvandaag = bepaallognaam $datumvandaag
if (test-path -path $logvanvandaag -pathtype leaf) { 
    $inhoudlog = Get-Content -path $logvanvandaag
    Add-Content -Path $logbestand -Value $inhoudlog
    Remove-Item $logvanvandaag
}
# dit wordt altijd gedaan.....    
Rename-Item -Path $logbestand -NewName $logvanvandaag

}

function Meldingnaarlogbestand {
param (
    [Parameter(Mandatory = $true)] [string]$meldtekst, # de melding die gelogd moet worden
    [string]$type = "FOUTMELDING" # type melding. Standaard is dit "FOUTMELDING" maar je kan ook "INFORMATIE" of "MEDEDELING" meegeven.
)
# map aanmaken voor logbestanden als deze niet bestaat
if (!(Test-Path "$logmap")) { New-Item -Path "$logmap" -ItemType Directory | Out-Null  } 

# starttijd van loggen naar variabele
$logtijd = get-date -Format "HH:mm:ss"

# loggen. $foutmeldingsbestand is in het begin gedefinieerd.
"$type" | out-file $foutmeldingsbestand -Append
"Tijd : $logtijd " | out-file $foutmeldingsbestand -Append
"$meldtekst" | out-file $foutmeldingsbestand -Append

"-------------------------------------------------------------------------
" | out-file $foutmeldingsbestand -Append

Logbestandtoevoegen $foutmeldingsbestand
}

function bepaaldatum {
# datum bepalen
$datumvandaag = get-date -Format "dd-MM-yyyy"
return $datumvandaag
}

function bepaaltijd {

# huidige tijd bepalen
$huidigetijd = get-date -Format "HH:mm:ss"
return $huidigetijd
}


function declareren_rpcnrs {

# Venster voor weergeven rpcnummer declareren. Wordt bij meerdere functies gebruikt.

$listbox_temp = New-Object System.Windows.Forms.Listbox
$listbox_temp.Location = New-Object System.Drawing.Point(10,40)
$listbox_temp.Size = New-Object System.Drawing.Size(150,20)
$listbox_temp.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$listbox_temp.SelectionMode = 'MultiExtended'
$listbox_temp.Height = 500

return $listbox_temp
}

function lijstrpcnrsaanmaken ($keuzelocatie, $listbox_temp) {
# een lijst met rpc-nummers wordt gemaakt adhv gekozen locatie

# lijst wordt leeggemaakt
$listbox_temp.Items.Clear()

# waarden uit array halen die nodig zijn om lijst te maken met rpc-nummers
[int]$keuzeeerstenr=$Global:beheer.locaties.$keuzelocatie.eerstenr
[int]$keuzelaatstenr=$Global:beheer.locaties.$keuzelocatie.laatstenr

#listbox items aanmaken
For ($i=$keuzeeerstenr; $i -le $keuzelaatstenr; $i++) {

    if ($i -lt 10) {$rpcnr="RPC-00"+"$i"}
    elseif ($i -lt 100) {$rpcnr="RPC-0"+"$i"}
    else {$rpcnr="RPC-"+"$i"}
    [void] $listbox_temp.Items.Add($rpcnr)
}

return $listbox_temp
}

function Add-EscapeClose {
    param(
        [System.Windows.Forms.Form]$FormEscapeClose
    )

    $FormEscapeClose.KeyPreview = $true

    $FormEscapeClose.Add_KeyDown({
        param($sendervar, $e)

        if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
            $sendervar.Close()
        }
    })
} # einde Add-EscapeClose

function venstermetvraag {

param (
    [Parameter(Mandatory = $true)] [string]$titel,
    [Parameter(Mandatory = $true)] [string]$vraag,
    [string]$knopok = "Ok",
    [string]$knopterug = "geen",
    [switch]$schuifbalk,
    [switch]$bredevenster
)


# venster declareren
if ($bredevenster) { 
    $formvraag = declareren_standaardvenster $titel 800 300
} else {
    $formvraag = declareren_standaardvenster $titel 600 200
}

$objtekst2 = New-Object System.Windows.Forms.textbox
$objtekst2.Location = New-Object System.Drawing.Size(50,5) 

$objtekst2.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$objtekst2.Text = $vraag
$objtekst2.BorderStyle = 'None' # geen lijnen zichtbaar
$objtekst2.BackColor  = 'white'
$objtekst2.Forecolor  = 'blue'
$objtekst2.TabStop = $false  # tekst wordt niet geselecteerd in het begin. is dus niet blauw.
$objtekst2.ReadOnly = $true # je kan niet in het venster typen
$objtekst2.Multiline = $true # meerdere regels kan je weergeven

# Schuifbalk alleen aangeven als je de switchh ebt toegevoegd ah eind van de functie aanroep.
if ($schuifbalk) { 
    $objtekst2.ScrollBars = "Vertical"
    # $objtekst2.ScrollBars = "Both" 
    } 
if ($bredevenster) { 
    $objtekst2.Size = New-Object System.Drawing.Size(730,210)
    } else {
    $objtekst2.Size = New-Object System.Drawing.Size(530,110)
    }

$formvraag.Controls.Add($objtekst2)

# knop ok wordt altijd weergegeven. knop annuleren alleen als een 2e knop-naam gegeven is.
$vraagok = New-object System.Windows.Forms.Button 
$vraagok.text= $knopok
if ($bredevenster) { 
    $vraagok.location = New-Object System.Drawing.Point(50,220)
} else {
    $vraagok.location = New-Object System.Drawing.Point(50,120)
}
$vraagok.size = "150,30"  
if ($vraagok.text -eq "Ok") { $vraagok.BackColor = 'blue' }
   else { $vraagok.BackColor = 'green' }
$vraagok.ForeColor = 'white'
$vraagok.DialogResult = [System.Windows.Forms.DialogResult]::ok
$formvraag.Controls.Add($vraagok)


if (!($knopterug -eq "geen") ) { 
$vraagescape = New-object System.Windows.Forms.Button 
$vraagescape.text= $knopterug
# $vraagescape.location = "250,220" 
if ($bredevenster) { 
    $vraagescape.location = New-Object System.Drawing.Point(250,220)
} else {
    $vraagescape.location = New-Object System.Drawing.Point(250,120)
}
$vraagescape.size = "150,30"  
$vraagescape.BackColor = 'red'
$vraagescape.ForeColor = 'white'
$vraagescape.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$formvraag.Controls.Add($vraagescape)
}

# Bij Escape-toets het venster sluiten.
Add-EscapeClose -Form $formvraag

$result = $formvraag.ShowDialog()
    
$formvraag.close();

return $result

} # einde venstermetvraag

Function declareren_uitlegvenster ($titel, $size_x, $size_y, $icoon_x, $icoon_y, $tekst) {
<# 
Hiermee kan je mbv een vraagteken in een venster extra uitleg geven.
variabele titel wordt als titel weergegeven.
variabele size_x en size_y geven de grootte vh venster op.
variabele icoon_x en icoon_y de positie van de vraagteken.
variabele tekst is de weer te geven informatietekst.
#>

# benodigde venster declareren
$Global:Form_uitleg_taak                    = New-Object system.Windows.Forms.Form
$Global:Form_uitleg_taak.StartPosition      = 'CenterScreen'
$Global:Form_uitleg_taak.BackColor          = "white"
$Global:Form_uitleg_taak.TopMost            = $true
$Global:Form_uitleg_taak.MaximumSize        = New-Object System.Drawing.size($size_x,$size_y)
$Global:Form_uitleg_taak.MinimumSize        = New-Object System.Drawing.size($size_x,$size_y)
$Global:Form_uitleg_taak.text               = $titel
$Global:Form_uitleg_taak.ControlBox         = $False
$Global:Form_uitleg_taak.Icon               = [System.Drawing.Icon]::ExtractAssociatedIcon($global:programma.icoon)

[int]$tekst_x = $size_x -10
[int]$tekst_y = $size_y -85

$Global:uitlegtaaktekst                     = New-Object system.Windows.Forms.Label
$Global:uitlegtaaktekst.AutoSize            = $false
$Global:uitlegtaaktekst.location            = New-Object System.Drawing.Point(10,10)
$Global:uitlegtaaktekst.Font                = 'Microsoft Sans Serif,11'
$Global:uitlegtaaktekst.ForeColor = [System.Drawing.Color]::blue
$Global:uitlegtaaktekst.text                = $tekst
$Global:uitlegtaaktekst.width               = $tekst_x
$Global:uitlegtaaktekst.height              = $tekst_y

$Global:Form_uitleg_taak.Controls.Add($Global:uitlegtaaktekst)

[int]$knop_x = 250
[int]$knop_y = $size_y -75

$knopsluiten = New-object System.Windows.Forms.Button 
$knopsluiten.text= 'Sluiten'
$knopsluiten.location = New-Object System.Drawing.size($knop_x,$knop_y)
$knopsluiten.size = "150,30"  
$knopsluiten.BackColor = 'red'
$knopsluiten.ForeColor = 'white'
$knopsluiten.DialogResult = [System.Windows.Forms.DialogResult]::ok

$Global:Form_uitleg_taak.Controls.Add($knopsluiten)

# Bij Escape-toets het venster sluiten.
Add-EscapeClose -Form $Global:Form_uitleg_taak 

# vraagteken weergeven om extra info te geven.
$Global:vraagtekenicoon                     = new-object Windows.Forms.PictureBox
$Global:vraagtekenicoon.Location            = New-Object System.Drawing.Size($icoon_x, $icoon_y)
$Global:vraagtekenicoon.Size                = New-Object System.Drawing.Size(30,60)
$Global:vraagtekenicoon.Image               = [System.Drawing.Image]::FromFile("$icoontjesmap\icoon-hulp.png")
$Global:vraagtekenicoon.add_click( { $Global:Form_uitleg_taak.showdialog() } )
$Global:vraagtekenicoon.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Klik hier voor uitleg over de taak." )
})
# $Global:vraagtekenicoon.add_MouseLeave( { $Global:Form_uitleg_taak.hide() } )

} # einde declareren_uitlegvenster

function bepaalinitnaamgebruiker {

# bepalen van de initialisatienaam van een bestand met gebruikersinstellingen

# invoer is altijd de gebruiker van de pc
# mocht dit veranderen dan hoeft alleen de volgende regel verwijderd te worden en
# ($invoer) te worden toegevoegd aan het begin van de function.
$invoer = $env:username
 
# bestandsnaam wordt bv. gebruiker0101234.ini
$uitvoer = -join ("$startmap","\gebruiker_",$invoer,".ini")

return $uitvoer
}

function gebruikersinstellingen {
# hier worden de standaardinstellingen gedeclareerd die gebruikers kunnen wijzigen

$algemeen=@{
    locatiekeuze = 'PAL'
    wissennabackup = 'Ja'
    gebruiker = ''
    afbeelding = 'Samenwerken'
    consolesluiten = 'Ja'
    controlevoorklaarzetten = 'Ja'
    websitemoppen = 'Apekool.nl'
    nieuwelayout =  'Ja'
    voortgangweergeven = 'Ja'
}
$opschonen=@{
    dagenbewarenlogs = 365
    opschonenlogs = 'Ja'
}
$uitvoerennaopstarten=@{
    updateinfo = 'Ja'
    controleopupdate = 'Ja'
    handmatigupdate = 'Nee'
    PS7snelkoppeling = 'Ja'
}
$Std_inst=@{
    algemeen  = $algemeen
    opschonen = $opschonen
    uitvoerennaopstarten = $uitvoerennaopstarten
}

return $Std_inst
}


Function Inlezengebruikersinstellingen {

# Bepalen van de persoonlijke initialisatiebestand.
$gebruikersbestand = bepaalinitnaamgebruiker

# standaard instellingen bepalen voor object $init
$global:init = gebruikersinstellingen

# inlezen initialisatiebestand als deze bestaat en toevoegen of verwijderen waarden van $init
# dit is nodig zodat, als de initialisatiebestand wordt ingelezen, eventuele nieuwe variabelen worden behouden en verwijderde variabelen niet worden toegevoegd. 
if (test-path -path $gebruikersbestand -pathtype leaf) { 
    # inlezen van object als hashwaarden. hier staan de gewijzigde waarden in die je wil behouden.
    $myObject = Get-Content -Path $gebruikersbestand | ConvertFrom-Json

    # waarden overzetten naar $init. nieuwe waarden worden behouden. verwijderde waarden worden niet toegevoegd.
    foreach( $property in $myobject.psobject.properties.name ) {
        foreach( $subproperty in $myobject.$property.psobject.properties.name )
        {
        # alleen toevoegen als deze bij 'init' al bestaat
        if ( $null -ne $global:init.$property.$subproperty) { 
            $global:init[$property][$subproperty] = $myObject.$property.$subproperty 
            }
        } # einde foreach $subproperty - loop 
        } # einde foreach $property - loop    

    # gekozen is om dit altijd te bewaren zodat je lijst met variabelen up to date is.
    # $global:init | ConvertTo-Json -depth 1 | Set-Content -Path $gebruikersbestand
    Bewareninstellingen
    } 

} # einde Inlezengebruikersinstellingen

Function Netwerkmapaanwezig {

<# Controleren of de netwerkmap aanwezig is en indien nodig herstellen
   Een netwerkmap moet altijd gegeven worden.
   De switch Geenmelding geef je als je geen melding met een venster wilt zien. Het programma loopt dan gewoon door.
   Deze switch wordt nog nergens gebruikt maar blijft aanwezig voor eventule wijzigign in de toekomst.
   De Write-Host regels zie je alleen in een testfase of bij start script, als de console open is
#>
param (
    [Parameter(Mandatory = $true)] [string]$netwerkmap,
    [switch]$geenmelding
)
$gevonden = $false

try {
    if (!(Test-Path -Path $netwerkmap -ErrorAction SilentlyContinue)) {
        
        # met mode alpha worden de lokale mappen gebruikt en onderstaande geldt alleen voor netwerkmappen
        if ($global:programma.mode -ne "alpha") {

        # bepaal de schijf letter
        $schijf = $netwerkmap.substring(0, 2)
        # controleren of schijf aanwezig is.
        $item = Get-SmbMapping | Where-Object -property LocalPath -Value $schijf -EQ
        if ($item) {
            # controleren of schijf ook verbonden is en anders herstellen
            if ($item.Status -eq 'Unavailable') {
                Write-Host "Herstellen van netwerkschijf " $item.LocalPath " naar " $item.RemotePath
                net use $item.LocalPath $item.RemotePath
                # net use $item.LocalPath $item.RemotePath >$null 2>&1

                # controleren of map aanwezig is na herstel.
                if (Test-Path -Path $netwerkmap -ErrorAction SilentlyContinue) { $gevonden = $true } 
            }
        } # einde if ($item)

        }  # einde if ($global:programma.mode -eq "alpha") 

    } else {
        $gevonden = $true 
    } # einde 1e controle netwerkmap
}
catch {
    $melding= $($_.Exception.Message)
    $gevonden = $false
}

if (!($gevonden)) {
    $melding = -join ("Er is geen verbinding met de netwerkschijf ", "`r`n", $netwerkmap)
    # melding wordt altijd gelogd. Dit kan eventueel met het toevoegen van een switch worden uitgezet.
    Meldingnaarlogbestand -meldtekst $melding
    if ($geenmelding) {
        Write-Host -f Red $melding
    } else {
        $vraagdoorgaan = -join ($melding, "`r`n", "Controleer of de netwerkschijf aanwezig is.", "`r`n", "De taak kan nu niet opgestart worden.")
        $null=venstermetvraag -titel "Geen verbinding met netwerkschijf" -vraag $vraagdoorgaan -schuifbalk
    }
} # einde if (!($gevonden))


return $gevonden
} # einde Netwerkmapaanwezig

Function declarerenlijstlocaties ($keuzelocatienr, $wijd, $loc_x, $loc_y) {

# De lijst met locaties aanmaken met de gegeven waarden. De meeste waarden zijn bij alle functies gelijk.

$lijstlocaties                     = New-Object system.Windows.Forms.ComboBox
$lijstlocaties.text                = "Locatie"
$lijstlocaties.width               = $wijd
$lijstlocaties.autosize            = $true
$lijstlocaties.Location = New-Object System.Drawing.Size($loc_x,$loc_y) 
$lijstlocaties.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$lijstlocaties.DropDownStyle="DropDownList"
$lijstlocaties.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer de locatie." )
})

# locaties toevoegen aan lijst
$teller=0

foreach( $property in $global:beheer.locaties.keys ) {

    $waarde  = $global:beheer.locaties.$property.naam
    [void] $lijstlocaties.Items.Add("$property - $waarde")

    # standaard keuzelocatie selecteren en in index van lijst zetten
    if ($property -eq "$keuzelocatienr") { $lijstlocaties.Selectedindex = $teller }
    $teller++
    }

return $lijstlocaties
}

Function Declareericoontjes {

# Op een plek de icoontjes die de bestanden weergeven declareren.
# nodig bij Functies Kopieren en Verkenner

$std_imageList = new-Object System.Windows.Forms.ImageList 
$std_imageList.ImageSize = New-Object System.Drawing.Size(30,30) 

# uitlezen bestandsformaten en bijbehorende icoontjes uit de array $global:bestandsformaten. 
$global:bestandsformaten | ForEach-Object {
    $naam = $_.naam
    $icoon = $_.icoon
    $bitm = [System.Drawing.Image]::FromFile("$icoontjesmap\$icoon")
    $std_imageList.Images.Add($naam, $bitm)
}

return $std_imageList
}

Function Bepaalextensienr ($bestand) {

# Bepaal welke extensie moet worden weergeven afhankelijk van type, map of bestand.
# De nummering is afhankelijk van de volgorde van aanmaken bij functie Declareericoont
$positiepunt = $bestand.LastIndexOf(".")
    $positiepunt += 1
    $extensie = $bestand.Substring($positiepunt)

    # Standaard krijgt elk bestand icoontje 1, maar afhankelijk van de extensie krijgt het een ander nummer. 
    # De nummering is afhankelijk van de volgorde van aanmaken bij functie Declareericoontjes. zie hierboven.
    $teller = 0
    foreach ($formaat in $global:bestandsformaten) {
        $formats = $formaat.typen
        if ($formats.Contains($extensie)) {
            return $teller
        }
        $teller += 1
    } # einde foreach-loop
return 1
}

Function Bepaalicoontjenr ($controlemap, $bestand) {

# Bepaal welke icoontje moet worden weergeven afhankelijk van type, map of bestand. 
# Wordt gebruikt bij functies Bestanden kopieren en Verkenner. Straks alleen bij Verkenner dus kan de functie verplaatst worden.....
# De nummering is afhankelijk van de volgorde van aanmaken bij functie Declareericoontjes. 
# een map heeft als nummer 0. Deze is als eerst gedeclareerd. zie functie Declareericoontjes.
# Deze functie bestaat alleen omdat bij Verkenner nog wel naar een netwerkmap wordt gekeken en dus test-path wordt gebruikt. 
# Als dit niet meer nodig is kan deze functie verwijderd worden en de functie Bepaalextensienr gebruikt worden.
# Bij Bestanden kopieren wordt naar een sharepointmap gekeken en kan de functie Bepaalextensienr worden gebruikt.

if (( test-path -path "$controlemap\$bestand" -pathtype container) -eq $true)  {
    $gevondennr = 0
    } else {
    $gevondennr = Bepaalextensienr $bestand
    }

return $gevondennr
}

Function Bewareninstellingen {
# hier worden de instellingen bewaard in een ini-bestand. dit bestand wordt ingelezen bij het opstarten van het script.

# Bepalen van de persoonlijke initialisatiebestand.
$gebruikersbestand = bepaalinitnaamgebruiker
$global:init | ConvertTo-Json -depth 1 | Set-Content -Path $gebruikersbestand
}

 function subtakenverbergen {
        # subtaken zijn de knoppen 5 t/m 13 

        # subtaken verbergen
        $Button8.visible = $false
        $Button9.visible = $false
        $Button10.visible = $false
        $Button6.visible = $false
        $Button5.visible = $false
        $Button11.visible = $false
        $Button1.visible = $true
        $Button2.visible = $true
        $uitleg2.visible = $true
        $uitleg1.visible = $true
        
    }

    function subtakentonen {

        $Button1.visible = $false
        $Button2.visible = $false
        $uitleg2.visible = $false
        $uitleg1.visible = $false
        $Button8.visible = $true
        $Button9.visible = $true
        $Button10.visible = $true
        $Button11.visible = $true
        $Button6.visible = $true
        $Button5.visible = $true
    }

    function Nieuwelayoutgebruiken {
        # deze functie zorgt dat de layout van het hoofdvenster wordt aangepast als er voor een andere layout wordt gekozen waarbij subtaken worden weergegeven. 
   
        $Form.ClientSize = New-Object System.Drawing.Point(700,480)
        $Button1.Location = New-Object System.Drawing.Point(164,50)
        $Button2.Location = New-Object System.Drawing.Point(376,50)
        $uitleg1.Location = New-Object System.Drawing.Point(168, 215)
        $uitleg2.Location = New-Object System.Drawing.Point(402, 215)

        $Button5.Location = New-Object System.Drawing.Point(164,150)
        $Button6.Location = New-Object System.Drawing.Point(276,50)
        $Button8.Location = New-Object System.Drawing.Point(388,150)
        $Button9.Location = New-Object System.Drawing.Point(276,150)
        $Button10.Location = New-Object System.Drawing.Point(388,50)
        $Button11.Location = New-Object System.Drawing.Point(164,50)
        $Button12.visible = $true
    }

    function Oudelayoutgebruiken {
        # deze functie zorgt dat de layout van het hoofdvenster wordt aangepast als er voor een andere layout wordt gekozen waarbij subtaken worden verborgen. 
 
        $Button5.Location = New-Object System.Drawing.Point(52,250)
        $Button6.Location = New-Object System.Drawing.Point(52,350)
        $Button8.Location = New-Object System.Drawing.Point(588,250)
        $Button9.Location = New-Object System.Drawing.Point(588,50)
        $Button10.Location = New-Object System.Drawing.Point(588,150)
        $Button11.Location = New-Object System.Drawing.Point(52,150)
        # $Button2.Location = New-Object System.Drawing.Point(376,50)
        $Button1.visible = $true
        $Button2.visible = $true
        $uitleg2.visible = $true
        $uitleg1.visible = $true
        $Button12.Visible = $false
         
    }

function VerbindmetSharePoint {
       
try {
    # Verbinden met SharePoint
    Connect-PnPOnline -Url $global:Sharepoint.Url -Interactive -ErrorAction Stop

    # Test de nieuwe verbinding
    Get-PnPWeb -ErrorAction Stop | Out-Null

    return $true
}
catch {
    # Loggen van fout
    $melding = -join ("Verbinding met SharePoint mislukt.","`r`n", $($_.Exception.Message))
    Meldingnaarlogbestand -meldtekst $melding
    # melding geven met venster
    $melding = -join ("`r`n", $melding, "`r`n", "Een aantal taken kunnen nu niet uitgevoerd worden.")
    $null = venstermetvraag -titel "Geen verbinding met SharePoint." -vraag $melding "OK"
    return $false
}
} # einde function VerbindmetSharePoint

function ControleerverbindingSharePoint {

param (
    [string]$controlemap = $global:beheer.examenmappen.digitalebestanden
)
    try {
        Get-PnPFolder -Url $controlemap -ErrorAction Stop | Out-Null
        return $true
    }
    catch {

        $controle = VerbindmetSharePoint
        return $controle
    }
} # einde function ControleerverbindingSharePoint



# hieronder de hoofdfuncties ----------------------------------------------------------------



function scriptRun {

function DownloadSharepoint {
    param (
        [string]$FolderUrl,
        [string]$LocalFolder,
        [string]$Teamsname
    )

    try {
        # Lokale map maken
        if (!(Test-Path $LocalFolder)) {
            New-Item -ItemType Directory -Path $LocalFolder -ErrorAction Stop | Out-Null
            # write-host "Map aangemaakt: $LocalFolder"
        }
    }
    catch {
        throw "Fout bij maken map $LocalFolder : $($_.Exception.Message)"
        return
    }

    # Bestanden ophalen
    try {
        $files = Get-PnPFolderItem -FolderSiteRelativeUrl $FolderUrl -ItemType File -ErrorAction Stop
    }
    catch {
        throw "Fout bij ophalen bestanden in $FolderUrl : $($_.Exception.Message)"
        return
    }

    foreach ($file in $files) {
        try {
            $fileUrl = $file.ServerRelativeUrl
            $fileName = $file.Name

            # write-host "Download bestand: $fileUrl"
            Get-PnPFile -Url $fileUrl -Path $LocalFolder -FileName $fileName -AsFile -Force -ErrorAction Stop
        }
        catch {
            throw "Fout bij downloaden bestand $($file.Name) : $($_.Exception.Message)"
        }
    }

    # Submappen ophalen
    try {
        $folders = Get-PnPFolderItem -FolderSiteRelativeUrl $FolderUrl -ItemType Folder -ErrorAction Stop
    }
    catch {
        throw "Fout bij ophalen submappen in $FolderUrl : $($_.Exception.Message)"
        return
    }

    foreach ($folder in $folders) {
        try {
            $subFolderUrl = $folder.ServerRelativeUrl.Replace($teamsname, "")
            $subLocalPath = Join-Path $LocalFolder $folder.Name

            # write-host "Verwerk map: $subFolderUrl"
            DownloadSharepoint -FolderUrl $subFolderUrl -LocalFolder $subLocalPath -Teamsname $teamsname
        }
        catch {
            throw "Fout bij verwerken map $($folder.Name) : $($_.Exception.Message)"
        }
    }
} # einde DownloadSharepoint

function UploadSharePointFolder {
    param(
        [Parameter(Mandatory)]
        [string]$LocalFolderPath,

        [Parameter(Mandatory)]
        [string]$SharePointFolder
    )

    $errors = New-Object System.Collections.Generic.List[string]

    # controle lokale map
    if (-not (Test-Path -LiteralPath $LocalFolderPath -PathType Container)) {
        $errors.Add("Lokale map niet gevonden: $LocalFolderPath")
        return $errors
    }

    $SharePointFolder = $SharePointFolder.Replace('\','/').Trim('/')
    $RootFolderName = Split-Path -Path $LocalFolderPath -Leaf
    $RootSharePointPath = "$SharePointFolder/$RootFolderName"

    try {
        # aanmaken map
        Add-PnPFolder -Name $RootFolderName -Folder $SharePointFolder | Out-Null
    }
    catch {
        $errors.Add("Map $LocalFolderPath niet geüpload naar SharePoint: `r`n - $SharePointFolder `r`n$($_.Exception.Message)")
        return $errors
    }

    # kopiëren map naar Sharepoint
    UploadFolderContentsRecursive `
        -LocalPath $LocalFolderPath `
        -SharePointPath $RootSharePointPath `
        -ErrorList $errors

    return $errors
} # einde functie UploadSharePointFolder

function UploadFolderContentsRecursive {
    param(
        [Parameter(Mandatory)]
        [string]$LocalPath,

        [Parameter(Mandatory)]
        [string]$SharePointPath,

        [System.Collections.Generic.List[string]]$ErrorList
    )

    $files = Get-ChildItem -LiteralPath $LocalPath -File
    foreach ($file in $files) {
        try {
            Add-PnPFile -Path $file.FullName -Folder $SharePointPath | Out-Null
        }
        catch {
            $ErrorList.Add("Bestand niet geüpload naar SharePoint:`r`n - $($file.FullName) `r`n$($_.Exception.Message)")
        }
    }

    $subFolders = Get-ChildItem -LiteralPath $LocalPath -Directory
    foreach ($subFolder in $subFolders) {
        $childSharePointPath = "$SharePointPath/$($subFolder.Name)"
        try {
            Add-PnPFolder -Name $subFolder.Name -Folder $SharePointPath | Out-Null
        }
        catch {
            # $ErrorList.Add(("Map niet geüpload naar SharePoint: {0}{1}{2}" -f $childSharePointPath, [Environment]::NewLine, $_.Exception.Message))
            $ErrorList.Add(("Map niet geüpload naar SharePoint:", [Environment]::NewLine," - {0}{1}{2}" -f $childSharePointPath, [Environment]::NewLine, $_.Exception.Message))
            continue
        }

        UploadFolderContentsRecursive `
            -LocalPath $subFolder.FullName `
            -SharePointPath $childSharePointPath `
            -ErrorList $ErrorList
    }
} # einde functie UploadFolderContentsRecursive

function toevoegentekstvenster ($tekst) {
    # deze functie voegt tekst toe aan venster "Objtekst2". 
    # de tekst wordt altijd onderaan toegevoegd en het venster wordt automatisch naar beneden gescrold.
    # Alleen uitvoeren als de checkbox is aangevinkt
    if ($uitvoeren.voortgang) {
        $uitvoeren.objtekst2.Invoke([Action]{
            $uitvoeren.objtekst2.AppendText($tekst + "`r`n")
        })
    }

}

########## Function Scriptrun begint hieronder ##################################################

# info geven in rechter venster
$infotekst = -join ("De taak ", $uitvoeren.taak, " is gestart.")
toevoegentekstvenster "`r`n**********************"
toevoegentekstvenster $infotekst

# nodig voor afhandelen foutmeldingen
$uitvoeren.foutmelding = $false

# nodig om in logbestand te schrijven
$logbestand = $uitvoeren.logbestand

# hier wordt de taak uitgevoerd.
switch ($uitvoeren.taak) {

    "backup"   { 

    # datum en tijdstip van vandaag in variabele plaatsen. nodig om de backup-mapnaam te bepalen.
    $datumvandaag = get-date -Format "yyyy-MM-dd__HH-mm-ss"

    # variabele voor test met sharepoint.
    [string]$Sharepointmap = $uitvoeren.doelmap

    # test of sharepoint map bestaat en aanmaken
    toevoegentekstvenster "Aanmaken SharePointmap."
    try {
        # controleren of de map bestaat. Als dit niet het geval is, wordt de map aangemaakt.
        # eerst de Sahrepointmap de sitegedeelte toevoegen
        $web = Get-PnPWeb
        $Sharepointmap = $Sharepointmap.TrimStart("/")
        $Sharepointteammap = "$($web.ServerRelativeUrl)/$Sharepointmap"
        
        Add-PnPFolder `
            -Name $datumvandaag `
            -Folder $Sharepointteammap | Out-Null
    }
    catch {
        ("Aanmaken SharePointmap: " + $Sharepointteammap + "`n" + $_.Exception.Message) | Out-File -FilePath $logbestand -Append
        $uitvoeren.foutmelding = $true
        toevoegentekstvenster "$_"
        break
    } # einde catch

    #kopiëren bestanden naar homemappen van de kandidaten
    foreach ($rpcitem in $uitvoeren.listbox.selecteditems) {
        
        # teksten met meldingen voor het logbestand
        $foutmelding_log = "[ $rpcitem - FOUT ] : "

        # bepalen bronmap. dit is de homemap van de kandidaten
        $bronmap = -join ($uitvoeren.homemap,'\',$rpcitem)

        # bepalen doelmap. dit is de map waar de backup in komt.
        [string]$doelmap = -join ($Sharepointmap,'/',$datumvandaag)

        # errors leeg maken
        $error.clear()
        try {
                # extra test of de specifieke rpc-map wel bestaat. Anders wordt de catch getriggerd en heb je een foutmelding.
                if (!(Test-Path $bronmap)) { throw "Map $bronmap niet gevonden."}

                toevoegentekstvenster  "Backup maken van $rpcitem"
                # backup maken begint hier.
                # Aanroepen functie om map te uploaden en het resultaat opvangen
                $errors = UploadSharePointFolder `
                    -LocalFolderPath $bronmap `
                    -SharePointFolder $doelmap
                
                # Kijken of er iets is misgegaan en daarna wissen als "wissen na backup" is geselecteerd 
                if ($errors.Count -gt 0) {
                    
                    # errors verzamelen en teruggeven
                    $melding = "Er zijn $($errors.Count) fout(en) opgetreden tijdens de upload."
                    $errors | ForEach-Object { $melding = -join ($melding, "`r`n", "$_") }
                    throw $melding

                    } elseif ($uitvoeren.wissennabackup -eq $true) {
                    # Wissen als dit geselecteerd is

                    # voortgang weergeven
                    toevoegentekstvenster  "Wissen van $rpcitem"                  
                    # Eerst de inhoud van mijn documenten 
                    Remove-Item "$bronmap\mijn documenten\*" -Recurse -Force -ErrorAction Stop
                    # dan de root van rpc-map exclusief map mijn documenten
                    Remove-Item "$bronmap\*" -Recurse -Force -Exclude "mijn documenten" -ErrorAction Stop
                    } # einde elseif $uitvoeren.wissennabackup -eq $true
        } # einde try
        catch {
                # foutmelding van PowerShell naar logbestand
                "$foutmelding_log" + $_.exception.message | out-file "$logbestand" -Append
                $uitvoeren.foutmelding = $true
                toevoegentekstvenster "$_"
        } # einde catch
        # progressie laten zien op balk
        $uitvoeren.progressbar.PerformStep()

    } # einde foreach rpcitem

               } # einde taak backup

    "kopiëren" { 

    # array aanmaken en vullen met geselecteerde items. 
    # Deze items worden vervolgens gekopiëerd.
    $geselecteerdeitems = [System.Collections.ArrayList]@()

    toevoegentekstvenster "Tijdelijke map aanmaken."
     # Tijdelijke map om bestanden uit te delen. Deze map wordt na het kopiëren verwijderd.
    $localPath = $env:USERPROFILE + "\Temp_BeherenBestanden"
    # onderstaande is nodig omdat bij DownloadSharepoint alleen de tijdelijke map automatisch wordt aangemaakt 
    # en niet wordt gewist als deze al bestaat.
    if (!(Test-Path $localPath)) {
        New-Item -ItemType Directory -Path $localPath -ErrorAction Stop | Out-Null
        # write-host "Tijdelijke map aangemaakt: $localPath"
    } else {
        # als de map al bestaat, deze eerst leeg maken. Anders kunnen er problemen ontstaan bij het kopiëren van bestanden als er al bestanden in staan.
        Remove-Item "$localPath\*" -Recurse -Force -ErrorAction Stop
    }
    
    # Teamsname wordt gebruikt bij dowloadsharepoint om de juiste url te bepalen. Deze is nodig omdat de url van een map in sharepoint afhankelijk is van de teamsnaam.
    $teamsname = $uitvoeren.team 

    # bronmap bepalen en in makkeljike variabele plaatsen. dit is de examenmap in sharepoint. 
    $bronmap =$uitvoeren.bronmap
    
    # foutmelding van PowerShell naar logbestand
    $foutmelding_log = "[ Downloaden SharePoint FOUT ] : "

    toevoegentekstvenster "Downloaden bestanden."
    <# Als er geen items zijn geselecteerd in de examenmap dan moet de gehele map worden gekopiërd naar $localPath
     anders worden de geselecteerde items een voor een gekopieerd.
    #>
    if ($uitvoeren.listview1.selecteditems.count -eq 0) {
        # uitvoeren als er niet is geklikt in het venster met mappen. Dit betekent dus de hele inhoud kopieëren.
        try { 
        DownloadSharepoint -FolderUrl $bronmap -LocalFolder $localPath -Teamsname $teamsname
        }
        catch {
            $melding = -join ($foutmelding_log, "`n", $_.exception.message)
            $melding | out-file "$logbestand" -Append
            $uitvoeren.foutmelding = $true
            $uitvoeren.progressbar.PerformStep()
            toevoegentekstvenster "$_"
            break
        } # einde = try catch DownloadSharepoint

        } else {
        # alleen de geselecteerd items in het venster met mappen kopieëren.
        
        $folders = Get-PnPFolderItem -FolderSiteRelativeUrl $bronmap
        try { 
            $folders = Get-PnPFolderItem -FolderSiteRelativeUrl $bronmap  
        }
        catch {
            $melding = -join ($foutmelding_log, "`n", $_.exception.message)
            $melding | out-file "$logbestand" -Append
            $uitvoeren.foutmelding = $true
            $uitvoeren.progressbar.PerformStep()
            toevoegentekstvenster "$_"
            break
        } # einde catch

        # loop door alle items en controleren of deze geselecteerd zijn.
        # Als dit het geval is, worden deze gedownload.
        foreach ($item in $uitvoeren.listview1.selecteditems) {
            $bronmap = -join ($uitvoeren.bronmap,'/',$item[0].text)
           
            foreach ($folder in $folders) {
                if ($folder.Name -eq $item[0].text) {
                    try {
                    if ($folder.GetType().Name -eq "Folder") {
                        $sublocalpath = Join-Path $localPath $folder.Name
                        DownloadSharepoint -FolderUrl $bronmap -LocalFolder $sublocalpath -Teamsname $teamsname
                        } elseif ($folder.GetType().Name -eq "File") {
                        Get-PnPFile -Url $bronmap -Path $localPath -FileName $folder.Name -AsFile -Force -ErrorAction Stop
                    } # einde if $folder.GetType().Name .. elseif... 
                    }
                    catch {
                        "$foutmelding_log" + $_.exception.message | out-file "$logbestand" -Append
                        $uitvoeren.foutmelding = $true
                        toevoegentekstvenster "$_"
                    } # einde try catch DownloadSharepoint binnen if $folder.Name -eq $item[0].text

                } # einde if $folder.Name -eq $item[0].text
            } # einde foreach $folder
        }
        # write-host "Geselecteerde items toegevoegd aan lijst met te kopiëren items."
    } # einde if $uitvoeren.listview1.selecteditems.count -eq 0 .... else ....

    # progressie laten zien op balk
    $uitvoeren.progressbar.PerformStep()

    #kopiëren bestanden naar homemappen van de kandidaten
    foreach ($rpcitem in $uitvoeren.listbox.selecteditems) {
        # teksten met meldingen voor het logbestand
        $foutmelding_log = "[ $rpcitem - FOUT ] : "

        # doelmap bepalen. dit is een lokale variabele
        $doelmap = -join ($uitvoeren.homemap,'\',$rpcitem,'\Mijn Documenten')
    
        # Weergeven in venster dat bestanden worden gekopieerd naar de homemap van de kandidaat.
        toevoegentekstvenster "Kopiëren bestanden naar $rpcitem"

        # kopieren geselecteerde mappen of bestanden  
        Copy-Item -path "$localPath\*" -destination "$doelmap" -recurse -Force -ErrorAction Stop
        # progressie laten zien op balk
        $uitvoeren.progressbar.PerformStep()
    } # einde foreach $rpcitem

    # progressie laten zien op balk
    # $uitvoeren.progressbar.PerformStep()
    # array legen. mss is dit niet nodig!
    $geselecteerdeitems.Clear()
    # geselecteerde rpc-nummers wissen. je moet dan opnieuw selecteren en kan niet meteen op bevestigen klikken.
    $uitvoeren.listbox.selecteditems.clear()
    # tijdelijke map verwijderen.
    Remove-Item "$localPath" -Recurse -Force
    # eventueel in try catch zetten als er problemen ontstaan bij het verwijderen van de tijdelijke map en dan onderstaand gebruiken:
    # Remove-Item "$localPath" -Recurse -Force -ErrorAction Stop  

               } # einde taak kopiëren

    "wissen"   { 
        #wissen van bestanden in homemappen van de kandidaten
        foreach ($rpcitem in $uitvoeren.listbox.selecteditems) {
            # teksten met meldingen voor het logbestand
            $foutmelding_log = "[ $rpcitem - FOUT ] : "
            
            # doelmap bepalen. dit is een lokale variabele voor de deel-functie wissen hieronder.
            $doelmap = -join ($uitvoeren.homemap,'\',$rpcitem,'\Mijn Documenten')
            $doelmaproot = -join ($uitvoeren.homemap,'\',$rpcitem)

            $error.clear()
            try {
                # extra test of de specifieke rpc-map en submap wel bestaat
                if (!(Test-Path $doelmap)) { throw "Map $doelmap niet gevonden."}
                if (!(Test-Path $doelmaproot)) { throw "Map $doelmaproot niet gevonden."}

                toevoegentekstvenster  "Wissen van $rpcitem"

                # verwijderen van bestanden. Eerst de inhoud van mijn documenten
                Remove-Item "$doelmap\*" -Recurse -Force -ErrorAction Stop
                # dan de root van rpc-map exclusief map mijn documenten
                Remove-Item "$doelmaproot\*" -Recurse -Force -Exclude "mijn documenten" -ErrorAction Stop
                }
            catch {

                # foutmelding van PowerShell naar logbestand
                "$foutmelding_log" + $_.exception.message | out-file "$logbestand" -Append
                $uitvoeren.foutmelding = $true
                  } # einde catch
            # progressie laten zien op balk
            $uitvoeren.progressbar.PerformStep()

            } # einde foreach statement
               } # einde taak wissen

    "verplaatsen" {
        # er is maar een actie te doen dus...
        $uitvoeren.progressbar.maximum = 3

        # teksten met meldingen voor het logbestand
        $foutmelding_log = "[ FOUT ] : "

        # definiëren bron- en doelmap
        $bronmap = $uitvoeren.bronmap
        $doelmap = $uitvoeren.doelmap

        # doelmap wordt geleegd voor het verplaatsen of kopiëren. 
        # dit is nu altijd gekozen maar staat hier nog met een if-statement om eventueel nog te wijzigen.
        if ($uitvoeren.doelmaplegen -eq $true) {
            $error.clear()
            try {
                # extra test of de specifieke rpc-map wel bestaat
                if (!(Test-Path $doelmap)) { throw "Map $doelmap niet gevonden."}
                toevoegentekstvenster  "Map $doelmap leegmaken"
                # verwijderen van bestanden in doelmap
                Remove-Item "$doelmap\*" -Recurse -Force -ErrorAction Stop
                }
            catch {

                # foutmelding van PowerShell naar logbestand
                "$foutmelding_log" + $_.exception.message | out-file "$logbestand" -Append
                $uitvoeren.foutmelding = $true

                toevoegentekstvenster "$_"
                # Verder ook niet meer uitvoeren

                # progressie laten zien op balk
                $uitvoeren.progressbar.PerformStep()
                break;
                  } # einde catch
        } # einde if ($uitvoeren.doelmaplegen -eq $true)
        
        # progressie laten zien op balk
        $uitvoeren.progressbar.PerformStep()

        # kopieren of verplaatsen
        $error.clear()
        try {
            # extra test of de specifieke rpc-map wel bestaat
            if (!(Test-Path $bronmap)) { throw "Map $bronmap niet gevonden."}
            
            # eerst kopiëren
            toevoegentekstvenster "Kopiëren van $bronmap naar $doelmap"
            Copy-Item -path "$bronmap" -destination "$doelmap" -recurse -ErrorAction Stop

            # progressie laten zien op balk
            $uitvoeren.progressbar.PerformStep()

            # verwijderen van bestanden als keuze is verplaatsen. alleen de inhoud van mijn documenten
            if ($uitvoeren.keuzeverplaatsen -eq "verplaatsen") {
                toevoegentekstvenster  "Wissen van $bronmap"
                Remove-Item "$bronmap" -Recurse -Force -ErrorAction Stop
                }
            }
        catch {
              
              $uitvoeren.foutmelding = $true
              # foutmelding van PowerShell naar logbestand
              "$foutmelding_log" + $_.exception.message | out-file "$logbestand" -Append
              toevoegentekstvenster "$_"
              
              } # einde catch

        # progressie laten zien op balk
        $uitvoeren.progressbar.PerformStep()

                  } # einde taak verplaatsen

    "opschonen"   { 
        #wissen van backups van homemappen van de kandidaten
        foreach ($rpcitem in $uitvoeren.listbox.items) {
            # teksten met meldingen voor het logbestand
            $foutmelding_log = "[ $rpcitem - FOUT ] : "
            
            # doelmap bepalen. dit is een lokale variabele voor de deel-functie wissen hieronder.
            $doelmap = $uitvoeren.doelmap
            # verwijderen van / aan het begin
            $doelmap = $doelmap.Trim('/')

            $error.clear()
            try {
                toevoegentekstvenster "Wissen van $rpcitem"
                # compleet verwijderen van mappen. 
                Remove-PnPFolder -Name $rpcitem -Folder $doelmap -Force
                }
            catch {
                # foutmelding van PowerShell naar logbestand
                "$foutmelding_log" + $_.exception.message | out-file "$logbestand" -Append
                $uitvoeren.foutmelding = $true
                  } # einde catch
            # progressie laten zien op balk
            $uitvoeren.progressbar.PerformStep()

            } # einde foreach statement
               } # einde taak wissen

} # einde switch commando $uitvoeren.taak

toevoegentekstvenster "De taak is uitgevoerd."
toevoegentekstvenster "**********************"

} # einde scriptRun

function uitvoerentaken {
# hier worden de 5 belangrijkste taken uitgevoerd.

# controleren of mappen bestaan - afhankelijk van de taak
# map uitvoeren.homemap wordt in ieder geval gecontroleerd

if (!(Netwerkmapaanwezig -netwerkmap $global:beheer.examenmappen.homemapstudenten)) { 
    return; 
} 

if ($uitvoeren.taak -eq "kopiëren") {
    if (!( ControleerverbindingSharePoint -controlemap $global:beheer.examenmappen.digitalebestanden )) {
        return
    } 
} 

if ($uitvoeren.taak -eq "backup") {
    if (!( ControleerverbindingSharePoint -controlemap $global:beheer.examenmappen.backupmap )) {
        return
    }
} 


# einde controleren of mappen bestaan

# Extra beveiliging voordat je de taak opschonen gaat uitvoeren

if ($uitvoeren.taak -eq "opschonen") {
   $vraagopschonen="LET OP : Als u nu op Opschonen klikt worden de bestanden definitief verwijderd!" + "`r`n" + "`r`n" + "Dit kan niet worden teruggedraaid." + "`r`n" + "Klik op Terug als u terug wilt."
 
   $result=venstermetvraag -titel "Starten met opschonen?" -vraag $vraagopschonen -knopok "Opschonen" -knopterug "Terug"

   if ( $result -eq "Cancel") { return }
}

# Extra beveiliging voordat je de taak wissen gaat uitvoeren

if ($uitvoeren.taak -eq "wissen") {
   $vraagwissen="LET OP : Als u nu op Wissen klikt worden de bestanden definitief verwijderd!" + "`r`n" + "`r`n" + "Dit kan niet worden teruggedraaid." + "`r`n" + "Klik op Terug als u terug wilt."

   $result=venstermetvraag -titel "Starten met wissen?" -vraag $vraagwissen -knopok "Wissen" -knopterug "Terug"

   if ( $result -eq "Cancel") { return }
}

# extra controle voordat je de taak bestanden klaarzetten gaat uitvoeren
if (($uitvoeren.taak -eq "kopiëren") -and ($uitvoeren.controlemappen)) {
    $teller = 0
    $nietlegemappen = ""

    foreach ($rpcitem in $listbox.selecteditems) {
        # doelmap bepalen. dit is een lokale variabele
        $doelmap = -join ($global:beheer.examenmappen.homemapstudenten,'\',$rpcitem,'\Mijn Documenten')
    
        # Controleren of de mappen leeg zijn. Foutmeldingen worden gelogd maar niet getoond!
        try {
            If ((Get-ChildItem -Path $doelmap -Force -ErrorAction Stop | Measure-Object).Count -gt 0) {
                # rpc-nr toevoegen aan overzicht van mappen die niet leeg zijn
                $nietlegemappen = -join ($nietlegemappen, $rpcitem, ' - ')
                $teller++
            } 
        }
        catch {
            $melding = -join ("Extra controle voor het uitvoeren van de taak Bestanden Klaarzetten : ", "`r`n", $_.exception.message )
            Meldingnaarlogbestand -meldtekst $melding
        }
        
    } # einde foreach $rpcitem ...

    # als een aantal mappen niet leeg zijn
    if ($teller -gt 0 ) {
    $vraagdoorgaan="LET OP : Op een aantal RPC-nummers zijn al bestanden aanwezig!" + "`r`n" + "Als u doorgaat worden de bestanden toegevoegd." + "`r`n" +
    "Klik op Terug als u terug wilt." + "`r`n" + "`r`n" + "De volgende $teller RPC-nummers zijn niet leeg: $nietlegemappen" 

    $result=venstermetvraag -titel "Controle of homemappen van de kandidaten leeg zijn." -vraag $vraagdoorgaan -knopok "Doorgaan" -knopterug "Terug" -schuifbalk

    if ( $result -eq "Cancel") { return }
    }

} 
# Einde extra controle voordat je de taak bestanden klaarzetten gaat uitvoeren

# startknop wordt onzichtbaar en venster met functie gesloten
$StartButton.Hide()
$Btnescape.Hide()
$form2.hide();


# het proces zichtbaar maken in een balk
$uitvoeren.progressbar = New-Object System.Windows.Forms.ProgressBar
$uitvoeren.progressbar.Location = New-Object System.Drawing.Point(20, 40)
$uitvoeren.progressbar.Size = New-Object System.Drawing.Size(560, 30)
$uitvoeren.progressbar.Style = "continuous"

# de maximumwaarde van de progressbar. Deze is bij taak opschonen en kopieren anders.
if ($uitvoeren.taak -eq "opschonen") {
    $uitvoeren.progressbar.maximum = $listbox.items.count
    } elseif ($uitvoeren.taak -eq "kopiëren") {
    # plus 2 omdat er eerst een stap is voor het downloaden van de bestanden en, na het kopiëren van de bestanden, het leegmaken van tijdelijke map.
    $uitvoeren.progressbar.maximum = $listbox.selecteditems.count +1
    } else {
    $uitvoeren.progressbar.maximum = $listbox.selecteditems.count
    }
$uitvoeren.progressbar.step = 1

# ProgressBar toevoegen aan form3
$uitvoeren.form3.Controls.Add($uitvoeren.progressbar);

# teksten en progressbar veranderen
$Label.hide()
$Description3.hide()
$Description2.ForeColor = 'green'
$Description2.Text = "De taak wordt uitgevoerd ..."
$uitvoeren.progressbar.visible

# tijdelijk logbestand bepalen
$tijdelijkelog = "tijdelijkelog.txt"

# logbestandsnaam definiëren en volledige pad naar bestand invoeren
$logbestand = -join ("$logmap","\",$tijdelijkelog)

# doorgeven aan hastable uitvoeren
$uitvoeren.logbestand = $logbestand

# starttijd van loggen naar variabele
$logtijd = bepaaltijd

# map aanmaken voor logbestanden als deze niet bestaat
if (!(Test-Path "$logmap")) { New-Item -Path "$logmap" -ItemType Directory | Out-Null  } 

# in logbestand info over de taak schrijven en beginnen met uitvoeren van taak ---------------------------

"De taak " + $uitvoeren.taak + " is gestart." | out-file $logbestand -Append -Encoding utf8BOM
"Starttijd : $logtijd" | out-file $logbestand -Append

if ($uitvoeren.taak -eq "kopiëren") {
    $objtekst2.Text | out-file $logbestand -Append
    } elseif ($uitvoeren.taak -eq "backup") {
    if ($wissennabackup.checked -eq $true) { "De bestanden worden na de back-up gewist." | out-file $logbestand -Append }
    } elseif ($uitvoeren.taak -eq "verplaatsen") {
    if ($keuzeoptie1.Selectedindex -eq "1") { 
        "U gaat bestanden kopiëren van een rpc-nummer naar een andere." | out-file $logbestand -Append
        } else {
        "U gaat bestanden verplaatsen van een rpc-nummer naar een andere." | out-file $logbestand -Append
        }
     if ($doelmaplegen.checked -eq $true) { 
        "De doelmap wordt voor het verplaatsen of kopiëren eerst geleegd." | out-file $logbestand -Append
                    } else {
        "De bestanden worden toegevoegd aan de bestanden in de doelmap." | out-file $logbestand -Append
                    }
    }
$objtekst1.Text | out-file $logbestand -Append

# ------ begin runspaces ----------------------------------------------

#Configure max thread count for RunspacePool.
$maxthreads = [int]$env:NUMBER_OF_PROCESSORS
    
#Create a new session state for parsing variables ie hashtable into our runspace.
$hashVars = New-object System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList 'uitvoeren',$uitvoeren,$Null
$InitialSessionState = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
    
#Add the variable to the RunspacePool sessionstate
$InitialSessionState.Variables.Add($hashVars)

#Create our runspace pool. We are entering three parameters here min thread count, max thread count and host machine of where these runspaces should be made.
$script:runspace = [runspacefactory]::CreateRunspacePool(1,$maxthreads,$InitialSessionState, $Host)

#Create a PowerShell instance.
$script:powershell = [powershell]::Create()
    
#Open a RunspacePool instance.
$script:runspace.Open()
         
#Add our main code to be run via $scriptRun within our RunspacePool.
$script:powershell.AddScript(${Function:scriptRun})
$script:powershell.RunspacePool = $script:runspace
        
#Run our RunspacePool.
$script:handle = $script:powershell.BeginInvoke()

#Wait for code to complete and keep UI responsive
do {
		[System.Windows.Forms.Application]::DoEvents()
		Start-Sleep -Milliseconds 1 
} while (!$script:handle.IsCompleted)

#Cleanup our RunspacePool threads when they are complete ie. GC.
if ($script:handle.IsCompleted)
        {
            $script:powershell.EndInvoke($script:handle)
            $script:powershell.Dispose()
            $script:runspace.Dispose()
            $script:runspace.Close()
            [System.GC]::Collect()
        }

# ----- Einde runspaces -----------------------------------------------

# in logbestand eindtijd schrijven
# eerst eindtijd naar variabele
$logtijd = bepaaltijd


"" | out-file $logbestand -Append
"Eindtijd  : $logtijd" | out-file $logbestand -Append
" -------------------------------------------------------------------------" | out-file $logbestand -Append
"" | out-file $logbestand -Append

# tijdelijke log toevoegen aan eigen logbestand als deze al bestaat. 
Logbestandtoevoegen $logbestand


# aangeven dat taken zijn uitgevoerd 
if ($uitvoeren.foutmelding) { 
    $Description2.ForeColor = 'red'
    $Description2.Text = "De taak is niet correct uitgevoerd. Bekijk de foutmeldingen in het logbestand."
    } else { $Description2.Text = "De taak is uitgevoerd." }

# knoppen zichtbaar maken
$EndButton.show()
$LogButton.show()
# de checkbox niet klikbaar
$voortgang.Visible = $false

# alleen bij taak kopieren onderstaande knop zichtbaar maken
if ($uitvoeren.taak -eq "kopiëren") {
    $Btnescape.size = New-Object System.Drawing.Size(200,40)
    # escape knop wordt nu opnieuw knop
    $Btnescape.text= "Opnieuw bestanden klaarzettenn"
    $Btnescape.BackColor = 'green'
    $Btnescape.show()
} elseif ($uitvoeren.taak -in @("wissen", "verplaatsen")) {
    # alleen bij taken wissen en verplaatsen onderstaande knop zichtbaar maken
    $Btnescape.size = New-Object System.Drawing.Size(200,40)
    # escape knop wordt nu terug knop
    $Btnescape.text= "Terug naar Verkenner"
    $Btnescape.BackColor = 'green'
    $Btnescape.show()  
} else {
# knop logbestand bekijken wordt nu naar links verplaatst om aan te sluiten met knop Terug.
$LogButton.Location = New-Object System.Drawing.Size(160, 440)
}

$form2.show()

# simuleer indrukken van tab-toets om de focus terug te brengen naar huidige venster.
[System.Windows.Forms.SendKeys]::SendWait("%{TAB}")

} # einde uitvoerentaken

function overzichttaken ([string]$taak) {
# na het bevestigen van je keuze bij een van de 4 taken kom je bij deze functie.
# hier zie je een overzicht en kan je de taak starten of nog terug.

# beheer-variabelen krijgen hier een verkorte naam tbv leesbaarheid en gebruik in andere functies
$digitalebestanden = $global:beheer.examenmappen.digitalebestanden
$homemapstudenten = $global:beheer.examenmappen.homemapstudenten
$backupmap = $global:beheer.examenmappen.backupmap

# hashtable object leeg maken voor het geval het nog waarden heeft.
$uitvoeren.clear()

# definiëren venster
switch ($taak) {
    "backup"      { $titel = "Overzicht uit te voeren taak Back-up maken " }
    "kopiëren"    { $titel = "Overzicht uit te voeren taak Bestanden klaarzetten" }
    "wissen"      { $titel = "Overzicht uit te voeren taak Wissen" }
    "verplaatsen" { $titel = "Overzicht uit te voeren taak Verplaatsen" }
    "opschonen"   { $titel = "Overzicht uit te voeren taak Opschonen" }
}

$uitvoeren.Form3 = declareren_standaardvenster $titel 600 540

$Description2                     = New-Object system.Windows.Forms.Label
$Description2.AutoSize            = $false
$Description2.width               = 570
$Description2.height              = 20
$Description2.location            = New-Object System.Drawing.Point(20,10)
$Description2.Font                = 'Microsoft Sans Serif,11'
$Description2.ForeColor           = 'blue'

# onderstaande tekst wordt alleen zichtbaar als backuptaak is gekozen en wissen na backup is geselecteerd.
$Description3                     = New-Object system.Windows.Forms.Label
$Description3.AutoSize            = $false
$Description3.width               = 500
$Description3.height              = 20
$Description3.location            = New-Object System.Drawing.Point(20,28)
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.Text                = "De bestanden worden na de back-up gewist."
$Description3.ForeColor           = 'blue'
$Description3.hide()

$StartButton = New-Object System.Windows.Forms.Button
$StartButton.Location = New-Object System.Drawing.Size(10, 440)
$StartButton.Size = New-Object System.Drawing.Size(120, 50)
$StartButton.Text = "Start"
$StartButton.height = 40
$StartButton.BackColor = 'green'
$StartButton.ForeColor = 'white'
$StartButton.Add_click( {
    # toevoegen object en variabelen aan hastable voor uitvoeren 
    $uitvoeren.taak=$taak
    $uitvoeren.homemap=$homemapstudenten
    $uitvoeren.listbox = New-Object System.Windows.Forms.Listbox
    $uitvoeren.listbox = $listbox
    $uitvoeren.voortgang = $voortgang.checked

    # doorgeven objtekst. dit is de venster waarin de voortgang wordt bijgehouden.
    $uitvoeren.objtekst2 = New-Object System.Windows.Forms.textbox
    $uitvoeren.objtekst2 = $objtekst2
    <# specifieke variabelen voor de gegeven taak.
       o.a. toevoegen tekst aan variabele uitvoeren.logbestandtekst om in logbestand te plaatsen
    #>
    switch ($taak) {

        "kopiëren" {
        $uitvoeren.ListView1 = New-Object System.Windows.Forms.ListView
        $uitvoeren.ListView1 = $global:ListView1
        $uitvoeren.controlemappen = $controlemappen.checked
        $uitvoeren.bronmap = $digitalebestanden
        $uitvoeren.team = $global:Sharepoint.team
        foreach ($item in $global:geselecteerdebronmap) {
                    $uitvoeren.bronmap  = -join ($uitvoeren.bronmap, '/', $item)
                }
        }

        "backup" {
        $uitvoeren.doelmap="$backupmap"
        $uitvoeren.wissennabackup=$wissennabackup.checked
        }

        "verplaatsen" {
        # bepalen doel-, bronmap en doelmaplegen
        $uitvoeren.bronmap = -join ($homemapstudenten,"\",$listbox.selecteditem,"\Mijn Documenten\*")
        $uitvoeren.doelmap = -join ($homemapstudenten,"\",$doelselectie.selecteditem,"\Mijn Documenten")

        # De volgende 2 variabelen hebben nu standaard de gegeven waarden.
        # dus de doelmap wordt altijd geleegd en alleen de keuze verplaatsen is mogelijk.
        # Deze variabelen blijven bestaan om mogelijk in de toekomst de opties open te houden.
        $uitvoeren.doelmaplegen=$true
        $uitvoeren.keuzeverplaatsen = "verplaatsen" 
        # keuze tussen kopieren of verplaatsen doorgeven. Dit is niet meer mogelijk.
        <#
        if ($keuzeoptie1.Selectedindex -eq "1") { 
                    $uitvoeren.keuzeverplaatsen = "kopiëren" 
                    } else {
                    $uitvoeren.keuzeverplaatsen = "verplaatsen" 
                    }
        #>
        }

        "opschonen" {
        $uitvoeren.doelmap="$backupmap"
        
        }
    } # einde switch $taak

    # $form2.hide()

    uitvoerentaken;
    
    });

$EndButton = New-Object System.Windows.Forms.Button
$EndButton.Location = New-Object System.Drawing.Size(10, 440)
$EndButton.Size = New-Object System.Drawing.Size(120, 50)
$EndButton.Text = "Sluiten"
$EndButton.height = 40
$EndButton.BackColor = 'red'
$EndButton.ForeColor = 'white'
$EndButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$EndButton.hide()

$Btnescape = New-object System.Windows.Forms.Button 
$Btnescape.text= "Terug"
$Btnescape.location = New-Object System.Drawing.Size(160, 440)
$Btnescape.size = New-Object System.Drawing.Size(120, 50)
$Btnescape.height = 40
$Btnescape.BackColor = 'red'
$Btnescape.ForeColor = 'white'
$Btnescape.DialogResult = [System.Windows.Forms.DialogResult]::cancel

$LogButton = New-Object System.Windows.Forms.Button
$LogButton.Location = New-Object System.Drawing.Size(400, 440)
$LogButton.Size = New-Object System.Drawing.Size(170, 50)
$LogButton.Text = "Logbestand bekijken"
$LogButton.height = 40
$LogButton.BackColor = 'green'
$LogButton.ForeColor = 'white'
$LogButton.hide()
$LogButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$LogButton.add_click({ 
    $Form2.dispose()
    $uitvoeren.Form3.dispose()

    vensterlogbestand })

$Label = New-Object System.Windows.Forms.Label
$Label.Font = 'Microsoft Sans Serif,12'
$Label.ForeColor = 'blue'
$Label.Text = "Klaar om de geselecteerde taak uit te voeren ?"
$Label.Location = New-Object System.Drawing.Point(20, 50)
$Label.Width = 480
$Label.Height = 20

switch ($taak) {
    "backup"      { 
                  $Description2.text = "U gaat een back-up uitvoeren op de volgende RPC-nummers." 
                  if ($wissennabackup.checked -eq $true) { 
                    $Description3.text = "De bestanden worden na de back-up gewist."
                    $Description3.show() 
                    }
                  }
    "kopiëren"    { $Description2.text = "U gaat bestanden of mappen klaarzetten op de volgende RPC-nummers." }
    "wissen"      { $Description2.text = "U gaat bestanden wissen van de volgende RPC-nummers." }
    "verplaatsen" { 
                  $Description3.show() 
                  $Description2.text = "U gaat bestanden verplaatsen van een RPC-nummer naar een andere." 
                  $Description3.text = "De doelmap wordt voor het verplaatsen of kopiëren eerst geleegd."
                  <# Bij taak verplaatsen is er geen keuze meer!! Dus alleen verplaatsen en altijd doelmap wissen!
                  if ($keuzeoptie1.Selectedindex -eq "1") { 
                    $Description2.text = "U gaat bestanden kopiëren van een RPC-nummer naar een andere." 
                    } else {
                    $Description2.text = "U gaat bestanden verplaatsen van een RPC-nummer naar een andere." 
                    }
                  
                  if ($doelmaplegen.checked -eq $true) { 
                    $Description3.text = "De doelmap wordt voor het verplaatsen of kopiëren eerst geleegd."
                    } else {
                    $Description3.text = "De bestanden worden toegevoegd aan de bestanden in de doelmap."
                    }
                  #>
                  }
    "opschonen"   { $Description2.text = "U gaat oude back-ups verwijderen." }
} # einde switch taak

$objtekst1 = New-Object System.Windows.Forms.textbox
$objtekst1.Location = New-Object System.Drawing.Size(20,80) 
$objtekst1.Size = New-Object System.Drawing.Size(200,290)
$objtekst1.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$objtekst1.Text = "RPC-nummers:" + "`r`n" + "`r`n"
$objtekst1.ReadOnly = $true
$objtekst1.Multiline = $true
$objtekst1.ScrollBars = "Both"
$objtekst1.BackColor  = 'white'

$objtekst2 = New-Object System.Windows.Forms.textbox
$objtekst2.Location = New-Object System.Drawing.Size(230,80) 
$objtekst2.Size = New-Object System.Drawing.Size(350,290)
$objtekst2.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$objtekst2.Text = ""
$objtekst2.ReadOnly = $true
$objtekst2.Multiline = $true
$objtekst2.ScrollBars = "Both"
# $objtekst2.Visible = $false
$objtekst2.BackColor  = 'white'
$objtekst2.WordWrap = $false

$voortgang = New-Object System.Windows.Forms.Checkbox 
$voortgang.Location = New-Object System.Drawing.Point(20,390)
$voortgang.Size = New-Object System.Drawing.Size(400,30)
$voortgang.Text = "Voortgang van de taak weergeven in het rechter venster"
$voortgang.Font = 'Microsoft Sans Serif,11'
$voortgang.ForeColor = [System.Drawing.Color]::green
$voortgang.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Geef aan je de voortgang van de taak wilt zien in het rechter venster." )
})

if (($global:init["algemeen"]["voortgangweergeven"]) -eq "Ja") {
    $voortgang.checked = $true
    } else {
    $voortgang.checked = $false
    }

# geselecteerde rpc-nummers links weergeven
# als taak is verplaatsen of opschonen heb je een andere inhoud dan bij overige taken
if ($taak -eq "verplaatsen") {
    $objtekst1.Text = $objtekst1.Text + " Bron is " + $listbox.selecteditem + "`r`n" + "`r`n"
    $objtekst1.Text = $objtekst1.Text + " Doel is " + $doelselectie.selecteditem + "`r`n"

    } elseif ($taak -eq "opschonen") {
    $objtekst1.Text = "Er zijn " + $listbox.items.count + " mappen met back-ups ouder dan " + $objTextBox1.Text + " dagen: "+ "`r`n" + "`r`n"
    foreach ($item in $listbox.items) {
        $objtekst1.Text = $objtekst1.Text + " - " + "$item" + "`r`n"
        }

    } else {
    foreach ($item in $listbox.selecteditems) {
        $objtekst1.Text = $objtekst1.Text + " - " + "$item" + "`r`n"
        }
    }

# geselecteerde mappen bij taak kopiëren rechts weergeven in overzicht. alleen als taak kopieren is geslecteerd
if ($taak -eq "kopiëren") {
    $objtekst2.Text = "Examenmap:" + "`r`n"
    # $objtekst2.Visible = $true

    # bepalen van geselecteerde bronmap.
    [string] $selectie = ""
    foreach ($item in $global:geselecteerdebronmap) {
          $selectie = -join ($selectie, '\', $item)
          }
    $objtekst2.Text = $objtekst2.Text + " - " + "$selectie" + "`r`n" + "`r`n"

    # alleen als er subitems zijn geselecteerd in middelste venster, overzicht geven
    if ($listview1.selecteditems.count -gt 0) {
        
        # bepalen bronmap
        $selectie = -join ($digitalebestanden, '\', $selectie)
        # aangeven of de eerste item is gevonden. alleen bij de 1e wordt extra text weergegeven
        $eerste = $true
        # inlezen en bepalen of er mappen zijn
        foreach ($item in $ListView1.selecteditems) {
            # inlezen geselecteerde items
            $inleesitem = $item[0].text
            # bepalen van map die gecontroleerd wordt
            $controleitem = -join ($selectie, '\', $inleesitem)

            
            # alleen weergeven als dit een map is
            if (( test-path -path "$controleitem" -pathtype container) -eq $true)  {
                # alleen bij de eerste item
                if ($eerste) {
                    $objtekst2.Text = $objtekst2.Text + "Submappen :" + "`r`n"
                    $eerste = $false
                    }
                $objtekst2.Text = $objtekst2.Text + " - " + "$inleesitem" + "`r`n"
                }
            }# einde 1e for each item

        # lege regel plaatsen, alleen als er mappen zijn weergegeven
        if (!($eerste)) { $objtekst2.Text = $objtekst2.Text + "`r`n" }

        # aangeven of de eerste item is gevonden. alleen bij de 1e wordt extra text weergegeven
        $eerste = $true
        # inlezen en bepalen of er bestanden zijn
        foreach ($item in $ListView1.selecteditems) {
            # inlezen geselecteerde items
            $inleesitem = $item[0].text
            # bepalen van map die gecontroleerd wordt
            $controleitem = -join ($selectie, '\', $inleesitem)

            # alleen weergeven als dit een bestand is
            if (( test-path -path "$controleitem" -pathtype container) -eq $false)  {
                # alleen bij de eerste item
                if ($eerste) {
                    $objtekst2.Text = $objtekst2.Text + "Bestanden :" + "`r`n"
                    $eerste = $false
                    }
                $objtekst2.Text = $objtekst2.Text + " - " + "$inleesitem" + "`r`n"
                }
            } # einde 2e for each item

        } # einde ($listview1.selecteditems.count -gt 0)
    } # einde ($taak -eq "kopiëren")

$uitvoeren.Form3.Controls.AddRange(@($Description2, $Description3, $voortgang, $StartButton, $EndButton, $Btnescape, $LogButton, $Label, $objtekst1, $objtekst2 ))

# Toevoegen gebruik van escapetoets.
# Function Add-EscapeClose kan hier niet gebruikt worden omdat deze niet in Runspace is gedefinieerd. Daarom wordt de code hier direct toegevoegd.
# Add-EscapeClose -Form $uitvoeren.Form3
$uitvoeren.Form3.Add_KeyDown({
    param($senderEscape, $e)
    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Escape) { 
    $senderEscape.Close()
    }
})
# zorgen dat speciale toetsen worden gedetecteerd.
$uitvoeren.Form3.KeyPreview = $true


$result = $uitvoeren.form3.ShowDialog()

$uitvoeren.Form3.dispose()

# Als knop Sluiten is ingedrukt dan terug naar hoofdmenu. Als knop Terug is ingedrukt dan terug naar keuzevenster van de taak.
if ($result -eq [system.windows.forms.dialogResult]::OK) { 
    $Form2.Close()
    $form.show()
    } elseif ($result -eq [system.windows.forms.dialogResult]::Cancel) {
    $form2.show()
    }

} # einde overzichttaken

function startknopklikbaar {
# deze functie wordt alleen gebruikt bij functie Vensterkopieren
# en bepaald of knoppen en items van vensterkopieren zichtbaar moeten zijn

# start knop
if (($global:listbox.selecteditems.count -gt 0) -and ($global:geselecteerdebronmap.count -ge 2)) {
    $Btnstart.Enabled= $true
} else {
    $Btnstart.Enabled= $false
}

} # einde startknopklikbaar

function InlezenSharePointMap {
<# inlezen gekozen map en in variabele plaatsen
 param $sharepointmap krijgt een waarde voor het geval het leeg wordt meegegeven
 Bij een fout wordt er alleen melding gemaakt in logboek.
 Wordt gebruikt bij Vensterkopieren. 
#>

param(
    [string]$sharepointmap = $global:beheer.examenmappen.digitalebestanden
    
    )

  try { 
  $Sharepointinhoud = Get-PnPFolderItem -FolderSiteRelativeUrl $sharepointmap  

  }
  catch {
  # melding loggen
  $melding = -join ("Inlezen SharePoint map ", $sharepointmap, "`n", $_.exception.message )
  Meldingnaarlogbestand -meldtekst $melding
  }
  return $Sharepointinhoud
}

function vensterkopieren { 

function toevoegen_listview1 ($toevoegitem, $type) {

if ($type -eq "Folder"){
        $extensienr = 0
    } elseif ($type -eq "File") {
        $extensienr = Bepaalextensienr $toevoegitem.name
    } else {
        $extensienr = 1
    }
[void] $listView1.Items.Add($toevoegitem.Name, $extensienr)
}

# function vensterkopieren begint hier

# gekozen locatie in makkelijke variabele plaatsen
$keuzelocatie=$global:init["algemeen"]["locatiekeuze"]
$digitalebestanden = $global:beheer.examenmappen.digitalebestanden

# lijst met geselecteerde examenmappen
$global:geselecteerdebronmap = [System.Collections.ArrayList]@()

if (!( ControleerverbindingSharePoint)) {
    return
}

# rpcnrs declareren met een function
$global:listBox = declareren_rpcnrs;
$global:listBox = lijstrpcnrsaanmaken $keuzelocatie $global:listBox 

# De hoofdmenu onzichtbaar maken
$form.Hide()

$Form2 = declareren_standaardvenster "Bestanden klaarzetten op de homemappen van de kandidaten" 920 660;

$Description2                     = New-Object system.Windows.Forms.Label
$Description2.text                = "RPC-nummers"
$Description2.AutoSize            = $false
$Description2.width               = 150
$Description2.height              = 20
$Description2.location            = New-Object System.Drawing.Point(20,15)
$Description2.Font                = 'Microsoft Sans Serif,11'
$Description2.ForeColor = [System.Drawing.Color]::Blue

$Description3                     = New-Object system.Windows.Forms.Label
$Description3.text                = "Locatie"
$Description3.AutoSize            = $false
$Description3.width               = 400
$Description3.height              = 42
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.location            = New-Object System.Drawing.Point(550,40)
$Description3.ForeColor = [System.Drawing.Color]::Blue

$Description4                     = New-Object system.Windows.Forms.Label
$Description4.text                = "Crebonummer"
$Description4.AutoSize            = $false
$Description4.width               = 400
$Description4.height              = 42
$Description4.Font                = 'Microsoft Sans Serif,11'
$Description4.location            = New-Object System.Drawing.Point(550,80)
$Description4.ForeColor = [System.Drawing.Color]::Blue

$Description5                     = New-Object system.Windows.Forms.Label
$Description5.text                = "Kerntaak"
$Description5.AutoSize            = $false
$Description5.width               = 400
$Description5.height              = 42
$Description5.Font                = 'Microsoft Sans Serif,11'
$Description5.location            = New-Object System.Drawing.Point(550,120)
$Description5.ForeColor = [System.Drawing.Color]::Blue

$Description8                     = New-Object system.Windows.Forms.Label
$Description8.text                = "Examen"
$Description8.AutoSize            = $false
$Description8.width               = 400
$Description8.height              = 42
$Description8.Font                = 'Microsoft Sans Serif,11'
$Description8.location            = New-Object System.Drawing.Point(550,160)
$Description8.ForeColor = [System.Drawing.Color]::Blue

$Btnstart = New-object System.Windows.Forms.Button 
$Btnstart.text= "Bevestigen"
$Btnstart.location = "50,570" 
$Btnstart.size = "150,30"  
$BtnStart.BackColor = 'green'
$BtnStart.ForeColor = 'white'
$Btnstart.Add_Click({ overzichttaken "kopiëren" }) 
$Btnstart.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bevestig je keuze en ga door naar het overzicht." )
})

$Btnescape = New-object System.Windows.Forms.Button 
$Btnescape.text= "Terug"
$Btnescape.location = "250,570" 
$Btnescape.size = "150,30"  
$Btnescape.BackColor = 'red'
$Btnescape.ForeColor = 'white'
$Btnescape.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$Btnescape.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})

$BtnOpnieuw                         = New-Object system.Windows.Forms.Button
$BtnOpnieuw.width                   = 40
$BtnOpnieuw.height                  = 40
$BtnOpnieuw.location                = New-Object System.Drawing.Point(150,200)
$BtnOpnieuw.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoontje-home.png")
$BtnOpnieuw.Add_Click({ 

      # array wordt leeggemaakt
      $geselecteerdebronmap.Clear()

      # selectie krijgt waarde van gekozen crebonummer
      $selectie = $digitalebestanden
      # inlezen gekozen map en in variabele plaatsen
      $folders = InlezenSharePointMap -sharepointmap $selectie

      # toevoegen aan venster
      $listView1.items.clear()
      foreach($folder in $folders){ 
            # toevoegen_listview1 $folder of File
            if ($folder.GetType().Name -eq "Folder") {
                toevoegen_listview1 $folder "Folder"
            } elseif ($folder.GetType().Name -eq "File") {
                toevoegen_listview1 $folder "File"
            }
        }  

      $listview1.SelectedItems.Clear()
      $listView1.AutoResizeColumns(1)

      # venster met inhoud map legen
      $listView2.items.clear()
      $objtekst2.Text = $Startexamenmap
      
      # dropdownmenu's leegmaken
      $lijstkerntaken.items.clear()
      $lijstexamens.items.clear()
      # selecties leegmaken. Verwijderen als de dropdownmenu's zijn verwijderd.
      $lijstcrebonrs.selectedindex = -1
      $lijstkerntaken.selectedindex = -1
      $lijstexamens.selectedindex = -1
      startknopklikbaar;
})
$BtnOpnieuw.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Alle keuzes wissen en opnieuw beginnen." )
})

$BtnTerug                         = New-Object system.Windows.Forms.Button
$BtnTerug.width                   = 40
$BtnTerug.height                  = 40
$BtnTerug.location                = New-Object System.Drawing.Point(150,245)
$BtnTerug.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoon-terug.png")
$BtnTerug.Add_Click({ 

    <# Deze if-statement werkt als er geen gebruik gemnaakt wordt van de dropdownmenu's. Als deze wel gebruikt worden, is de switch-statement voldoende.
     # verwijderen laatste item uit array met geselecteerde bronmap. als de array leeg is, gebeurt er niets.
    
     if ($geselecteerdebronmap.count -gt 0) {
        $verwijdernr=$geselecteerdebronmap.Count-1
        $geselecteerdebronmap.RemoveAt($verwijdernr)
        }
    #>
    switch ($geselecteerdebronmap.count) {
           "0" { # niets doen 
               }
           "1" { 
           #verwijder alles
           $geselecteerdebronmap.Clear()
           # dropdownmenu's leegmaken
           $lijstkerntaken.items.clear()
           $lijstexamens.items.clear()
           # selecties leegmaken
           $lijstcrebonrs.selectedindex = -1
           $lijstkerntaken.selectedindex = -1
           $lijstexamens.selectedindex = -1
               }
           "2" { 
           #verwijder de laatste
           $geselecteerdebronmap.RemoveAt(1)
           # dropdownmenu's leegmaken
           $lijstexamens.items.clear()
           # selecties leegmaken
           $lijstkerntaken.selectedindex = -1
           $lijstexamens.selectedindex = -1
               }
           "3" { 
           #verwijder de laatste
           $geselecteerdebronmap.RemoveAt(2)
           # selecties leegmaken
           $lijstexamens.selectedindex = -1
               }
           default { 
           $verwijdernr=$geselecteerdebronmap.Count-1
           $geselecteerdebronmap.RemoveAt($verwijdernr)
           }
    } # einde switch    
    
    # selectie krijgt waarde van startmap
    $selectie = $digitalebestanden

    # De huidige map weergeven bij venster geselecteerde examenmap.
    $objtekst2.Text = $Startexamenmap
    # toevoegen aan array en geselecteerde examenmap
    foreach ($item in $geselecteerdebronmap) {
            $selectie = -join ($selectie, '/', $item)
            # Toevoegen aan venster geselecteerde examenmap
           $objtekst2.Text = -join ($objtekst2.Text, $Scheidingstekst, $Item)
    } # einde foreach
    
    # inlezen gekozen map en in variabele plaatsen
    $folders = InlezenSharePointMap -sharepointmap $selectie

      # toevoegen aan venster
      $listView1.items.clear()
      foreach($folder in $folders){ 
            # toevoegen_listview1 $folder of File
            if ($folder.GetType().Name -eq "Folder") {
                toevoegen_listview1 $folder "Folder"
            } elseif ($folder.GetType().Name -eq "File") {
                toevoegen_listview1 $folder "File"
            }
        }  

    $listview1.SelectedItems.Clear()
    $listView1.AutoResizeColumns(1)

    # venster met inhoud map legen
    $listView2.items.clear()

    startknopklikbaar;
 }) # einde BtnTerug.add_click

$BtnTerug.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "De laatste keuze wissen en één stap terug." )
})

# listbox is al in het begin gedeclareerd. onderstaande waarden gelden voor deze functie.
$listBox.Location = New-Object System.Drawing.Point(10,40)
$listBox.Size = New-Object System.Drawing.Size(130,500)
$listBox.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$listBox.SelectionMode = 'MultiExtended'
$listBox.BackColor  = 'white'
$listBox.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer de RPC-nummers waar de bestanden naar toe worden overgezet." )
})


# bij aanklikken van een rpcnr, kijken of startknop weergegeven kan worden
$listbox.add_SelectedIndexChanged(
     { startknopklikbaar;
     } )

# Aanmaken van een imageList voor de icoontjes in de listview 
$imageList = Declareericoontjes

# Inhoud van de gekozen map in een listview weergeven.
$global:listView1 = New-Object System.Windows.Forms.ListView
$listView1.View = 'Details'
$listView1.Height = 278
$listView1.Width = 330
$listView1.Font = New-Object System.Drawing.Font("MS Sans Serif",12)
# zorgen dat selectie zichtbaar blijft.
$listview1.HideSelection = $false
 
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 200
$System_Drawing_Point.Y = 245
 
$listView1.Location = $System_Drawing_Point
$listView1.Name = "listView1"
$listView1.Sorting = 'Ascending'
$listView1.Columns.Add('Geselecteerde mappen en bestanden',600)| Out-Null
$listView1.SmallImageList = $imageList
$listView1.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer eventueel alleen de bestanden en mappen die je wilt overzetten. 
Klik op een map om de inhoud rechts weer te geven." )
})


# bij aanklikken van een map, inhoud weergeven in venster ernaast
$listView1.add_SelectedIndexChanged(
     { 
    # Controle of een item gevonden is. Anders wordt de muisklik en dus de code hieronder 2x uitgevoerd!
    if ($listView1.SelectedItems.Count -gt 0) {

     # selectie krijgt waarde van volledige pad naar gekozen map
     $selectie = $digitalebestanden
     foreach ($item in $geselecteerdebronmap) {
                $selectie = -join ($selectie, '/', $item)
          }
     $selectie = -join ($selectie, '/', $listView1.SelectedItems.text)

    # $folders = Get-PnPFolderItem -FolderSiteRelativeUrl $selectie
    $folders = InlezenSharePointMap -sharepointmap $selectie
     # alleen als 1 item is geselecteerd en de item moet een map zijn.

     if (( $listView1.selecteditems.count -eq 1) -and ($folders.count -gt 0) ) {
          # if ($folders.count -gt 0) {

          # tekstbox legen
          $listView2.items.clear()

          # weergeven inhoud in rechter venster, inhoud geselecteerde map
          # dan netjes in rijen plaatsen.
          foreach ($item in $folders) {
            if ($item.GetType().Name -eq "Folder") {
                $extensienr = 0
                [void] $listView2.Items.Add($item.name, $extensienr)
                
                } elseif ($item.GetType().Name -eq "File") {
                $extensienr = Bepaalextensienr $item.name
                [void] $listView2.Items.Add($item.name, $extensienr)
                } 
            }
          # aanpassen venster aan inhoud
          $listView2.AutoResizeColumns(1) 
          startknopklikbaar;

        } else {
          # venster met inhoud map legen
          $listView2.items.clear()
        } # einde if (( $listView1.selecteditems.count -eq 1) .. else ...
    }
    }
    )


# bij dubbelklikken van een map, map selecteren en openen
$listView1.add_doubleClick(
     {
     # selectie krijgt waarde van volledige pad naar gekozen map
     $selectie = $digitalebestanden
     foreach ($item in $geselecteerdebronmap) {
                $selectie = -join ($selectie, '/', $item)
                }
     $selectie = -join ($selectie, '/', $listView1.SelectedItems.text)
     
     $folders = InlezenSharePointMap -sharepointmap $selectie

     # alleen als de geselecteerde item een map is en inhoud heeft, wordt deze map geopend en weergegeven in het venster.
     if ($folders.count -gt 0) {
            # Toevoegen aan 1 vd dropdownmenu's.
            switch ($geselecteerdebronmap.count) {
                "0" { $lijstcrebonrs.selectedindex = $listView1.SelectedIndices[0] }
                "1" { $lijstkerntaken.selectedindex = $listView1.SelectedIndices[0] }
                "2" { $lijstexamens.selectedindex = $listView1.SelectedIndices[0] }
                default {
                    # venster met inhoud map legen
                    $listView2.items.clear()
                    # standaard tekst in venster met geselecteerd examenmap
                    $objtekst2.Text = $Startexamenmap
                    # toevoegen aan lijst geselecteerde mappen
                    $geselecteerdebronmap.Add($listView1.SelectedItems.text)
                    

                    # leegmaken huidige venster 
                    $listView1.items.clear()
                    # toevoegen aan geselecteerde examenmap
                    foreach ($item in $geselecteerdebronmap) {
                        $objtekst2.Text = -join ($objtekst2.Text, $Scheidingstekst, $Item)
                        }

                    # toevoegen aan venster
                    foreach($folder in $folders){ 
                        # toevoegen_listview1 $folder of File
                        if ($folder.GetType().Name -eq "Folder") {
                            toevoegen_listview1 $folder "Folder"
                            } elseif ($folder.GetType().Name -eq "File") {
                            toevoegen_listview1 $folder "File"
                            }
                    } # einde foreach($folder in $folders) 
                    # breedte listview1 aanpassen aan de inhoud
                    $listView1.AutoResizeColumns(1) 
                    startknopklikbaar;
                }
            } # einde switch ($geselecteerdebronmap.count)
                    
     }   # einde if ($folders.count -gt 0)
     } ) # einde listView1.add_doubleClick

$listView2 = New-Object System.Windows.Forms.ListView
$listView2.View = 'Details'
$listView2.Height = 278
$listView2.Width = 350
$listView2.Font = New-Object System.Drawing.Font("MS Sans Serif",12)
# zorgen dat selectie zichtbaar blijft.
$listview2.MultiSelect = $false
 
$System_Drawing_Point2 = New-Object System.Drawing.Point
$System_Drawing_Point2.X = 530
$System_Drawing_Point2.Y = 245
 
$listView2.Location = $System_Drawing_Point2
$listView2.Name = "listView2"
$listView2.Sorting = 'Ascending'
$listView2.Columns.Add('Inhoud geselecteerde examenmap',600)| Out-Null
# hieronder toch niet nodig. geeft geen effect.
# $listView1.AutoResizeColumns(1)
$listView2.SmallImageList = $imageList
$listView2.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Dit is de inhoud van de geselecteerde map." )
})

$listView2.add_SelectedIndexChanged( { 
  $listview2.SelectedItems.Clear()
  } )

# standaard tekst in venster met geselecteerd examenmap
$Startexamenmap = "Examenmap"
# Tekst tussen twee geselecteerde mappen, om deze uit elkaar te houden
$Scheidingstekst = " » "

$objtekst2 = New-Object System.Windows.Forms.textbox
$objtekst2.Location = New-Object System.Drawing.Size(200,200) 
$objtekst2.Size = New-Object System.Drawing.Size(680,47)
$objtekst2.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$objtekst2.Text = $Startexamenmap
$objtekst2.ReadOnly = $true
$objtekst2.Multiline = $true
$objtekst2.BackColor  = 'white'
$objtekst2.Forecolor  = 'blue'
$objtekst2.WordWrap = $true
$objtekst2.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Hier zie je de huidige geselecteerde examenmap." )
})

$Controlemappen = New-Object System.Windows.Forms.Checkbox 
$Controlemappen.Location = New-Object System.Drawing.Point(50,530)
$Controlemappen.Size = New-Object System.Drawing.Size(700,30)
$Controlemappen.Text = "Controleer of de homemappen van de kandidaten leeg zijn voordat bestanden worden overgezet."
$Controlemappen.Font = 'Microsoft Sans Serif,11'
$Controlemappen.ForeColor = [System.Drawing.Color]::green
$Controlemappen.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Geef aan of gecontroleerd moet worden of de homemappen van de kandidaten leeg zijn." )
})

if (($global:init["algemeen"]["controlevoorklaarzetten"]) -eq "Ja") {
    $Controlemappen.checked = $true
    } else {
    $Controlemappen.checked = $false
    }

# Standaard lijst met alle locaties maken, met standaardwaarden
$lijstlocaties = declarerenlijstlocaties $keuzelocatie 330 200 40


# bij wijzigen van selectie lijstlocaties
$lijstlocaties.add_SelectedIndexChanged(
     { 
     [string]$waarde = $lijstlocaties.selecteditem
     $keuzelocatie = $waarde.Substring(0,3)

     # nieuwe rpcnrs declareren
     $global:listBox = lijstrpcnrsaanmaken $keuzelocatie $global:listBox 
     # startknop niet klikbaar maken
     startknopklikbaar;
     } ) 

$lijstcrebonrs                     = New-Object system.Windows.Forms.ComboBox
$lijstcrebonrs.text                = "Crebonummer"
$lijstcrebonrs.width               = 330
$lijstcrebonrs.autosize            = $true
$lijstcrebonrs.Location = New-Object System.Drawing.Size(200,80) 
$lijstcrebonrs.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$lijstcrebonrs.DropDownStyle="DropDownList"
$lijstcrebonrs.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer de crebonummer." )
})

# inhoud map in de lijst met geselecteerde mappen zetten 
# in het begin zijn het alleen maar folders, daarom de toevoeging -ItemType Folder 
$selectie = $digitalebestanden
$folders = InlezenSharePointMap -sharepointmap $selectie

foreach($folder in $folders){ 
    # toevoegen_listview1 $folder of File aan de lijst met geselecteerde mappen en de dropdownmenu voor crebonummers
    if ($folder.GetType().Name -eq "Folder") {
        toevoegen_listview1 $folder "Folder"
        $lijstcrebonrs.Items.Add($folder.name)
    } elseif ($folder.GetType().Name -eq "File") {
        toevoegen_listview1 $folder "File"
    }
}  

# breedte listview1 aanpassen aan de inhoud
$listView1.AutoResizeColumns(1) 

# uitvoeren als selectie van crebonummer wijzigt
$lijstcrebonrs.add_SelectedIndexChanged(
     { 
      
    # alleen als er geselecteerd is 
    if ($lijstcrebonrs.SelectedIndex -ge 0) {
        # venster met inhoud map legen
        $listView2.items.clear()

        <# toevoegen aan lijst geselecteerde mappen
           array wordt leeggemaakt omdat je inhoud geeft aan de 1e item aan de array "geselecteerdebronmap"
        #>
        $geselecteerdebronmap.Clear()

        # leegmaken huidige venster en dropdownmenu's
        $listView1.items.clear()
        $lijstkerntaken.items.clear()
        $lijstexamens.items.clear()
        $objtekst2.Text = $Startexamenmap

        # selectie krijgt waarde van gekozen crebonummer
        $selectie = -join ($digitalebestanden, '/', $lijstcrebonrs.SelectedItem)
        
        # toevoegen aan lijst geselecteerde mappen 
        $geselecteerdebronmap.Add($lijstcrebonrs.SelectedItem)
        # Toevoegen aan geselecteerde examenmap
        $objtekst2.Text = -join ($objtekst2.Text, $Scheidingstekst, $lijstcrebonrs.SelectedItem)

        # inlezen gekozen map en in variabele plaatsen
        $folders = InlezenSharePointMap -sharepointmap $selectie
        foreach($folder in $folders){ 
            # toevoegen_listview1 $folder of File aan de lijst met geselecteerde mappen en de dropdownmenu voor crebonummers
                if ($folder.GetType().Name -eq "Folder") {
                    toevoegen_listview1 $folder "Folder"
                    $lijstkerntaken.Items.Add($folder.name)
                } elseif ($folder.GetType().Name -eq "File") {
                    toevoegen_listview1 $folder "File"
                }
            }
            
        # breedte listview1 aanpassen aan de inhoud
        $listView1.AutoResizeColumns(1)

    startknopklikbaar;
    } else { 
       $lijstcrebonrs.selectedindex = -1
    } 
     # einde ($lijstkerntaken.SelectedIndex -ge 0) .. else
     } )


$lijstkerntaken                     = New-Object system.Windows.Forms.ComboBox
$lijstkerntaken.text                = "Kerntaak"
$lijstkerntaken.width               = 330
$lijstkerntaken.autosize            = $true
$lijstkerntaken.Location = New-Object System.Drawing.Size(200,120) 
$lijstkerntaken.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$lijstkerntaken.DropDownStyle="DropDownList"
$lijstkerntaken.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer de kerntaak." )
})


# uitvoeren als selectie van kerntaken wijzigt
 $lijstkerntaken.add_SelectedIndexChanged(
    {
      

      if ($lijstkerntaken.SelectedIndex -ge 0) {

        # venster met inhoud map legen
        $listView2.items.clear()

        # leegmaken huidige venster en dropdownmenu's
        $listView1.items.clear()
        $lijstexamens.items.clear()
        $objtekst2.Text = $Startexamenmap

        <# controleren of een aantal geselecteerde mappen verwijderd moeten worden. Dit komt voor als je al mappen hebt geselecteerd en terug gaat.
           verwvanaf =1 omdat hiermee de 2e item in de array wordt aangesproken
        #>
        $verwvanaf = 1
        [int] $aantal = $geselecteerdebronmap.count -$verwvanaf
        if ($geselecteerdebronmap.count -gt $verwvanaf) { $geselecteerdebronmap.RemoveRange($verwvanaf,$aantal) }

        # selectie krijgt waarde van gekozen kerntaak
        $selectie = -join ($digitalebestanden, '\', $geselecteerdebronmap[0], '\', $lijstkerntaken.SelectedItem)

        # Toevoegen aan geselecteerde examenmap
        $objtekst2.Text = -join ($objtekst2.Text, $Scheidingstekst, $geselecteerdebronmap[0])

        # inlezen gekozen map en in variabele plaatsen
        $folders = InlezenSharePointMap -sharepointmap $selectie
        foreach($folder in $folders){ 
            # toevoegen_listview1 $folder of File aan de lijst met geselecteerde mappen en de dropdownmenu voor examennummers
                if ($folder.GetType().Name -eq "Folder") {
                    toevoegen_listview1 $folder "Folder"
                    $lijstexamens.Items.Add($folder.name)
                } elseif ($folder.GetType().Name -eq "File") {
                    toevoegen_listview1 $folder "File"
                }
            }

        # en dan nu pas toevoegen
        $geselecteerdebronmap.Add($lijstkerntaken.SelectedItem)
        
        # Toevoegen aan geselecteerde examenmap
        $objtekst2.Text = -join ($objtekst2.Text, $Scheidingstekst, $lijstkerntaken.SelectedItem)

        # breedte listview1 aanpassen aan de inhoud
        $listView1.AutoResizeColumns(1)
        startknopklikbaar;
    } # einde ($lijstkerntaken.SelectedIndex -ge 0)
    } )

$lijstexamens                     = New-Object system.Windows.Forms.ComboBox
$lijstexamens.text                = "Examen"
$lijstexamens.width               = 330
$lijstexamens.autosize            = $true
$lijstexamens.Location = New-Object System.Drawing.Size(200,160) 
$lijstexamens.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$lijstexamens.DropDownStyle="DropDownList"
$lijstexamens.Name =  "Kies een examen"
$lijstexamens.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer het examen." )
})


# uitvoeren als selectie van examens wijzigt
$lijstexamens.add_SelectedIndexChanged(
    {
      if ($lijstexamens.SelectedIndex -ge 0) {
      
        # venster met inhoud map legen
        $listView2.items.clear()

        # leegmaken huidige vensters
        $listView1.items.clear()
        $objtekst2.Text = $Startexamenmap

        <# controleren of een aantal geselecteerde mappen verwijderd moeten worden. Dit komt voor als je al mappen hebt geselecteerd en terug gaat.
           verwvanaf = 2 omdat hiermee de 3e item in de array wordt aangesproken.
        #>
        $verwvanaf = 2
        [int] $aantal = $geselecteerdebronmap.count -$verwvanaf
        if ($geselecteerdebronmap.count -gt $verwvanaf) { $geselecteerdebronmap.RemoveRange($verwvanaf,$aantal) }

        # selectie krijgt waarde van gekozen examen
        $selectie = -join ($digitalebestanden, '\', $geselecteerdebronmap[0], '\', $geselecteerdebronmap[1], '\', $lijstexamens.SelectedItem)

        # Toevoegen aan geselecteerde examenmap
        $objtekst2.Text = -join ($objtekst2.Text, $Scheidingstekst, $geselecteerdebronmap[0], $Scheidingstekst, $geselecteerdebronmap[1])

        # inlezen gekozen map en in variabele plaatsen
        $folders = InlezenSharePointMap -sharepointmap $selectie
        foreach($folder in $folders){ 
            # toevoegen_listview1 $folder of File aan de lijst met geselecteerde mappen
                if ($folder.GetType().Name -eq "Folder") {
                    toevoegen_listview1 $folder "Folder"
                } elseif ($folder.GetType().Name -eq "File") {
                    toevoegen_listview1 $folder "File"
                }
            }

        # en dan nu pas toevoegen
        $geselecteerdebronmap.Add($lijstexamens.SelectedItem)

        # Toevoegen aan geselecteerde examenmap
        $objtekst2.Text = -join ($objtekst2.Text, $Scheidingstekst, $lijstexamens.SelectedItem)

        # breedte listview1 aanpassen aan de inhoud
        $listView1.AutoResizeColumns(1)
        startknopklikbaar;
    }  # einde if ($lijstexamens.SelectedIndex -ge 0)
    } )

# venster met uitleg over deze taak wordt gedeclareerd. hieronder worden enkele variabelen aangepast aan deze taakvenster
declareren_uitlegvenster "Uitleg over de taak Bestanden klaarzetten." 690 340 520 570 "Hier kunt u bestanden klaarzetten op de homemappen, of RPC-nummers, van de kandidaten.
In het linkerkolom selecteert u de RPC-nummers waar de bestanden naar toe worden overgezet.
In het midden selecteert u de locatie, crebonummer, kerntaak en examen.

U kunt ook 'door de mappen bladeren' door dubbel te klikken op een map in het middelste kolom.
Met het terug-icoontje gaat u een map terug.
Met het home-icoontje gaat u terug naar het begin.

Eventueel kunt u ervoor kiezen om alleen enkele mappen over te zetten.
Hiertoe moet u in het vakje onderaan deze bestanden of mappen selecteren, 
met een enkele muisklik of met de CTRL-toets in combinatie met een muisklik.

Als u op een map klikt in het vakje onderaan wordt de inhoud hiervan rechts weergegeven.

Om naar het overzicht te gaan waar u het overzetten kan starten moet u op Bevestigen klikken.
"

startknopklikbaar;

$Form2.controls.AddRange(@($listBox, $lijstlocaties, $lijstcrebonrs, $lijstkerntaken, $lijstexamens, $objtekst2, $BtnOpnieuw, $BtnTerug, 
$listview1, $listView2, $Btnstart, $Btnescape, $Controlemappen, $Description2,
$Description3, $Description4, $Description5, $Description8, $Global:vraagtekenicoon ))

# toevoegen van escape key functionaliteit aan het venster, zodat deze ook met de escape key gesloten kan worden.
Add-EscapeClose -Form $form2

# venster tonen
$null = $form2.ShowDialog()
    
$form2.close();
# $form2.hide();

# De hoofdmenu zichtbaar maken
$form.show()

} # einde vensterkopieren

function vensterbackup {
# taak backuppen begint hier

# variabelen
$keuzelocatie=$global:init["algemeen"]["locatiekeuze"]

# De hoofdmenu onzichtbaar maken
$form.Hide()

# rpcnrs declareren met een function
$global:listBox = declareren_rpcnrs;
$global:listBox = lijstrpcnrsaanmaken $keuzelocatie $global:listBox 

# venster declareren
$Form2 = declareren_standaardvenster "Back-up maken van de homemappen" 480 680

$Description3                     = New-Object system.Windows.Forms.Label
$Description3.text                = "Locatie"
$Description3.AutoSize            = $false
$Description3.width               = 800
$Description3.height              = 40
$Description3.location            = New-Object System.Drawing.Point(290,15)
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.ForeColor = [System.Drawing.Color]::Blue

$Description4                     = New-Object system.Windows.Forms.Label
$Description4.text                = "RPC-nummers"
$Description4.AutoSize            = $false
$Description4.width               = 800
$Description4.height              = 40
$Description4.location            = New-Object System.Drawing.Point(290,55)
$Description4.Font                = 'Microsoft Sans Serif,11'
$Description4.ForeColor = [System.Drawing.Color]::Blue

$Btnstart = New-object System.Windows.Forms.Button 
$Btnstart.text= "Bevestigen"
$Btnstart.location = "50,570" 
$Btnstart.size = "150,30"
$BtnStart.BackColor = 'green'
$BtnStart.ForeColor = 'white'
$Btnstart.Add_Click({ overzichttaken "backup" }) 
$Btnstart.Enabled= $false
$Btnstart.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bevestig je keuze en ga door naar het overzicht." )
})

$Btnescape = New-object System.Windows.Forms.Button 
$Btnescape.text= "Terug"
$Btnescape.location = "250,570" 
$Btnescape.size = "150,30"  
$Btnescape.BackColor = 'red'
$Btnescape.ForeColor = 'white'
$Btnescape.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$Btnescape.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})

# listbox is in het begin al gedeclareerd.
$listBox.Location = New-Object System.Drawing.Point(10,55)
$listBox.Size = New-Object System.Drawing.Size(260,20)
$listBox.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$listBox.SelectionMode = 'MultiExtended'
$listBox.Height = 475
$listBox.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer de RPC-nummers waarvan de back-up wordt gemaakt." )
})

# start knop zichtbaar of niet
$listbox.add_SelectedIndexChanged(
     { 
     if ($listbox.selecteditems.count -gt 0) {
        $Btnstart.Enabled= $true
        } else {
        $Btnstart.Enabled= $false
        }
    } )

$wissennabackup = New-Object System.Windows.Forms.Checkbox 
$wissennabackup.Location = New-Object System.Drawing.Point(50,530)
$wissennabackup.Size = New-Object System.Drawing.Size(300,30)
$wissennabackup.Text = "Bestanden na de back-up ook wissen"
$wissennabackup.Font = 'Microsoft Sans Serif,11'
$wissennabackup.ForeColor = [System.Drawing.Color]::green
$wissennabackup.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Geef aan of de homemappen van de kandidaten na de bac-kup worden gewist." )
})

if (($global:init["algemeen"]["wissennabackup"]) -eq "Ja") {
    $wissennabackup.checked = $true
    } else {
    $wissennabackup.checked = $false
    }

# Standaard lijst met alle locaties maken, met standaardwaarden
$lijstlocaties = declarerenlijstlocaties $keuzelocatie 260 10 15


# bij wijzigen van selectie lijstlocaties
$lijstlocaties.add_SelectedIndexChanged(
     { 
     [string]$waarde = $lijstlocaties.selecteditem
     $keuzelocatie = $waarde.Substring(0,3)

     # nieuwe rpcnrs declareren
     $global:listBox = lijstrpcnrsaanmaken $keuzelocatie $global:listBox 
     # startknop niet klikbaar maken
     $Btnstart.Enabled= $false
     } ) 

# venster met uitleg over deze taak wordt gedeclareerd. hieronder worden enkele variabelen aangepast aan deze taakvenster
declareren_uitlegvenster "Uitleg over de taak Back-up maken." 730 230 420 580 "Hier kunt u een back-up maken van de geselecteerde homemappen van de kandidaten.
Bovenaan kunt u de locatie en daaronder de homemappen, of RPC-nummers, selecteren.

Standaard wordt na de back-up de homemappen van de kandidaten gewist.
Als u dit niet wilt moet u het vinkje bij de bijbehorende tekst onderaan weghalen.

Om naar het overzicht te gaan waar u de back-up kan starten moet u op Bevestigen klikken.
"

$form2.controls.AddRange(@($lijstlocaties, $listBox, $Btnstart, $Btnescape, $wissennabackup, $Description3, $Description4, $Global:vraagtekenicoon ))

# toevoegen van escape key functionaliteit aan het venster, zodat deze ook met de escape key gesloten kan worden.
Add-EscapeClose -Form $form2

$null = $form2.ShowDialog()
    
$form2.close();

# De hoofdmvenster zichtbaar maken
$form.show()
} # einde vensterbackup

function vensterwissen {
# taak wissen begint hier

# variabelen
$keuzelocatie=$global:init["algemeen"]["locatiekeuze"]

# De hoofdmenu onzichtbaar maken
$form.Hide()

# rpcnrs declareren met een function
$global:listBox = declareren_rpcnrs;
$global:listBox = lijstrpcnrsaanmaken $keuzelocatie $global:listBox 

# venster declareren
$Form2 = declareren_standaardvenster "Wissen van homemappen van de kandidaten" 480 640;

$Description3                     = New-Object system.Windows.Forms.Label
$Description3.text                = "Locatie"
$Description3.AutoSize            = $false
$Description3.width               = 800
$Description3.height              = 40
$Description3.location            = New-Object System.Drawing.Point(290,15)
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.ForeColor = [System.Drawing.Color]::Blue

$Description4                     = New-Object system.Windows.Forms.Label
$Description4.text                = "RPC-nummers"
$Description4.AutoSize            = $false
$Description4.width               = 800
$Description4.height              = 40
$Description4.location            = New-Object System.Drawing.Point(290,55)
$Description4.Font                = 'Microsoft Sans Serif,11'
$Description4.ForeColor = [System.Drawing.Color]::Blue


$Btnstart = New-object System.Windows.Forms.Button 
$Btnstart.text= "Bevestigen"
$Btnstart.location = "50,540" 
$Btnstart.size = "150,30"  
$BtnStart.BackColor = 'green'
$BtnStart.ForeColor = 'white'
$Btnstart.Add_Click({ overzichttaken "wissen" }) 
$Btnstart.Enabled= $false
$Btnstart.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bevestig je keuze en ga door naar het overzicht." )
})

$Btnescape = New-object System.Windows.Forms.Button 
$Btnescape.text= "Terug"
$Btnescape.location = "250,540" 
$Btnescape.size = "150,30"  
$Btnescape.BackColor = 'red'
$Btnescape.ForeColor = 'white'
$Btnescape.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$form2.cancelbutton = $Btnescape
$Btnescape.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})


# listbox is in het begin al gedeclareerd.
$listBox.Location = New-Object System.Drawing.Point(10,55)
$listBox.Size = New-Object System.Drawing.Size(260,20)
$listBox.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$listBox.SelectionMode = 'MultiExtended'
$listBox.Height = 475
$listBox.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer de RPC-nummers waarvan de back-up wordt gemaakt." )
})

# start knop zichtbaar of niet
$listbox.add_SelectedIndexChanged(
     { 
     if ($listbox.selecteditems.count -gt 0) {
        $Btnstart.Enabled= $true
        } else {
        $Btnstart.Enabled= $false
        }
    } )

# Standaard lijst met alle locaties maken, met standaardwaarden
$lijstlocaties = declarerenlijstlocaties $keuzelocatie 260 10 15

# bij wijzigen van selectie lijstlocaties
$lijstlocaties.add_SelectedIndexChanged(
     { 
     [string]$waarde = $lijstlocaties.selecteditem
     $keuzelocatie = $waarde.Substring(0,3)

     # nieuwe rpcnrs declareren
     $global:listBox = lijstrpcnrsaanmaken $keuzelocatie $global:listBox 
     # startknop niet klikbaar maken
     $Btnstart.Enabled= $false
     } ) 

# venster met uitleg over deze taak wordt gedeclareerd. hieronder worden enkele variabelen aangepast aan deze taakvenster
declareren_uitlegvenster "Uitleg over de taak Wissen." 690 180 430 550 "Hier kunt u bestanden van de geselecteerde RPC-nummers verwijderen.
Bovenaan kunt u de locatie en daaronder de RPC-nummers die verwijderd moet worden, selecteren.

Om naar het overzicht te gaan waar u het verwijderen kan starten moet u op Bevestigen klikken.
"

$form2.controls.AddRange(@($lijstlocaties, $listBox, $Btnstart, $Btnescape, $Description3, $Description4, $Global:vraagtekenicoon))

Add-EscapeClose -Form $form2

$null = $form2.ShowDialog()
    
$form2.close();

# De hoofdvenster zichtbaar maken
$form.show()
} # einde vensterwissen

function vensterverplaatsen {
# taak verplaatsen van bestanden begint hier

# variabelen
$keuzelocatie=$global:init["algemeen"]["locatiekeuze"]
$keuzedoelmaplegen


# De hoofdmenu onzichtbaar maken
$form.Hide()

# venster declareren
$Form2 = declareren_standaardvenster "Verplaatsen of kopiëren van bestanden" 550 380;

$Description2                     = New-Object system.Windows.Forms.Label
$Description2.text                = "Bron"
$Description2.AutoSize            = $false
$Description2.width               = 150
$Description2.height              = 50
$Description2.location            = New-Object System.Drawing.Point(300,120)
$Description2.Font                = 'Microsoft Sans Serif,11'
$Description2.ForeColor = [System.Drawing.Color]::Blue

$Description3                     = New-Object system.Windows.Forms.Label
$Description3.text                = "Doel"
$Description3.AutoSize            = $false
$Description3.width               = 150
$Description3.height              = 50
$Description3.location            = New-Object System.Drawing.Point(300,170)
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.ForeColor = [System.Drawing.Color]::Blue

$Description5                     = New-Object system.Windows.Forms.Label
$Description5.text                = "Locatie"
$Description5.AutoSize            = $false
$Description5.width               = 300
$Description5.height              = 42
$Description5.Font                = 'Microsoft Sans Serif,11'
$Description5.location            = New-Object System.Drawing.Point(300,20)
$Description5.ForeColor = [System.Drawing.Color]::Blue

$Description6                     = New-Object system.Windows.Forms.Label
$Description6.text                = "Taak"
$Description6.AutoSize            = $false
$Description6.width               = 300
$Description6.height              = 42
$Description6.Font                = 'Microsoft Sans Serif,11'
$Description6.location            = New-Object System.Drawing.Point(300,70)
$Description6.ForeColor = [System.Drawing.Color]::Blue

$Btnstart = New-object System.Windows.Forms.Button 
$Btnstart.text= "Bevestigen"
$Btnstart.location = "50,270" 
$Btnstart.size = "150,30"  
$BtnStart.BackColor = 'green'
$BtnStart.ForeColor = 'white'
$Btnstart.Add_Click({ overzichttaken "verplaatsen" }) 
$Btnstart.Enabled= $false
$Btnstart.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bevestig je keuze en ga door naar het overzicht." )
})

$Btnescape = New-object System.Windows.Forms.Button 
$Btnescape.text= "Terug"
$Btnescape.location = "250,270" 
$Btnescape.size = "150,30"  
$Btnescape.BackColor = 'red'
$Btnescape.ForeColor = 'white'
$Btnescape.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$Btnescape.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})
$form2.cancelbutton = $Btnescape

# de selectie vd de bron
$bronselectie                     = New-Object system.Windows.Forms.ComboBox
$bronselectie.width               = 260
$bronselectie.autosize            = $true
$bronselectie.DropDownStyle       = "DropDownList"
$bronselectie.Font                = 'Microsoft Sans Serif,12'
$bronselectie.location = "20,120" 
$bronselectie.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer het rpc-nummer met de bronbestanden." )
})
$bronselectie = lijstrpcnrsaanmaken $keuzelocatie $bronselectie

#  de selectie vd de doel rpc-nummer 
$doelselectie                     = New-Object system.Windows.Forms.ComboBox
$doelselectie.width               = 260
$doelselectie.autosize            = $true
$doelselectie.DropDownStyle       = "DropDownList"
$doelselectie.Font                = 'Microsoft Sans Serif,12'
$doelselectie.location = "20,170" 
$doelselectie.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer het rpc-nummer waar de bestanden naar toe moeten." )
})
$doelselectie = lijstrpcnrsaanmaken $keuzelocatie $doelselectie

#  de keuze vd taak
$keuzeoptie1                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie1.width               = 260
$keuzeoptie1.autosize            = $true
$keuzeoptie1.DropDownStyle       = "DropDownList"
$keuzeoptie1.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie1.location = "20,70" 
[void] $keuzeoptie1.Items.Add("Verplaatsen")
[void] $keuzeoptie1.Items.Add("Kopiëren")
$keuzeoptie1.Selectedindex = 0
$keuzeoptie1.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer de uit te voeren taak." )
})


$doelselectie.add_SelectedIndexChanged(
     { 
    # kijken of dezelfde selectie is gemaakt en zo ja, opheffen
    if ($doelselectie.selecteditem -eq $bronselectie.selecteditem) { 
        $doelselectie.selecteditem = $null
        }
    # kijken of startknop zichtbaar mag zijn
    if (($null -ne $doelselectie.selecteditem) -and ($null -ne $bronselectie.selecteditem)) {
        $Btnstart.Enabled= $true
        } else {
        $Btnstart.Enabled= $false
        }  
    } )

$bronselectie.add_SelectedIndexChanged(
     { 
    # kijken of dezelfde selectie is gemaakt en zo ja, opheffen
    if ($doelselectie.selecteditem -eq $bronselectie.selecteditem) { 
        $bronselectie.selecteditem = $null
        }
    # kijken of startknop zichtbaar mag zijn
     if (($null -ne $doelselectie.selecteditem) -and ($null -ne $bronselectie.selecteditem)) {
        $Btnstart.Enabled= $true
        } else {
        $Btnstart.Enabled= $false
        }  
    } )

# Standaard lijst met alle locaties maken, met standaardwaarden
$lijstlocaties = declarerenlijstlocaties $keuzelocatie 260 20 20


# bij wijzigen van selectie lijstlocaties
$lijstlocaties.add_SelectedIndexChanged(
     { 
     [string]$waarde = $lijstlocaties.selecteditem
     $keuzelocatie = $waarde.Substring(0,3)

     # nieuwe rpcnrs declareren
     $bronselectie = lijstrpcnrsaanmaken $keuzelocatie $bronselectie
     $doelselectie = lijstrpcnrsaanmaken $keuzelocatie $doelselectie

     # selectie van bron en doel ophefen
     $doelselectie.selecteditem = $null
     $bronselectie.selecteditem = $null

     # startknop niet klikbaar maken
     $Btnstart.Enabled= $false
     } ) 

$doelmaplegen = New-Object System.Windows.Forms.Checkbox 
$doelmaplegen.Location = New-Object System.Drawing.Point(20,220)
$doelmaplegen.Size = New-Object System.Drawing.Size(500,30)
$doelmaplegen.Text = "Doelmap wissen alvorens het verplaatsen of kopiëren."
$doelmaplegen.Font = 'Microsoft Sans Serif,12'
$doelmaplegen.ForeColor = [System.Drawing.Color]::Green
if ($keuzedoelmaplegen -eq "Ja") {
    $doelmaplegen.Checked = $true
    } else {
    $doelmaplegen.Checked = $false
    }
$doelmaplegen.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Geef aan of de doelmap geleegd moet worden voor het uitvoeren van de taak." )
})

# venster met uitleg over deze taak wordt gedeclareerd. hieronder worden enkele variabelen aangepast aan deze taakvenster
declareren_uitlegvenster "Uitleg over de taak Verplaatsen of kopiëren." 680 280 460 290 "Hier kunt u bestanden van een RPC-nummer verplaatsten of kopiëren naar een andere RPC-nummer.

Geef aan in welke RPC-nummer de bestanden staan, dit is de bron. 
Dan naar welke RPC-nummer de bestanden worden gekopiëerd, dat is het doel. 
Eventueel kan de locatie of taak nog worden aangepast.

Als Doelmap legen voor het verplaatsen of kopiëren is aangevinkt zal de inhoud van de doelmap 
gewist worden voor het verplaatsen of kopiëren.

Om naar het overzicht te gaan waar u het verplaatsen kan starten moet u op Bevestigen klikken."

$form2.controls.AddRange(@($lijstlocaties, $keuzeoptie1, $bronselectie, $doelselectie, $doelmaplegen, $Btnstart, $Btnescape, $Description2, 
$Description3, $Description4, $Description5, $Description6, $Global:vraagtekenicoon ))

Add-EscapeClose -Form $form2;

$null = $form2.ShowDialog()
    
$form2.close();

# De hoofdmvenster zichtbaar maken
$form.show()
} # einde vensterverplaatsen


function vensterlogbestand {

function bepaaldatumuitlognaam ($invoer)
{
<# Uit de invoer wordt de datum bepaald. De format hiervoor staat in functie "bepaallognaam".
  Een wijziging in deze functie moet hier ook worden toegepast.
#>
$jaar = $invoer.substring(4, 4)
$maand = $invoer.substring(9, 2)
$dag = $invoer.substring(12, 2)
$datumintekst = -join ($dag,'-',$maand,'-',$jaar)
return $datumintekst
} # einde bepaaldatumuitlognaam

function Inlezenlogs { 

# De logbestanden worden ingelezen en met een try-catch methode de fouten opgevangen
try {
$uitvoer = Get-ChildItem -Path $weertegevenlogs -Name -ErrorAction Stop
return $uitvoer
}
catch {
      $melding = -join ("Taak logbestanden bekijken is gestart : ", "`n", $_.exception.message )
      Meldingnaarlogbestand -meldtekst $melding
}
} # einde function Inlezenlogs

# function vensterlogbestand bekijken begint hier

# Deze variabele bepaalt de "weer te geven logbestanden". Dit is is een function geplaatst om op 1 plek veranderingen door te voeren.
$weertegevenlogs = bepaaleigenlogbestanden

# controle of er logbestanden zijn
if (!(Test-Path -Path $weertegevenlogs)) {
    $null = venstermetvraag -titel "Geen logbestanden" -vraag "`r`nEr zijn geen logbestanden om te tonen."
    return;
    }

# De hoofdmenu onzichtbaar maken
$form.Hide()

# venster declareren
$Form2 = declareren_standaardvenster "Logbestanden bekijken" 1060 670

$Description2                     = New-Object system.Windows.Forms.Label
$Description2.text                = "Filter op jaar"
$Description2.AutoSize            = $false
$Description2.width               = 100
$Description2.height              = 42
$Description2.location            = New-Object System.Drawing.Point(20,18)
$Description2.Font                = 'Microsoft Sans Serif,11'
$Description2.ForeColor = [System.Drawing.Color]::Blue

$Description3                     = New-Object system.Windows.Forms.Label
$Description3.text                = "en op maand"
$Description3.AutoSize            = $false
$Description3.width               = 100
$Description3.height              = 42
$Description3.location            = New-Object System.Drawing.Point(210,18)
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.ForeColor = [System.Drawing.Color]::Blue

$Description4                     = New-Object system.Windows.Forms.Label
$Description4.text                = "Logbestanden"
$Description4.AutoSize            = $false
$Description4.width               = 120
$Description4.height              = 20
$Description4.location            = New-Object System.Drawing.Point(20,65)
$Description4.Font                = 'Microsoft Sans Serif,11'
$Description4.ForeColor = [System.Drawing.Color]::Blue

$Description5                     = New-Object system.Windows.Forms.Label
$Description5.text                = "Inhoud van geselecteerde logbestand"
$Description5.AutoSize            = $false
$Description5.width               = 280
$Description5.height              = 20
$Description5.location            = New-Object System.Drawing.Point(160,65)
$Description5.Font                = 'Microsoft Sans Serif,11'
$Description5.ForeColor = [System.Drawing.Color]::Blue

$filterjaar                     = New-Object system.Windows.Forms.ComboBox
$filterjaar.width               = 70
$filterjaar.autosize            = $true
$filterjaar.DropDownStyle       = "DropDownList"
$filterjaar.Font                = 'Microsoft Sans Serif,12'
$filterjaar.location = "120,15" 
# vullen met jaren
for ($i=2025; $i -le 2040; $i++) {
    [void] $filterjaar.Items.Add($i)
}
$filterjaar.add_SelectedIndexChanged({
    $filtermaand.Enabled = $true
    $filtermaand.selecteditem = $null
    $listbox2.Items.clear()

    # Inlezen logs en in array plaatsen
    Inlezenlogs | Sort-Object -Descending | ForEach-Object {
        $datumlog = bepaaldatumuitlognaam "$_"
        #test
        # Write-Host "filterjaar: $($filterjaar.selecteditem) - datumlog: $datumlog"

        if ($datumlog -like "*$($filterjaar.SelectedItem)*") { 
            [void] $listbox2.Items.Add($datumlog)
        }
    }
    if ($listbox2.Items.count -gt 0) { $listBox2.SelectedIndex = 0 }
        else { $objtekst1.Text = "" }
})
$filterjaar.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Toon alleen de logbestanden van het geselecteerde jaar." )
})

$filtermaand                     = New-Object system.Windows.Forms.ComboBox
$filtermaand.width               = 50
$filtermaand.autosize            = $true
$filtermaand.DropDownStyle       = "DropDownList"
$filtermaand.Font                = 'Microsoft Sans Serif,12'
$filtermaand.location = "320,15" 
$filtermaand.Enabled = $false
# vullen met maanden
for ($i=01; $i -le 12; $i++) {
    if ($i -lt 10) {
        [void] $filtermaand.Items.Add("0$i")
        } else {
        [void] $filtermaand.Items.Add("$i")
        }
}
$filtermaand.add_SelectedIndexChanged({
    $listbox2.Items.clear()
    # bepaal de te filteren maand en jaar
    $filter = "$($filtermaand.SelectedItem)-$($filterjaar.SelectedItem)"
    Inlezenlogs | Sort-Object -Descending | ForEach-Object {
        $datumlog = bepaaldatumuitlognaam "$_"
        if ($datumlog -like "*$filter*") { 
            [void] $listbox2.Items.Add($datumlog)
        }
    }
    if ($listbox2.Items.count -gt 0) { $listBox2.SelectedIndex = 0 }
        else { $objtekst1.Text = "" }
})
$filtermaand.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Toon alleen de logbestanden van de geselecteerde maand." )
})

$filterwissen = New-object System.Windows.Forms.Button 
$filterwissen.text= "Filters wissen"
$filterwissen.location = "400,15" 
$filterwissen.size = "150,30"  
$filterwissen.BackColor = 'blue'
$filterwissen.ForeColor = 'white'
$filterwissen.add_click({
    
    $filtermaand.selecteditem = $null
    $filterjaar.selecteditem = $null
    $filtermaand.Enabled = $false

    $listbox2.Items.clear()
    Inlezenlogs | Sort-Object -Descending | ForEach-Object {
    $datumlog = bepaaldatumuitlognaam "$_"
    [void] $listbox2.Items.Add($datumlog)        
    }
    # eerste logbestand is geselecteerd.
    $listBox2.SelectedIndex = 0
})
$filterwissen.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Wis alle filters en laat alle logbestanden weer zien." )
})

$Buttenok = New-object System.Windows.Forms.Button 
$Buttenok.text= "Terug"
$Buttenok.location = "50,590" 
$Buttenok.size = "150,30"  
$Buttenok.BackColor = 'red'
$Buttenok.ForeColor = 'white'
$Buttenok.DialogResult = [System.Windows.Forms.DialogResult]::ok
$Buttenok.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})

$listBox2 = New-Object System.Windows.Forms.Listbox
$listBox2.Location = New-Object System.Drawing.Point(10,90)
$listBox2.Size = New-Object System.Drawing.Size(120,20)
$listBox2.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$listBox2.Height = 495
$listBox2.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer de datum van het logbestand die u wilt zien." )
})

# bij aanklikken van een datum, inhoud weergeven in venster ernaast
$listbox2.add_SelectedIndexChanged( {
    $objtekst1.Text = ""
    # datum omzetten naar bestandsnaam
    $gekozendatum = bepaallognaam $ListBox2.SelectedItem
    # inhoud bestand inlezen
    $volledigetext = Get-Content -Path "$gekozendatum"
    # dan netjes in rijen plaatsen.
    foreach ($item in $volledigetext) {
               $objtekst1.Text = $objtekst1.Text + "$item" + "`r`n"
               }
    } )

# inhoud van logmap weergeven met listbox2
Inlezenlogs | Sort-Object -Descending | ForEach-Object {
    $datumlog = bepaaldatumuitlognaam "$_"
    [void] $listbox2.Items.Add($datumlog)
    }

$objtekst1 = New-Object System.Windows.Forms.textbox
$objtekst1.Location = New-Object System.Drawing.Size(150,90) 
$objtekst1.Size = New-Object System.Drawing.Size(880,484)
$objtekst1.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$objtekst1.Text = ""
$objtekst1.ReadOnly = $true
$objtekst1.Multiline = $true
$objtekst1.ScrollBars = "Both"
$objtekst1.BackColor  = 'white'
$objtekst1.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Inhoud van het geselecteerde logbestand." )
})

# venster met uitleg over deze taak wordt gedeclareerd. hieronder worden enkele variabelen aangepast aan deze taakvenster
declareren_uitlegvenster "Uitleg over het venster Logbestanden bekijken." 680 180 500 590 "Als u links de datum van het logbestand dat je wilt bekijken selecteert, dan wordt rechts 
de inhoud weergegeven.

U kunt om sneller een logbestand te vinden, bovenaan filteren op jaar en maand.
Door om de knop Filters wissen te klikken ziet u weer alle logbestanden." 

$Form2.Controls.AddRange(@($Description2, $Description3, $Description4, $Description5, $filterjaar, $filtermaand, $filterwissen, $listbox2, $objtekst1, $Buttenok, $Global:vraagtekenicoon ))

# eerste logbestand is geselecteerd.
$listBox2.SelectedIndex = 0

Add-EscapeClose -Form $form2

$null = $form2.ShowDialog()

# De hoofdmenu zichtbaar maken
$form.show()
} # einde vensterlogbestand

function controleerupdate {

    param (
        [string]$tedownloadenbestand,
        [string]$updateto
    )
    # controleren of er een update is. Dit gebeurt door de website te controleren op de laatste versie en deze te vergelijken met de huidige versie.
    # Er wordt alleen parameters doorgegeven die nodig zijn voor deze controle. 

Function vergelijk_versies ($huidigeversie, $updateversie) {
    # Haal eventuele +rc.x of -rc.x suffixen eruit en bewaar ze
    $huidigeMain = $huidigeversie -replace '\.rc\.\d+$', ''
    $updateMain = $updateversie -replace '\.rc\.\d+$', ''

    # Haal rc-nummer indien aanwezig
    $huidigeRc = $null
    if ($huidigeversie -match '\.rc\.(\d+)$') { $huidigeRc = [int]$Matches[1] }
    $updateRc = $null
    if ($updateversie -match '\.rc\.(\d+)$') { $updateRc = [int]$Matches[1] }

    # Split de hoofdversies in onderdelen
    $huidigeDeel = $huidigeMain -split '\.'
    $updateDeel = $updateMain -split '\.'

    for ($i = 0; $i -lt [Math]::Max($huidigeDeel.Length, $updateDeel.Length); $i++) {
        $huidigeNummer = if ($i -lt $huidigeDeel.Length) { [int]$huidigeDeel[$i] } else { 0 }
        $updateNummer = if ($i -lt $updateDeel.Length) { [int]$updateDeel[$i] } else { 0 }

        if ($huidigeNummer -lt $updateNummer) {
            return -1  # Huidige versie is lager
        } elseif ($huidigeNummer -gt $updateNummer) {
            return 1   # Huidige versie is hoger
        }
    }

    # Vergelijk RC's indien hoofdversies gelijk zijn
    if ($null -ne $huidigeRc -and $null -ne $updateRc) {
        if ($huidigeRc -lt $updateRc) { return -1 }
        elseif ($huidigeRc -gt $updateRc) { return 1 }
        else { return 0 }
    } elseif ($null -ne $huidigeRc -and $null -eq $updateRc) {
        # Release Candidate is altijd lager dan een definitieve release
        return -1
    } elseif ($null -eq $huidigeRc -and $null -ne $updateRc) {
        return 1
    }

    return 0  # Versies zijn gelijk
} # einde vergelijk_versies

# Hier begint function controleerupdate **************************************

# standaard tekst voor foutmelding bij deze functie. Deze wordt aangevuld met de specifieke foutmelding.
$foutmeldingbegin = "Controle op updates is gestart : `n"
# huidige versie van het programma
$huidigeversie = $global:programma.versie
# bepalen programma naam tbv doorzoeken website naar laatste versie
$programmanaam = $global:programma.naam
# Standaard waarde. Als er geen update is gevonden, dan blijft deze waarde 0.0.0. 
# Let op, dit betekent dat er een probleem is met de update.
$updateto = "0.0.0" 

# dit is de url van de github repository. Hier wordt bepaald of de release of release candidate wordt gedownload.
$url = $global:programma.github 
if ($global:programma.mode -eq "release") {
        $url = -join ($url,"release")
        } elseif ($global:programma.mode -eq "rc") {
        $url = -join ($url,"prerelease")
        } else {
        $url = -join ($url,"test")
        }

# inhoud van de map in github ophalen
try {
        $response = Invoke-RestMethod -Uri $url -Headers @{ "User-Agent" = "PowerShell" }
    } 
catch {
        $melding = -join ($foutmeldingbegin, "Het is niet gelukt om verbinding te maken met de website!
Neem contact op met de eigenaar van $url"  ) 
        $fout = $true
        return [PSCustomObject]@{
        tedownloadenbestand = ""
        updateto = ""
        fout = $fout
        melding = $melding
        }
    }
       
# Loop door de items in de response en controleer of er een nieuw update is
foreach ($item in $response) {
        # alleen bestanden controleren
        if ($item.type -eq "file") {
            # bestnaam is de naam van het te controleren bestand
            $bestnaam = $($item.name) 

            # controleer of het bestand de juiste format heeft.
            if ($bestnaam -match "$programmanaam") {
                # conroleer of het bestand de juiste versieformat heeft.
                if (( $bestnaam -match "_\d+\.\d+\.\d+\.zip$") -or ( $bestnaam -match "_\d+\.\d+\.\d+\.rc\.\d+\.zip$") ){

                    # bepaal laatste versie van het script
                    # versiemetzip is de versie met .zip in de naam.
                    $versiemetzip = $bestnaam.split('_')[1]
                    # de positie van de laatste punt in de versie bepalen
                    $positiepunt = $versiemetzip.LastIndexOf(".")
                    # updateto is alleen de versie zonder .zip. Dit is de versie die we willen vergelijken met de huidige versie.
                    $updateto = $versiemetzip.Substring(0, $positiepunt) 
                    # tedownloadebestand is de naam van het bestand dat gedownload moet worden
                    $tedownloadenbestand = $item.download_url

                    break # we zoeken maar 1 bestand, dus na de eerste gevonden versie stoppen met zoeken
                } # einde controle bestnaam met versieformat
            } # einde controle bestnaam met programmanaam                     
        } # einde if item.type = file
    } # einde foreach loop

# Als er geen update is gevonden, melding geven en loggen
if ($updateto -eq "0.0.0") {
        # Write-Host "" -f Red
        $fout = $true
        $melding = -join ($foutmeldingbegin, "Er is geen update gevonden in de GitHub repository: $url
Neem contact op met de eigenaar van $url"  ) 
        # het volgende is niet nodig want de return wordt gedaan na de else...
        return [PSCustomObject]@{
        tedownloadenbestand = ""
        updateto = ""
        fout = $fout
        melding = $melding
        }
    } else {
    $fout = $false
    # vergelijken van de huidige versie met de update versie
    $resultaat = vergelijk_versies $huidigeversie $updateto
    if ($resultaat -eq 0) {
        # Huidige versie is gelijk aan de update versie
        $melding = "Huidige versie is gelijk aan de update versie."
        $updateto = "gelijk"
        } elseif ($resultaat -gt 0) {
        # Huidige versie is hoger dan de update versie
         $melding = "Huidige versie is hoger dan de update versie." 
         $updateto = "hoger"
        }
    } # einde if $updateto -eq "0.0.0" .. else ..

return [PSCustomObject]@{
        tedownloadenbestand = $tedownloadenbestand
        updateto = $updateto
        fout = $fout
        melding = $melding
    }

} # einde controleerupdate

function updateuitvoeren {

# bepalen programma naam tbv controle hieronder en doorzoeken website naar laatste versie
$programmanaam = $global:programma.naam

# Eerste regel van elke foutmelding
$foutmeldingbegin = "Uitvoeren van een update :
"

# Standaard waarde. Als er geen update is gevonden, dan blijft deze waarde 0.0.0. 
# Let op, dit betekent dat er een probleem is met de update.
$updateto = "0.0.0" 

# controleren of ingesteld is om handmatig een update te forceren.
$forceerupdate = $Global:init.uitvoerennaopstarten.handmatigupdate

# zip-bestand met update op lokale pc
$zip_download = -join ("$startmap","\","updatebestand.zip")

if (Test-Path -path $zip_download -pathtype leaf) {
        write-host "Er is net een update uitgevoerd. Het gedownloade bestand wordt verwijderd."
        Remove-Item $zip_download -Recurse -Force
        # alleen verder gaan als er is ingesteld is om handmatig een update te forceren. 
        if ($forceerupdate -eq "Nee") { return }
    }

if ($forceerupdate -eq "Nee") {
    # Als de update niet handmatig is ingesteld dan pas controleren op de andere voorwaarden. Dit om zeker van te zijn dat een update wordt uitgevoerd.
    # alleen starten als programma.mode niet de status alpha of beta heeft.
    if ("alpha","beta" -contains($global:programma.mode)) {
    return
    }

    # alleen starten als je dit bij instelling hebt staan. Dit is om te voorkomen dat er onbedoeld een update wordt uitgevoerd.
    if ($global:init["uitvoerennaopstarten"]["Controleopupdate"] -ne "Ja") {
    Write-Host "Controle op updates is uitgeschakeld. Er wordt geen update uitgevoerd." -ForegroundColor Yellow
    return
    }
}  # einde if $forceerupdate -eq "Nee" 

# controleren of het script al is opgestart. Als dit zo is kan het mis gaan bij het updaten.
if ($PSVersionTable.PSVersion.Major -ge 6) {
    $programmanaamprocess = "pwsh.exe"
    } else {
    $programmanaamprocess = "powershell.exe"
    }

try {
    $gevonden = Get-CimInstance Win32_Process -Filter "Name='$programmanaamprocess' AND CommandLine like '%$programmanaam%'" -ErrorAction Stop
    }
catch {
        # melding loggen
        $melding = -join ($foutmeldingbegin, $_.exception.message )
        Meldingnaarlogbestand -meldtekst $melding
        $melding2 = -join ($foutmeldingbegin, "Fout tijdens de controle of het programma al is gestart. Zie logbestand voor details." )
        Write-Host $melding2 -ForegroundColor Yellow
        return
}
 
 if ($gevonden) { 
     # er moet altijd een proces gevonden worden omdat dit programma in ieder geval draait. Probleem is er als er meerdere processen draaien.
    if ($gevonden.processid.count -gt 1) { 
        $melding = -join ($foutmeldingbegin, "Het updateproces is niet uitgevoerd omdat een andere proces van het programma al is opgestart." )
        Write-Host $melding -ForegroundColor Yellow
        # Melding ook loggen
        Meldingnaarlogbestand -meldtekst $melding -type "MEDEDELING"
        Start-Sleep -Seconds 3
        return
    } 
 }

# Info geven
write-host "Controleren op een update."

# function controleerupdate uitvoeren en resultaat in variabele plaatsen
$resultaatcontrole = controleerupdate 
if ($resultaatcontrole.fout) {
    # er is een fout opgetreden bij het controleren op een update. De foutmelding wordt hier gelogd en weergegeven.
    Meldingnaarlogbestand -meldtekst $resultaatcontrole.melding
    write-host $resultaatcontrole.melding -f Red
    Start-Sleep -Seconds 8
    return
} elseif (($resultaatcontrole.updateto -eq "gelijk") -or ($resultaatcontrole.updateto -eq "hoger")) {
    # er is geen update nodig, omdat de huidige versie gelijk is aan de update versie. Melding loggen en weergeven.
    write-host $resultaatcontrole.melding 
    $melding = -join ("Controle op een update:","`r`n",$resultaatcontrole.melding )
    Meldingnaarlogbestand -meldtekst $melding -type "MEDEDELING"
    #Start-Sleep -Seconds 3
    return
} 

# waarden uit resultaatcontrole halen omdat er een update is gevonden.
$tedownloadenbestand = $resultaatcontrole.tedownloadenbestand
$updateto = $resultaatcontrole.updateto

# Hier aangekomen dan is er een update beschikbaar.
write-host "`nProgramma wordt geupdatet naar versie $updateto " -f Green

# downloaden zip_download van Github en foutmeldingen opvangen
$error.clear()
try {
    Invoke-WebRequest -Uri $tedownloadenbestand -OutFile $zip_download -ErrorAction Stop
    }

catch {
    # foutmelding weergeven, loggen en stoppen
    $melding = -join ($foutmeldingbegin, "Het updaten is niet gelukt omdat het updatebestand niet is gevonden op de website. 
Neem contact op met de eigenaar van $url" )
    Meldingnaarlogbestand -meldtekst $melding
    write-host $melding -f Red
    Start-Sleep -Seconds 8
    return
    }

# backup maken van hele map voor het geval het mis gaat bij het uitpakken
# eerst de backupbestand een naam geven
$backupzip = "$startmap\backup.zip"
# als deze al bestaat, verwijderen...
if (test-path -path "$backupzip" -PathType Leaf) { Remove-Item "$backupzip" }
# Dan backup maken....
try {
    Write-Host "Er wordt een veiligheidsbackup gemaakt."
    Compress-Archive -Path "$startmap\*" -DestinationPath $backupzip -ErrorAction Stop
}
catch {
    # foutmelding weergeven en stoppen
    $melding = -join ($foutmeldingbegin, "Het updaten is niet gelukt omdat er geen veiligheidsback-up gemaakt kon worden. 
Neem contact op met de eigenaar van $url")
    Meldingnaarlogbestand -meldtekst $melding
    write-host $melding -f Red
    Start-Sleep -Seconds 8
    return
    }

# uitpakken en installeren van programma
$error.clear()
try {
    Expand-Archive -Path "$zip_download" -DestinationPath "$startmap" -Force -ErrorAction Stop
}
catch {
    # foutmelding weergeven en stoppen
    
    $melding = -join ($foutmeldingbegin, "Het updaten is niet gelukt omdat er iets fout ging bij het uitpakken van de nieuwe bestanden. 
Neem contact op met de eigenaar van $url" )
    Meldingnaarlogbestand -meldtekst $melding
    write-host $melding -f Red
    Start-Sleep -Seconds 8
    
    # Terugzetten van backup 
    Expand-Archive -Path "$backupzip" -DestinationPath "$startmap" -Force

    # zipbestand en backup na het uitpakken verwijderen
    Remove-Item "$zip_download"
    if (test-path -path "$backupzip") { Remove-Item "$backupzip" }

    return
    }

# de backup na het uitpakken verwijderen. de zipbestand niet omdat bij het starten dan gezien kan worden dat al een update is uitgevoerd.
# Remove-Item "$zip_download"
if (test-path -path "$backupzip") { Remove-Item "$backupzip" }

Write-Host -f Yellow "Het programma heeft een update uitgevoerd en heeft nu de versie $updateto.
Het programma wordt opnieuw opgestart  ..."

Meldingnaarlogbestand -meldtekst "Het programma heeft een update uitgevoerd en heeft nu de versie $updateto." -type "MEDEDELING"

Start-Sleep -Seconds 5

# Zorgen dat na de update de update informatie wordt weergegeven in het hoofdvenster. Hiervoor wordt een waarde in het init bestand aangepast. 
# Deze waarde wordt bij het opstarten van het programma gelezen en zorgt ervoor dat de update informatie wordt weergegeven. 
$Global:init.uitvoerennaopstarten.updateinfo='Ja'

# zorgen dat na de update niet nog een keer geforceerd een update wordt uitgevoerd. Hiervoor wordt een waarde in het init bestand aangepast.
$global:init.uitvoerennaopstarten.handmatigupdate = "Nee"

Bewareninstellingen
# $gebruikersbestand = bepaalinitnaamgebruiker
# $global:init | ConvertTo-Json -depth 1 | Set-Content -Path $gebruikersbestand

# opnieuw opstarten script met een andere procesnummer (sessie). De oude kan worden afgesloten.
$pwsh7_locatie = (Get-Command pwsh).Source
Start-Pwsh7 $pwsh7_locatie

# beëindigen van huidige proces. programma gaat verder in het nieuwe proces dat met start-process is gestart.
exit;


} # einde updateuitvoeren

function vensterinstellingen {

# De hoofdmenu onzichtbaar maken
$form.Hide()

# venster declareren
$Form2 = declareren_standaardvenster "Instellingen wijzigen" 1000 550

$keuzeoptie1                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie1.width               = 80
$keuzeoptie1.autosize            = $true
$keuzeoptie1.DropDownStyle       = "DropDownList"
$keuzeoptie1.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie1.location = "450,55" 

# locaties toevoegen aan lijst
$teller=0
$keuzelocatie=$global:init["algemeen"]["locatiekeuze"]
foreach( $property in $global:beheer.locaties.keys ) {
    # locatiecode toevoegen
    [void] $keuzeoptie1.Items.Add("$property")

    # standaard keuzelocatie selecteren en in index van lijst zetten
    if ($property -eq "$keuzelocatie") { $keuzeoptie1.Selectedindex = $teller }
    $teller++
    } 
  

$keuzeoptie2                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie2.width               = 80
$keuzeoptie2.autosize            = $true
$keuzeoptie2.DropDownStyle       = "DropDownList"
$keuzeoptie2.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie2.location = "450,135" 
[void] $keuzeoptie2.Items.Add("Ja")
[void] $keuzeoptie2.Items.Add("Nee")
if ($global:init["algemeen"]["wissennabackup"] -eq "Ja") {
    $keuzeoptie2.Selectedindex = 0
    } else {
    $keuzeoptie2.Selectedindex = 1
    }

$keuzeoptie3                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie3.width               = 80
$keuzeoptie3.autosize            = $true
$keuzeoptie3.DropDownStyle       = "DropDownList"
$keuzeoptie3.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie3.location = "450,215" 
[void] $keuzeoptie3.Items.Add("Ja")
[void] $keuzeoptie3.Items.Add("Nee")
if ($global:init["algemeen"]["voortgangweergeven"] -eq "Ja") {
    $keuzeoptie3.Selectedindex = 0
    } else {
    $keuzeoptie3.Selectedindex = 1
    }

$keuzeoptie4                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie4.width               = 80
$keuzeoptie4.autosize            = $true
$keuzeoptie4.DropDownStyle       = "DropDownList"
$keuzeoptie4.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie4.location = "450,255" 
[void] $keuzeoptie4.Items.Add("Ja")
[void] $keuzeoptie4.Items.Add("Nee")
if ($global:init["opschonen"]["opschonenlogs"] -eq "Ja") {
    $keuzeoptie4.Selectedindex = 0
    } else {
    $keuzeoptie4.Selectedindex = 1
    }

$keuzeoptie5 = New-Object System.Windows.Forms.TextBox 
$keuzeoptie5.Location = New-Object System.Drawing.Size(450,295) 
$keuzeoptie5.Size = New-Object System.Drawing.Size(80,60)
$keuzeoptie5.MaxLength = 4
$keuzeoptie5.Font = 'Microsoft Sans Serif,11'
$keuzeoptie5.Text=$Global:init["opschonen"]["dagenbewarenlogs"]
$keuzeoptie5.Add_TextChanged({
    $this.Text = $this.Text -replace '\D'
})

$keuzeoptie6                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie6.width               = 170
$keuzeoptie6.autosize            = $true
$keuzeoptie6.DropDownStyle       = "DropDownList"
$keuzeoptie6.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie6.location = "770,55" 

[int]$teller = 0
$global:afbeeldingen.ForEach( {
    [void] $keuzeoptie6.Items.Add($_.naam)
    if ($_.naam -eq $global:init["algemeen"]["afbeelding"]) {$keuzeoptie6.Selectedindex = $teller}
    $teller+=1

})

$keuzeoptie6.add_SelectedIndexChanged({
# een match zoeken met de gekozen afbeelding in je persoonlijke instellingen
$global:afbeeldingen.ForEach( {
    if ($_.naam -eq $keuzeoptie6.Selecteditem) {
        $keuzeafbeelding = $_.bestand
        $gifbox2.Image    = [System.Drawing.Image]::FromFile("$gifjesmap\$keuzeafbeelding")
        }
})

})

$keuzeoptie7                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie7.width               = 170
$keuzeoptie7.autosize            = $true
$keuzeoptie7.DropDownStyle       = "DropDownList"
$keuzeoptie7.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie7.location = "770,15" 

[int]$teller = 0
$global:moppen.ForEach( {
    [void] $keuzeoptie7.Items.Add($_.naam)
    if ($_.naam -eq $global:init["algemeen"]["websitemoppen"]) {$keuzeoptie7.Selectedindex = $teller}
    $teller+=1
})

$keuzeoptie8 = New-Object System.Windows.Forms.TextBox 
$keuzeoptie8.Location = New-Object System.Drawing.Size(300,15) 
$keuzeoptie8.Size = New-Object System.Drawing.Size(230,60)
$keuzeoptie8.MaxLength = 40
$keuzeoptie8.Font = 'Microsoft Sans Serif,11'
$keuzeoptie8.Text=$Global:init["algemeen"]["gebruiker"]

$keuzeoptie9                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie9.width               = 80
$keuzeoptie9.autosize            = $true
$keuzeoptie9.DropDownStyle       = "DropDownList"
$keuzeoptie9.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie9.location = "450,335" 
[void] $keuzeoptie9.Items.Add("Ja")
[void] $keuzeoptie9.Items.Add("Nee")
if ($global:init["algemeen"]["consolesluiten"] -eq "Ja") {
    $keuzeoptie9.Selectedindex = 0
    } else {
    $keuzeoptie9.Selectedindex = 1
    }

$keuzeoptie10                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie10.width               = 80
$keuzeoptie10.autosize            = $true
$keuzeoptie10.DropDownStyle       = "DropDownList"
$keuzeoptie10.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie10.location = "450,175" 
[void] $keuzeoptie10.Items.Add("Ja")
[void] $keuzeoptie10.Items.Add("Nee")
if ($global:init["algemeen"]["controlevoorklaarzetten"] -eq "Ja") {
    $keuzeoptie10.Selectedindex = 0
    } else {
    $keuzeoptie10.Selectedindex = 1
    }

$keuzeoptie11                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie11.width               = 80
$keuzeoptie11.autosize            = $true
$keuzeoptie11.DropDownStyle       = "DropDownList"
$keuzeoptie11.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie11.location = "450,95" 
[void] $keuzeoptie11.Items.Add("Ja")
[void] $keuzeoptie11.Items.Add("Nee")
if ($global:init["algemeen"]["nieuwelayout"] -eq "Ja") {
    $keuzeoptie11.Selectedindex = 0
    } else {
    $keuzeoptie11.Selectedindex = 1
    }

# Keuze PowerShell 7 start is verwijderd. Dit was keuzeoptie12

$keuzeoptie13                     = New-Object system.Windows.Forms.ComboBox
$keuzeoptie13.width               = 80
$keuzeoptie13.autosize            = $true
$keuzeoptie13.DropDownStyle       = "DropDownList"
$keuzeoptie13.Font                = 'Microsoft Sans Serif,12'
$keuzeoptie13.location = "450,375" 
[void] $keuzeoptie13.Items.Add("Ja")
[void] $keuzeoptie13.Items.Add("Nee")
if ($global:init["uitvoerennaopstarten"]["Controleopupdate"] -eq "Ja") {
    $keuzeoptie13.Selectedindex = 0
    } else {
    $keuzeoptie13.Selectedindex = 1
    }

$Description1                     = New-Object system.Windows.Forms.Label
$Description1.text                = "Standaard locatie"
$Description1.AutoSize            = $false
$Description1.width               = 400
$Description1.height              = 30
$Description1.location            = New-Object System.Drawing.Point(40,60)
$Description1.Font                = 'Microsoft Sans Serif,11'
$Description1.ForeColor = [System.Drawing.Color]::Blue
$Description1.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Met de standaard locatie wordt bepaald van welke locatie de rpc-nummers geselecteerd kunnen worden." )
})

$Description2                     = New-Object system.Windows.Forms.Label
$Description2.text                = "Homemap kandidaten wissen na uitvoeren van een back-up"
$Description2.AutoSize            = $false
$Description2.width               = 410
$Description2.height              = 30
$Description2.location            = New-Object System.Drawing.Point(40,140)
$Description2.Font                = 'Microsoft Sans Serif,11'
$Description2.ForeColor = [System.Drawing.Color]::Blue
$Description2.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bepaal of de optie om homemappen te wissen standaard is geselecteerd bij het uitvoeren van een back-up." )
})

$Description3                     = New-Object system.Windows.Forms.Label
$Description3.text                = "Tijdens het uitvoeren van een taak de voortgang weergegeven in het rechter venster."
$Description3.AutoSize            = $false
$Description3.width               = 400
$Description3.height              = 40
$Description3.location            = New-Object System.Drawing.Point(40,220)
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.ForeColor = [System.Drawing.Color]::Blue
$Description3.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bepaal of tijdens het uitvoeren van een taak de voortgang wordt weergegeven in het rechter venster." )
})

$Description4                     = New-Object system.Windows.Forms.Label
$Description4.text                = "Automatisch verwijderen oude logbestanden bij de start van het programma"
$Description4.AutoSize            = $false
$Description4.width               = 400
$Description4.height              = 40
$Description4.location            = New-Object System.Drawing.Point(40,260)
$Description4.Font                = 'Microsoft Sans Serif,11'
$Description4.ForeColor = [System.Drawing.Color]::Blue
$Description4.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bepaal of bij het opstarten logbestanden verwijderd worden. Hierbij wordt gebruikt gemaakt van de instelling hieronder." )
})

$Description5                     = New-Object system.Windows.Forms.Label
$Description5.text                = "Aantal dagen dat de logbestanden van het programma bewaard blijven"
$Description5.AutoSize            = $false
$Description5.width               = 400
$Description5.height              = 40
$Description5.location            = New-Object System.Drawing.Point(40,300)
$Description5.Font                = 'Microsoft Sans Serif,11'
$Description5.ForeColor = [System.Drawing.Color]::Blue
$Description5.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bepaal tot hoeveel dagen de logbestanden bewaard blijven bij het verwijderen van oude logbestanden." )
})

$Description6                     = New-Object system.Windows.Forms.Label
$Description6.text                = "Afbeelding in het hoofdvenster"
$Description6.AutoSize            = $false
$Description6.width               = 400
$Description6.height              = 40
$Description6.location            = New-Object System.Drawing.Point(560,60)
$Description6.Font                = 'Microsoft Sans Serif,11'
$Description6.ForeColor = [System.Drawing.Color]::Blue
$Description6.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Wijzigen van albeelding in hoofdmenu" )
})


$Description7                     = New-Object system.Windows.Forms.Label
$Description7.text                = "Website met moppen"
$Description7.AutoSize            = $false
$Description7.width               = 400
$Description7.height              = 40
$Description7.location            = New-Object System.Drawing.Point(560,20)
$Description7.Font                = 'Microsoft Sans Serif,11'
$Description7.ForeColor = [System.Drawing.Color]::Blue
$Description7.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bepaal welke website standaard de moppen genereerd." )
})


$Description8                     = New-Object system.Windows.Forms.Label
$Description8.text                = "Jouw naam"
$Description8.AutoSize            = $false
$Description8.width               = 400
$Description8.height              = 40
$Description8.location            = New-Object System.Drawing.Point(40,20)
$Description8.Font                = 'Microsoft Sans Serif,11'
$Description8.ForeColor = [System.Drawing.Color]::Blue
$Description8.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Je naam zoals die wordt weergegeven in het hoofdvenster." )
})

$Description9                     = New-Object system.Windows.Forms.Label
$Description9.text                = "Console, venster met informatie over het script, verbergen als het hoofdvenster wordt getoond."
$Description9.AutoSize            = $false
$Description9.width               = 400
$Description9.height              = 40
$Description9.location            = New-Object System.Drawing.Point(40,340)
$Description9.Font                = 'Microsoft Sans Serif,11'
$Description9.ForeColor = [System.Drawing.Color]::Blue
$Description9.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bepaal of je de console, na het opstartproces, wil sluiten." )
})

$Description10                     = New-Object system.Windows.Forms.Label
$Description10.text                = "Controleer of de homemappen van de kandidaten leeg zijn voordat bestanden worden klaargezet."
$Description10.AutoSize            = $false
$Description10.width               = 400
$Description10.height              = 40
$Description10.location            = New-Object System.Drawing.Point(40,175)
$Description10.Font                = 'Microsoft Sans Serif,11'
$Description10.ForeColor = [System.Drawing.Color]::Blue
$Description10.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bepaal of je de homemappen van de kandidaten wil controleren voordat je bestanden klaarzet." )
})

$Description11                     = New-Object system.Windows.Forms.Label
$Description11.text                = "Toon de nieuwe layout in het hoofdvenster."
$Description11.AutoSize            = $false
$Description11.width               = 400
$Description11.height              = 40
$Description11.location            = New-Object System.Drawing.Point(40,100)
$Description11.Font                = 'Microsoft Sans Serif,11'
$Description11.ForeColor = [System.Drawing.Color]::Blue
$Description11.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bepaal of je het nieuwe layout in het hoofdvenster wil tonen." )
})

$Description13                     = New-Object system.Windows.Forms.Label
$Description13.text                = "Automatisch controleren en installeren van updates bij het opstarten van het programma."
$Description13.AutoSize            = $false
$Description13.width               = 400
$Description13.height              = 40
$Description13.location            = New-Object System.Drawing.Point(40,380)
$Description13.Font                = 'Microsoft Sans Serif,11'
$Description13.ForeColor = [System.Drawing.Color]::Blue
$Description13.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bepaal of je op een update van het programma wil controleren en deze installeren bij het opstarten van het programma. Dit wordt dan automatisch gedaan." )
})

$Btnstandaard = New-object System.Windows.Forms.Button 
$Btnstandaard.text= "Herstel de standaardinstellingen"
$Btnstandaard.location = "430,430" 
$Btnstandaard.size = "250,30"  
$Btnstandaard.BackColor = 'blue'
$Btnstandaard.ForeColor = 'white'
$Btnstandaard.add_click({
    # inlezen ini-bestand naar tijdelijke object
    $temp_init = gebruikersinstellingen

    # alle opties krijgen hun standaard waarde. Er wordt nog niets bewaard!
    $keuzeoptie1.SelectedItem=$temp_init["algemeen"]["locatiekeuze"]
    $keuzeoptie2.SelectedItem=$temp_init["algemeen"]["wissennabackup"]
    $keuzeoptie3.SelectedItem=$temp_init["algemeen"]["voortgangweergeven"]
    $keuzeoptie4.SelectedItem=$temp_init["opschonen"]["opschonenlogs"]
    $keuzeoptie5.Text=$temp_init["opschonen"]["dagenbewarenlogs"]
    $keuzeoptie6.SelectedItem=$temp_init["algemeen"]["afbeelding"]
    $keuzeoptie7.SelectedItem=$temp_init["algemeen"]["websitemoppen"]
    $keuzeoptie9.SelectedItem=$temp_init["algemeen"]["consolesluiten"]
    $keuzeoptie10.SelectedItem=$temp_init["algemeen"]["controlevoorklaarzetten"]
    $keuzeoptie11.SelectedItem=$temp_init["algemeen"]["nieuwelayout"]
    $keuzeoptie13.SelectedItem=$temp_init["uitvoerennaopstarten"]["Controleopupdate"]
}) # einde Btnstandaard.add_click
$Btnstandaard.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Zet alle instellingen terug naar de standaard waarden." )
})

$Btnaccept = New-object System.Windows.Forms.Button 
$Btnaccept.text= "Bewaren"
$Btnaccept.location = "50,430" 
$Btnaccept.size = "150,30"  
$Btnaccept.BackColor = 'green'
$Btnaccept.ForeColor = 'white'
$Btnaccept.DialogResult = [System.Windows.Forms.DialogResult]::yes
$Btnaccept.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Sla de wijzingen op en ga terug naar het hoofdvenster." )
})

$Btnescape = New-object System.Windows.Forms.Button 
$Btnescape.text= "Terug"
$Btnescape.location = "240,430" 
$Btnescape.size = "150,30"  
$Btnescape.BackColor = 'red'
$Btnescape.ForeColor = 'white'
$Btnescape.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$Btnescape.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster zonder de wijzigingen op te slaan." )
})


#Gekozen afbeelding tonen naast de opties
$gifbox2 = New-Object Windows.Forms.picturebox
$gifbox2.AutoSize = $false

# standaard waarde geven voor het geval geen match gevonden is hieronder
$keuzeafbeelding = 'Samenwerken'

# een match zoeken met de gekozen afbeelding in je persoonlijke instellingen
foreach ($afbeelding in $global:afbeeldingen) {
    if ($afbeelding.naam -eq $keuzeoptie6.Selecteditem) {
        $keuzeafbeelding = $afbeelding.bestand
        break
    }
}
$gifbox2.Image    = [System.Drawing.Image]::FromFile("$gifjesmap\$keuzeafbeelding")
$gifbox2.location = New-Object System.Drawing.Point(570,80)
$gifbox2.Size     = "370,320"
$gifbox2.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
$gifbox2.add_click({
    if ($keuzeoptie6.Selectedindex -eq 6) {
        $keuzeoptie6.Selectedindex = 0
        } else {
        $keuzeoptie6.Selectedindex++
        }
})
$gifbox2.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Klik hier voor de volgende afbeelding." )
})


# venster met uitleg over deze taak wordt gedeclareerd. hieronder worden enkele variabelen aangepast aan deze taakvenster
declareren_uitlegvenster "Uitleg over het venster Instellingen." 680 300 950 410 "
Wijzig hier de standaard instellingen van het programma. 
Je kan de voorkeuren die standaard zijn ingesteld bij een taak wijzigen,
enkele beheerinstellingen wijzigen en de layout aanpassen.

U kunt alle instellingen herstellen naar de standaardwaarde door op de knop 
Herstel de standaardinstellingen te klikken.
Als u de instellingen wilt bewaren klikt u op Bewaren.
Als u terug wilt zonder de instellingen te bewaren klikt u op Terug.

U krijgt extra informatie over een instelling als de muiscursor op een tekst staat.
" 

$Form2.Controls.AddRange(@($keuzeoptie8, $keuzeoptie1, $keuzeoptie11, $keuzeoptie2, $keuzeoptie10, $keuzeoptie3, $keuzeoptie4, $keuzeoptie5, $keuzeoptie9, $keuzeoptie7, $keuzeoptie6, $keuzeoptie13,
$description1, $description2, $description3, $description4, $description5, $description6, $description8, $description9, $description10, $description7, $Description11, $Description13, 
$Btnaccept, $Btnescape, $Btnstandaard, $Global:vraagtekenicoon, $gifbox2 ))

Add-EscapeClose -Form $form2

# openen venster
$result = $form2.ShowDialog()

# bewaren van instellingen
if ($result -eq [system.windows.forms.dialogResult]::yes) { 

    # keuzes worden opgehaald en in variabelen gezet. Deze worden vervolgens in het globale init object gezet. Daarna worden deze bewaard in het persoonlijke init bestand van de gebruiker.
    $global:init["algemeen"]["locatiekeuze"]=$keuzeoptie1.Selecteditem
    $global:init["algemeen"]["wissennabackup"]=$keuzeoptie2.Selecteditem
    $global:init["algemeen"]["voortgangweergeven"]=$keuzeoptie3.Selecteditem
    $global:init["opschonen"]["opschonenlogs"]=$keuzeoptie4.Selecteditem
    $global:init["algemeen"]["websitemoppen"]=$keuzeoptie7.Selecteditem
    $global:init["algemeen"]["consolesluiten"]=$keuzeoptie9.Selecteditem
    $global:init["algemeen"]["controlevoorklaarzetten"]=$keuzeoptie10.Selecteditem
    $global:init["algemeen"]["nieuwelayout"]=$keuzeoptie11.Selecteditem
    $global:init["uitvoerennaopstarten"]["Controleopupdate"]=$keuzeoptie13.Selecteditem

    # alle spaties aan begin en eind weghalen
    # $keuzeoptie8.Text.Trim()
    $global:init["algemeen"]["gebruiker"]=$keuzeoptie8.Text.Trim()

    # Ook gelijk weergeven in hoofdvenster
    $Description.text = "Welkom " + $global:init.algemeen.gebruiker
    # Controle of het ingevoerd getal voor "aantal dagen bewaren logs" klopt
    if (!($keuzeoptie5.Text -eq "" )) {
        # eventueel de nullen ervoor weghalen
        [int32]$getal1=$keuzeoptie5.Text
        # alleen als getal1 groter of gelijk is aan 0 is wordt de wijging doorgevoerd
        if ($getal1 -ge 0) { $global:init["opschonen"]["dagenbewarenlogs"]=$getal1 }
    }
    # afbeelding in hoofdmenu wordt aangepast
    $global:init["algemeen"]["afbeelding"]=$keuzeoptie6.Selecteditem
    # een match zoeken met de gekozen afbeelding in je persoonlijke instellingen
    $global:afbeeldingen.ForEach( {
    if ($_.naam -eq $global:init["algemeen"]["afbeelding"]) {
        $keuzeafbeelding = $_.bestand
        $gifBox.Image    = [System.Drawing.Image]::FromFile("$gifjesmap\$keuzeafbeelding")
        }
        })

    # bestand met nieuwe variabele bewaren.
    # Eerst wordt de persoonlijke initialisatiebestand bepaald.
    Bewareninstellingen

    # Nieuwe hoofdvenster tonen of niet
    if ($keuzeoptie11.Selectedindex -eq 0) {
        # nieuwe hoofdvenster tonen
        Nieuwelayoutgebruiken
        subtakenverbergen
        } else {
        # Oude layout gebruiken
        Oudelayoutgebruiken
        # subtakentonen
        }
    # Console open houden of sluiten
    if (($global:programma.mode -eq 'release') -or ($global:programma.mode -eq 'rc')) {
        if ($keuzeoptie9.Selectedindex -eq 0) {
        Toonofverbergconsole 0;
        } else {
        Toonofverbergconsole 5;
        }
    }

} # einde bewaren van instellingen

# De hoofdmenu zichtbaar maken
$form.show()

} # einde vensterinstellingen

function vensteropschonen {

function inlezenmappen {
# inlezen van backupmappen, bepalen aantal te verwijderen mappen en vullen van venster

if ($objTextBox1.Text -eq "") {
    $null = venstermetvraag -titel "Geen getal ingevuld" -vraag "`r`nVul een geldige getal in voor het aantal dagen waarna een back-up wordt verwijderd."
    # $objTextBox1.Text = "0"
    $Btnaccept.Enabled=$false 
    $listBox.items.clear()
    return;
}

# ingevoerde getallen uit de invulbox halen en eventueel de nullen ervoor eruit halen. dit laatste is een controle.
# getal1 is voor de backups
[int32]$getal1=$objTextBox1.Text
$objTextBox1.Text=$getal1.Tostring()

# aantal backups die worden verwijderd tellen
$tellerbackups = 0
# hier wordt er ingelezen, aantal te verwijderen mappen bepaald en venster gevuld.
$listBox.items.clear()

# backupmap krijgt hier een verkorte naam tbv leesbaarheid
$backupmap = $global:beheer.examenmappen.backupmap
# de datum tot waar de mappen worden geselecteerd
$grensdatum = (Get-Date).AddDays(-$getal1)
# het volledige pad naar de map in Sharepoint die ingelezen wordt
$zoekfolder = -join ($global:Sharepoint.team, $backupmap)
# inlezen backupmap en fouten opvangen
try {
    $folders = Get-PnPListItem -List "Documenten" -FolderServerRelativeUrl $zoekfolder -PageSize 1000 -Fields "FileRef","FileLeafRef","Created","FSObjType" | Where-Object {
        ($_.FieldValues["FileRef"].Substring(0, $_.FieldValues["FileRef"].LastIndexOf("/"))) -eq $zoekfolder
    }
    foreach ($folder in $folders) {
        if (
        $folder["FSObjType"] -eq 1 -and
        $folder["Created"] -lt $grensdatum
        ) {
        $tellerbackups++
        [void]$listbox.Items.Add($folder["FileLeafRef"])
        }
    } # einde foreach
}
catch {
  # melding loggen
  $melding = -join ("Inlezen SharePoint map ", $zoekfolder, "`n", $_.exception.message )
  Meldingnaarlogbestand -meldtekst $melding
}

# Knop Bevestigen laten zien als er mappen zijn om te verwijderen
if ($tellerbackups -eq 0 ) { $Btnaccept.Enabled=$false }
      else { $Btnaccept.Enabled=$true }
}
# einde function inlezenmappen


# ------ begin van de function vensteropschonen ---------------------

# controleren of de mappen beschikbaar zijn
if (!( ControleerverbindingSharePoint -controlemap $global:beheer.examenmappen.backupmap )) {
        return
    }

# De hoofdmenu onzichtbaar maken
$form.Hide()

# venster declareren
$Form2 = declareren_standaardvenster "Verwijder gemaakte back-ups van de homemappen van de kandidaten" 650 600

$Description1                     = New-Object system.Windows.Forms.Label
$Description1.text                = "Back-ups van de homemappen die ouder zijn dan"
$Description1.AutoSize            = $false
$Description1.width               = 360
$Description1.height              = 30
$Description1.location            = New-Object System.Drawing.Point(20,15)
$Description1.Font                = 'Microsoft Sans Serif,11'
$Description1.ForeColor = [System.Drawing.Color]::blue


$Description2                     = New-Object system.Windows.Forms.Label
$Description2.text                = "dagen worden verwijderd."
$Description2.AutoSize            = $false
$Description2.width               = 200
$Description2.height              = 30
$Description2.location            = New-Object System.Drawing.Point(440,15)
$Description2.Font                = 'Microsoft Sans Serif,11'
$Description2.ForeColor = [System.Drawing.Color]::blue

$Description3                     = New-Object system.Windows.Forms.Label
$Description3.text                = "Onderstaande mappen worden verwijderd."
$Description3.AutoSize            = $false
$Description3.width               = 800
$Description3.height              = 30
$Description3.location            = New-Object System.Drawing.Point(20,85)
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.ForeColor = [System.Drawing.Color]::Blue

$Description4                     = New-Object system.Windows.Forms.Label
$Description4.text                = "Wijzig eventueel het aantal dagen hierboven en klik op Opnieuw inlezen."
$Description4.AutoSize            = $false
$Description4.width               = 800
$Description4.height              = 30
$Description4.location            = New-Object System.Drawing.Point(20,50)
$Description4.Font                = 'Microsoft Sans Serif,11'
$Description4.ForeColor = [System.Drawing.Color]::Blue

$objTextBox1 = New-Object System.Windows.Forms.TextBox 
$objTextBox1.Location = New-Object System.Drawing.Size(380,13) 
$objTextBox1.Size = New-Object System.Drawing.Size(55,50)
$objTextBox1.MaxLength = 4
$objTextBox1.Font = 'Microsoft Sans Serif,11'
$objTextBox1.Text=$Global:beheer.dagenbewarenbackup
$objTextBox1.Add_TextChanged({
    $this.Text = $this.Text -replace '\D'
})
$objTextBox1.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Wijzigen hier eventueel tot hoeveel dagen oud de back-ups bewaard blijven." )
})

$global:listbox = New-Object System.Windows.Forms.Listbox
$global:listbox.Location = New-Object System.Drawing.Point(20,115)
$global:listbox.Size = New-Object System.Drawing.Size(250,20)
$global:listbox.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$global:listbox.Height = 400
$global:listbox.SelectionMode = 0
$global:listbox.HorizontalScrollbar = $true

$Btnaccept = New-object System.Windows.Forms.Button 
$Btnaccept.text= "Bevestigen"
$Btnaccept.location = "50,510" 
$Btnaccept.size = "150,30"  
$Btnaccept.BackColor = 'green'
$Btnaccept.ForeColor = 'white'
$Btnaccept.add_click({ 
    inlezenmappen
    if ($Btnaccept.Enabled) { overzichttaken "opschonen"} 
    })

# alleen klikbaar als aantal gevonden bestanden hoger is dan 0
if ($tellerbackups -eq 0 ) { $Btnaccept.Enabled=$false }
    
$Btnaccept.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bevestig je keuze en ga door naar het overzicht." )
})

$Btnescape = New-object System.Windows.Forms.Button 
$Btnescape.text= "Terug"
$Btnescape.location = "250,510" 
$Btnescape.size = "150,30"
$Btnescape.BackColor = 'red'
$Btnescape.ForeColor = 'white'
$Btnescape.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$Btnescape.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})

$BtInlezen = New-object System.Windows.Forms.Button 
$BtInlezen.text= "Opnieuw inlezen"
$BtInlezen.location = "300,115" 
$BtInlezen.size = "150,30"  
$BtInlezen.BackColor = 'blue'
$BtInlezen.ForeColor = 'white'
$BtInlezen.add_click({ 
    inlezenmappen
    })
# $BtInlezen.Enabled=$false
$BtInlezen.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Opnieuw inlezen van de mappen als het aantal dagen is gewijzigd." )
})

# venster met uitleg over deze taak wordt gedeclareerd.
declareren_uitlegvenster "Uitleg over het venster Verwijder oude back-ups en oude logbestanden." 700 200 450 510 "Hier kunnen oude back-ups van de homemappen van de kandidaten verwijderd worden.

In het venster zie je een overzicht van de mappen die vewijderd worden met de huidige instellingen.
Wijzigen eventueel tot hoeveel dagen oud de bestanden bewaard blijven en klik op Opnieuw inlezen.

Om naar het overzicht te gaan waar u het verwijderen kan starten moet u op Bevestigen klikken." 


$Form2.Controls.AddRange(@( $objTextBox1, $global:listbox, $description1, $description2, $description3, $description4,  $BtInlezen, $Btnaccept, $Btnescape, $Global:vraagtekenicoon ))




Add-EscapeClose -Form $form2

# uitvoeren bij het starten van de form
$Form2.add_Shown({ 
    # eerst inlezen mappen
    inlezenmappen;
})
# openen venster
$null = $form2.ShowDialog()

# De hoofdmenu zichtbaar maken
$form.show()

} # einde vensteropschonen


function informatieprogramma {

# De hoofdmenu onzichtbaar maken
$form.Hide()

# Powershell versie
$psversie = $PSVersionTable.PSVersion.ToString()

# venster declareren
$Form2 = declareren_standaardvenster "Informatie over het programma" 960 690
$Form2.ShowInTaskbar = $True
$Form2.KeyPreview = $True

$Description2                     = New-Object system.Windows.Forms.Label
$Description2.text                = "Naam van het programma :
Versie : 
Build :
PowerShell versie :
Installatiemap :
Programmeur :
Afbeeldingen :"

$Description2.AutoSize            = $false
$Description2.width               = 220
$Description2.height              = 120
$Description2.location            = New-Object System.Drawing.Point(20,10)
$Description2.Font                = 'Microsoft Sans Serif,11'
$Description2.ForeColor = [System.Drawing.Color]::Blue

$versie = $global:programma.versie
$extralabel = $global:programma.extralabel
$scriptnaam = $global:programma.naam

$Description3                     = New-Object system.Windows.Forms.Label
$Description3.text                = "$scriptnaam
$versie
$extralabel
$psversie
$startmap
Benvindo Neves
Marco Laluan"

$Description3.AutoSize            = $false
$Description3.width               = 1200
$Description3.height              = 115
$Description3.location            = New-Object System.Drawing.Point(250,10)
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.ForeColor = [System.Drawing.Color]::Blue

$FormTabControl = New-object System.Windows.Forms.TabControl
$FormTabControl.Size = "903,440"
$FormTabControl.Location = "25,135"
$FormTabControl.SizeMode = 'Fixed'
$FormTabControl.BackColor = "white"
$FormTabControl.ItemSize = New-Object System.Drawing.Size(300,40)
$FormTabControl.Font = [System.Drawing.Font]::new("Microsoft Sans Serif", 12)

$Tab1 = New-object System.Windows.Forms.Tabpage
$Tab1.DataBindings.DefaultDataSourceUpdateMode = 0
$Tab1.UseVisualStyleBackColor = $True
$Tab1.Name = "TAB1"
$Tab1.Text = "Changelog"

$Tab2 = New-object System.Windows.Forms.Tabpage
$Tab2.DataBindings.DefaultDataSourceUpdateMode = 0
$Tab2.UseVisualStyleBackColor = $True
$Tab2.Name = "TAB2"
$Tab2.Text = "Readme"

$Tab3 = New-object System.Windows.Forms.Tabpage
$Tab3.DataBindings.DefaultDataSourceUpdateMode = 0
$Tab3.UseVisualStyleBackColor = $True
$Tab3.Name = "TAB3"
$Tab3.Text = "License"


$Buttenok = New-object System.Windows.Forms.Button 
$Buttenok.text= "Terug"
$Buttenok.location = "50,600" 
$Buttenok.size = "150,30"  
$Buttenok.BackColor = 'red'
$Buttenok.ForeColor = 'white'
$Buttenok.DialogResult = [System.Windows.Forms.DialogResult]::ok
$Buttenok.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})


$objtekst1 = New-Object System.Windows.Forms.textbox
$objtekst1.Location = New-Object System.Drawing.Size(1,1) 
$objtekst1.Size = New-Object System.Drawing.Size(892,399)
$objtekst1.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$objtekst1.Text = ""
$objtekst1.ReadOnly = $true
$objtekst1.Multiline = $true
$objtekst1.ScrollBars = "Both"
$objtekst1.BackColor  = 'white'

$objtekst2 = New-Object System.Windows.Forms.textbox
$objtekst2.Location = New-Object System.Drawing.Size(1,1) 
$objtekst2.Size = New-Object System.Drawing.Size(892,399)
$objtekst2.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$objtekst2.Text = ""
$objtekst2.ReadOnly = $true
$objtekst2.Multiline = $true
$objtekst2.ScrollBars = "Both"
$objtekst2.BackColor  = 'white'

$objtekst3 = New-Object System.Windows.Forms.textbox
$objtekst3.Location = New-Object System.Drawing.Size(1,1) 
$objtekst3.Size = New-Object System.Drawing.Size(892,399)
$objtekst3.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$objtekst3.Text = ""
$objtekst3.ReadOnly = $true
$objtekst3.Multiline = $true
$objtekst3.ScrollBars = "Both"
$objtekst3.BackColor  = 'white'

# tijdelijke variabelen benoemen
$tempreadmebestand="$startmap\$readmebestand"
$tempchangelogbestand="$startmap\$changelogbestand"
$templicensebestand="$startmap\$licensebestand"

# inhoud bestand inlezen van het Changelog-document en in het venster plaatsen
# deze manier maakt dat het laden van het bestand en laten zien in het venster sneller gaat
if ((test-path -path $tempchangelogbestand -pathtype leaf)) { 
        $volledigetext = Get-Content -Path "$tempchangelogbestand"
        } else {
        $volledigetext = "Het Changelog-document is niet gedownload en kan dus niet getoont worden."
        }
# dan netjes in rijen plaatsen.
foreach ($item in $volledigetext) {
               $objtekst1.Text = $objtekst1.Text + "$item" + "`r`n"
               }


# inhoud bestand inlezen van het Readme-document en in het venster plaatsen
if ((test-path -path $tempreadmebestand -pathtype leaf)) { 
            $volledigetext = Get-Content -Path "$tempreadmebestand"
            } else {
            $volledigetext = "Het Readme-document is niet gedownload en kan dus niet getoont worden."
            }
    # dan netjes in rijen plaatsen.
    foreach ($item in $volledigetext) {
                $objtekst2.Text = $objtekst2.Text + "$item" + "`r`n"
                }

# inhoud bestand inlezen van het License-document en in het venster plaatsen
if ((test-path -path $templicensebestand -pathtype leaf)) { 
            $volledigetext = Get-Content -Path "$templicensebestand"
            } else {
            $volledigetext = "Het License-document is niet gedownload en kan dus niet getoont worden."
            }
    # dan netjes in rijen plaatsen.
    foreach ($item in $volledigetext) {
                $objtekst3.Text = $objtekst3.Text + "$item" + "`r`n"
                }

# venster met uitleg over deze taak wordt gedeclareerd. 
declareren_uitlegvenster "Uitleg over het venster Informatie over het programma." 680 250 500 600 "Bovenaan ziet u enkele gegevens over dit programma.

Daaronder ziet u drie tabbladen met informatie over het programma.
De README is een bestand die eerst gelezen moet worden, voorafgaand aan compilatie, installatie of eerste gebruik.
De CHANGELOG is een bestand met de wijzigingen per versie.
De LICENSE is een bestand met de licentie waaronder dit programma is uitgebracht.

Door op de rode knop onderaan te klikken gaat u terug naar het hoofdvenster." 

$Form2.Controls.AddRange(@($FormTabControl, $Description2, $Description3, $Buttenok, $objtekst1, $Global:vraagtekenicoon))

$FormTabControl.Controls.Add($Tab1)
$FormTabControl.Controls.Add($Tab2)
$FormTabControl.Controls.Add($Tab3)

$Tab1.Controls.Add($objtekst1)
$Tab2.Controls.Add($objtekst2)
$Tab3.Controls.Add($objtekst3)

Add-EscapeClose -Form $form2

# venster starten
$null = $form2.ShowDialog()


# De hoofdmenu zichtbaar maken
$form.show()
} # einde informatieprogramma

function opschonenlogsbijstart {


# alleen starten als dit is ingesteld in opschonenlogs en programma.mode niet de status alpha heeft.
if (($global:init.opschonen.opschonenlogs -eq "Nee") -or ("alpha" -contains($global:programma.mode)) ) {
    return;
}

# alleen starten als map met logbestanden bestaat
if (!(test-path -path "$logmap")) {
return;
}

# variabelen definiëren -----------------

# tijdelijk logbestand bepalen
$tijdelijkelog = "tijdelijkelog.txt"

# logbestandsnaam definiëren en volledige pad naar bestand invoeren
$logbestand = -join ("$logmap","\",$tijdelijkelog)

# starttijd van loggen naar variabele
$logtijd = bepaaltijd

#foutmelding voor logbestand
$foutmelding_log="[ FOUT ] "

# Eerste regel voor logbestand over het starten van opschonen
$melding_opschonen_begint = "Het opschonen van logbestanden is gestart. "

# Deze variabele bepaalt de "weer te geven logbestanden". Dit is in een function geplaatst om op 1 plek veranderingen door te voeren.
$weertegevenlogs = bepaaleigenlogbestanden

# aantal dagen dat bestanden bewaard blijven uit object halen
[int32]$getal2 = $global:init.opschonen.dagenbewarenlogs

# einde variabelen definiëren ----------------------

<# Controleren of er logbestanden zijn om te verwijderen. 
   Hiervoor worden de eigen logbestanden die kunnen worden verwijderd geteld.
   Met try-catch worden fouten opvangen
#>

$tellerlogs=0
try {
    Get-ChildItem -Path $weertegevenlogs -ErrorAction Stop | Where-Object {(!($_.psiscontainer) -and $_.LastWriteTime -lt (Get-Date).AddDays(-$getal2))} | foreach-object {
        $tellerlogs++
    }
} 

catch {
        # melding loggen en weergeven
        $melding = -join ($melding_opschonen_begint, "`n", $_.exception.message )
        Meldingnaarlogbestand -meldtekst $melding
        Write-Host $melding -ForegroundColor Red
        return;
}

# Stoppen als er niets is om te verwijderen
if ( $tellerlogs -eq 0) {
    return;
}

# start proces verwijderen

Write-Host "Opschonen van $tellerlogs logbestanden."

# in logbestand schrijven
$melding_opschonen_begint | out-file $logbestand -Append
"Starttijd : $logtijd" | out-file $logbestand -Append

# in logbestand info schrijven
"De volgende $tellerlogs logbestanden ouder dan $getal2 dagen verwijderen : " | out-file $logbestand -Append

# bepaal de lijst met mappen die verwijderd worden en opvangen foutmelding met try- catch methode
try {
    Get-ChildItem -Path $weertegevenlogs -ErrorAction Stop | Where-Object {(!($_.psiscontainer) -and $_.LastWriteTime -lt (Get-Date).AddDays(-$getal2))} | foreach-object {
        # bestand om te verwijderen
        $todelete = $_.Name
        # in logbestand schrijven
        " - $todelete " | out-file $logbestand -Append

        #verwijderen map 
        $error.clear()
        Remove-Item "$logmap\$todelete" -force -ErrorAction Stop 
   
    } # einde get-childitem        
} # einde try

catch {
      # foutmelding van PowerShell naar logbestand
      "$foutmelding_log" + $_ | out-file $logbestand -Append
      Write-Host $_ -ForegroundColor Red
} # einde try catch

# in logbestand eindtijd schrijven
# eerst eindtijd naar variabele
# alleen uitvoeren als aantal dagen verwijderen logs > 0. Zo wordt alles verwijderd als je dit als 0 instelt. 
# Nu blijft de laatste log met het opschonen bestaan.
if ( $getal2 -gt 0) {
    $logtijd = bepaaltijd

    "" | out-file $logbestand -Append
    "Eindtijd  : $logtijd" | out-file $logbestand -Append
    " -------------------------------------------------------------------------" | out-file $logbestand -Append
    "" | out-file $logbestand -Append

    # tijdelijke log toevoegen aan eigen logbestand als deze al bestaat, anders bestand hernoemen.
    Logbestandtoevoegen $logbestand

} else {
    # tijdelijke logbestand verwijderen
    Remove-Item -Path $logbestand -Force
}

} # einde opschonenlogsbijstart

function Venstermetgrap {
# Een venster verschijnt met een grap of een leuke weetje

function laadgrap {
# een random grap ophalen en in tekst-variabele plaatsen

try {
    switch ($keuzewebsite.Selecteditem) {
        'Apekool.nl' {
        # toevoegen van -ContentType "application/json; charset=utf-8bom" heeft geen zin.
        $quote = Invoke-RestMethod -Method Get -Uri 'http://api.apekool.nl/services/jokes/getjoke.php' -erroraction Stop
        $tekst = $quote.joke 
        $tekst = [System.Web.HttpUtility]::HtmlDecode($tekst)
        $reload.Enabled = $true
          }
        'Appspot.com' {
        $quote = Invoke-RestMethod -Method Get -Uri 'https://official-joke-api.appspot.com/jokes/random' -erroraction Stop
        $tekst = $quote.setup + "`r`n" + $quote.punchline
        $reload.Enabled = $true
          }
        'Icanhazdadjoke.com' {
        $Header = @{'Accept' = 'application/json' }
        $quote = (Invoke-RestMethod -Method Get -Uri 'https://icanhazdadjoke.com/' -Headers $Header -UseBasicParsing).joke
        $tekst = $quote
        $reload.Enabled = $true
          }
        Default { 
        $tekst = 'Kies een website met moppen bij de keuzelijst hieronder.'
        $reload.Enabled = $false 
        }
    }
    
}
catch {
    $tekst = "Het is niet gelukt een mop te krijgen van de API van " + $keuzewebsite.selecteditem + "`r`n" + "De website geeft de volgende melding: " + "`r`n" + $_.exception.message
    Meldingnaarlogbestand -meldtekst $tekst
    $reload.Enabled = $false  
}

return $tekst
}

#venster aanmaken
$Form2 = declareren_standaardvenster "Moppen" 900 300;

$objtekst1 = New-Object System.Windows.Forms.textbox
$objtekst1.Location = New-Object System.Drawing.Size(20,20) 
$objtekst1.Size = New-Object System.Drawing.Size(850,180)
$objtekst1.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)

$objtekst1.ReadOnly = $true
$objtekst1.Multiline = $true
$objtekst1.TabStop = $false
#$objtekst1.ScrollBars = "Both"
$objtekst1.ScrollBars = 'vertical'
$objtekst1.BackColor  = 'white'
$Form2.Controls.Add($objtekst1);

$Buttenok = New-object System.Windows.Forms.Button 
$Buttenok.text= "Terug"
$Buttenok.location = "50,210" 
$Buttenok.size = "150,30"  
$Buttenok.BackColor = 'red'
$Buttenok.ForeColor = 'white'
$Buttenok.DialogResult = [System.Windows.Forms.DialogResult]::ok
$Buttenok.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})
$Form2.Controls.Add($Buttenok);

$reload = New-object System.Windows.Forms.Button 
$reload.text= "Nog een grap"
$reload.location = "250,210" 
$reload.size = "150,30"  
$reload.BackColor = 'green'
$reload.ForeColor = 'white'
$reload.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Nog een grap genereren." )
})
$reload.add_click({
    $objtekst1.Text = laadgrap
})
# hier naar toe verplaatst omdat $reload eerst gedefinieerd moet worden.
$objtekst1.Text = laadgrap

$Form2.Controls.Add($reload);

$keuzewebsite                     = New-Object system.Windows.Forms.ComboBox
$keuzewebsite.width               = 360
$keuzewebsite.autosize            = $true
$keuzewebsite.DropDownStyle       = "DropDownList"
$keuzewebsite.Font                = 'Microsoft Sans Serif,12'
$keuzewebsite.location = "500,210" 

[int]$teller = 0
$global:moppen.ForEach( {
    [void] $keuzewebsite.Items.Add($_.naam)
    # adhv ingestelde keuze bij instellingen bepaal je de geselecteerde item
    if ($_.naam -eq $global:init["algemeen"]["websitemoppen"]) {$keuzewebsite.Selectedindex = $teller}
    $teller+=1

})

$keuzewebsite.add_SelectedIndexChanged({
    $objtekst1.Text = laadgrap
})

# $reload en $keuzewebsite moeten eerst gedefinieerd moeten worden.
# dit is nodig zodat als er geen mop geladen kan worden, de knop reload uitgeschakeld is.
$objtekst1.Text = laadgrap

$Form2.Controls.Add($keuzewebsite);

# venster met uitleg over deze taak wordt gedeclareerd.
declareren_uitlegvenster "Uitleg over het venster Moppen." 700 200 450 210 "Hier wordt een mop gegenereerd en weergegeven.
Rechtsonder staat de website waaruit de mop is gehaald.
Klik hierop om een andere website te kiezen.
Met de knop Nog een grap kan je een nieuwe mop genereren.
De knop Terug brengt je terug naar het hoofdvenster." 

$Form2.controls.add($Global:vraagtekenicoon)
Add-EscapeClose -Form $form2

# venster starten
$null = $form2.ShowDialog()

} # einde functie Venstermetgrap

function vensterverkenner {

Function Selecteermap {
# Selecteert de huidige gekozen map of submap.

    $selectie = $global:beheer.examenmappen.homemapstudenten
    $selectie = -join ($selectie,'\',$listBox.SelectedItem)

# eventuele geselecteerde submappen toevoegen
    foreach ($item in $geselecteerdebronmap) {
                $selectie = -join ($selectie, '\', $item)
    }
    return $selectie
}

Function geselecteerdebronmaplegen {

$mijndocumentenmap = 'Mijn Documenten'

$geselecteerdebronmap.Clear()
$geselecteerdebronmap.Add($mijndocumentenmap)
}

function Venstervullen ($pad) {

    $listView1.BeginUpdate()
    $listView1.Items.Clear()

    try {
        $items = Get-ChildItem -Path $pad -ErrorAction Stop | Sort-Object Name

        foreach ($item in $items) {

            # 📁 MAP
            if ($item.PSIsContainer) {
                $lvItem = $listView1.Items.Add($item.Name, 0)
                $lvItem.SubItems.Add($item.LastWriteTime.ToString()) | Out-Null
                $lvItem.SubItems.Add("") | Out-Null
            }

            # 📄 BESTAND
            else {

                $extensienr = Bepaalicoontjenr $pad $item.Name

                if ($item.Length -eq 0) { 
                    $grootte = '0 kB'
                }
                elseif ($item.Length -lt 1024) { 
                    $grootte = '1 kB'
                }
                else {
                    $grootte = "$([math]::Round($item.Length / 1024)) kB"
                }

                $lvItem = $listView1.Items.Add($item.Name, $extensienr)

                $lvItem.SubItems.Add($item.LastWriteTime.ToString()) | Out-Null
                $lvItem.SubItems.Add($grootte) | Out-Null
            }
        }
    }
    catch {
        # melding loggen en weergeven
        $melding = -join ("Venster Verkenner wordt gevuld : ", "`n", $_.exception.message )
        Meldingnaarlogbestand -meldtekst $melding
    }

    $listView1.EndUpdate()
}

Function geselecteerdemap_vullen ($selectie) {

    Venstervullen $selectie

    # aanpassen venster aan inhoud
    $listView1.AutoResizeColumns(1) 

    # Weergeven submappen van homemap kandidaat in bovenste venster (submappenvenster)
    if ( $listBox.selecteditems.count -eq 1) {
        $objtekst2.Text = $listBox.SelectedItem
    } else {
        $objtekst2.Text = ''
    }

    foreach ($item in $geselecteerdebronmap) {
          $objtekst2.Text = -join ($objtekst2.Text, $Scheidingstekst, $Item)
        }
} # einde geselecteerdemap_vullen

function SortListView {
# Bestanden sorteren op de kolom waar je op klikt. Dit wordt bij functie Verkenner gebruikt.
param(
        [System.Windows.Forms.ListView]$sender,
        [int]$column
    )

    if ($script:sortColumn -eq $column) {
        # toggle ↑ ↓
        if ($script:sortOrder -eq [System.Windows.Forms.SortOrder]::Ascending) {
            $script:sortOrder = [System.Windows.Forms.SortOrder]::Descending
        } else {
            $script:sortOrder = [System.Windows.Forms.SortOrder]::Ascending
        }
    }
    else {
        $script:sortColumn = $column
        $script:sortOrder = [System.Windows.Forms.SortOrder]::Ascending
    }

    $sender.ListViewItemSorter = New-Object ListViewItemComparer($column, $script:sortOrder)
    $sender.Sort()
} # einde SortListView

Function Knoppenklikbaar {

# bepalen of knop Wissen klikbaar moet zijn
if ($listbox.selecteditems.count -gt 0) {
        $Btwissen.Enabled= $true
        } else {
        $Btwissen.Enabled= $false
}
# bepalen of knop Verplaatsen zichtbaar moet zijn
# if (($listBox.selecteditems.count -eq 1) -and ($null -ne $doelselectie.selecteditem)) {
if ($listBox.selecteditems.count -eq 1) {
    $Btnverplaatsen.Enabled= $true
    } else {
    $Btnverplaatsen.Enabled= $false
}
} # einde function Knoppenklikbaar

# ----------- Start function VensterVerkenner -------------------------------

# variabelen krijgen hier een verkorte naam tbv leesbaarheid en gebruik in andere functies
$keuzelocatie     = $global:init["algemeen"]["locatiekeuze"]
# lijst met geselecteerde examenmappen
$global:geselecteerdebronmap = [System.Collections.ArrayList]@()

# controleren of de mappen beschikbaar zijn
if (!(Netwerkmapaanwezig -netwerkmap $global:beheer.examenmappen.homemapstudenten )) { return; } 

# rpcnrs declareren met een function
$global:listBox = declareren_rpcnrs;
$global:listBox = lijstrpcnrsaanmaken $keuzelocatie $global:listBox 

# De hoofdmenu onzichtbaar maken
$form.Hide()

$Form2 = declareren_standaardvenster "Bestanden van homemappen van de kandidaten controleren en openen" 900 670;

$Description2                     = New-Object system.Windows.Forms.Label
$Description2.text                = "RPC-nummers"
$Description2.AutoSize            = $false
$Description2.width               = 150
$Description2.height              = 20
$Description2.location            = New-Object System.Drawing.Point(20,15)
$Description2.Font                = 'Microsoft Sans Serif,11'
$Description2.ForeColor = [System.Drawing.Color]::Blue
$Form2.controls.add($Description2)

$Description3                     = New-Object system.Windows.Forms.Label
$Description3.text                = "Locatie"
$Description3.AutoSize            = $false
$Description3.width               = 400
$Description3.height              = 20
$Description3.Font                = 'Microsoft Sans Serif,11'
$Description3.location            = New-Object System.Drawing.Point(210,15)
$Description3.ForeColor = [System.Drawing.Color]::Blue
$Form2.controls.add($Description3)

$Description4                     = New-Object system.Windows.Forms.Label
$Description4.text                = "Dubbelklik op een bestand om deze te openen met het standaardprogramma voor dit type bestand."
$Description4.AutoSize            = $false
$Description4.width               = 680
$Description4.height              = 20
$Description4.Font                = 'Microsoft Sans Serif,11'
$Description4.location            = New-Object System.Drawing.Point(210,535)
$Description4.ForeColor = [System.Drawing.Color]::Green
$Form2.controls.add($Description4)

# listbox is al in het begin gedeclareerd. onderstaande waarden gelden voor deze functie.
$listBox.Location = New-Object System.Drawing.Point(10,40)
$listBox.Size = New-Object System.Drawing.Size(130,500)
$listBox.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$listBox.SelectionMode = 'MultiExtended'
$listBox.BackColor  = 'white'
$listBox.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer de RPC-nummer waarvan je de bestanden wilt zien." )
})
$Form2.controls.add($listBox)

$listBox.add_SelectedIndexChanged( { 

    # Venster inhoud kandidatenmap legen
    $listView1.items.clear()
    # geselecteerde submappen van inhoud kandidatenmap legen
    geselecteerdebronmaplegen
    # geselecteerde doelmap legen
    $doelselectie.selecteditem = $null

    # selecteert de gekozen map of submap
    # alleen als 1 item is geselecteerd 
    $selectie = Selecteermap
    if ( $listBox.selecteditems.count -eq 1) {
          # weergeven inhoud in rechter venster, inhoud geselecteerde map
          geselecteerdemap_vullen $selectie

          }  # einde $listView1.selecteditems.count -eq 1 
    Knoppenklikbaar
     } ) # einde $listBox.add_SelectedIndexChanged

# Standaard lijst met alle locaties maken, met standaardwaarden
$lijstlocaties = declarerenlijstlocaties $keuzelocatie 330 200 40

$Form2.controls.add($lijstlocaties)

# bij wijzigen van selectie lijstlocaties, andere rpc-nummers weergeven
$lijstlocaties.add_SelectedIndexChanged(
     { 
     [string]$waarde = $lijstlocaties.selecteditem
     $keuzelocatie = $waarde.Substring(0,3)
     # nieuwe rpcnrs declareren
     $global:listBox = lijstrpcnrsaanmaken $keuzelocatie $global:listBox 

     # Venster inhoud kandidatenmap legen
     $listView1.items.clear()
     $objtekst2.Clear()
     # geselecteerde submappen van inhoud kandidatenmap legen
     $geselecteerdebronmap.Clear()
     # geselecteerde doelmap legen
     $doelselectie.selecteditem = $null
     Knoppenklikbaar

     } ) 

$BtnOpnieuw                         = New-Object system.Windows.Forms.Button
$BtnOpnieuw.width                   = 40
$BtnOpnieuw.height                  = 40
$BtnOpnieuw.location                = New-Object System.Drawing.Point(150,80)
$BtnOpnieuw.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoontje-home.png")
$BtnOpnieuw.Add_Click({ 
      # alleen als 1 item is geselecteerd 
      if ( $listBox.selecteditems.count -eq 1) {
      # array wordt leeggemaakt en krijgt eventueel de Mijn documentenmap als 1e item
      geselecteerdebronmaplegen

      # selectie krijgt waarde van home-map nu array terug is naar standaard.
      $selectie = Selecteermap

      # vullen van rechter venster
      $listView1.items.clear()
      geselecteerdemap_vullen ($selectie)
      }
})
$BtnOpnieuw.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Terug naar de home-map van de geselecteerde RPC-nummer." )
})
$Form2.controls.add($BtnOpnieuw)

$BtnTerug                         = New-Object system.Windows.Forms.Button
$BtnTerug.width                   = 40
$BtnTerug.height                  = 40
$BtnTerug.location                = New-Object System.Drawing.Point(150,125)
$BtnTerug.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoon-terug.png")
$BtnTerug.Add_Click({ 
      # alleen als 1 item is geselecteerd EN er items zijn in array
      if (( $listBox.selecteditems.count -eq 1) -and ($geselecteerdebronmap.Count -gt 0)) {
        # laatste item in array verwijderen
        $verwijdernr=$geselecteerdebronmap.Count-1
        $geselecteerdebronmap.RemoveAt($verwijdernr)
        
        # selectie krijgt waarde van home-map nu array terug is naar standaard.
        $selectie = Selecteermap

        # vullen van rechter venster
        $listView1.items.clear()
        geselecteerdemap_vullen ($selectie)
      }
 }) # einde BtnTerug.add_click

$BtnTerug.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "één map terug gaan." )
})
$Form2.controls.add($BtnTerug)

# Tekst tussen twee geselecteerde mappen, om deze uit elkaar te houden
$Scheidingstekst = " » "

$objtekst2 = New-Object System.Windows.Forms.textbox
$objtekst2.Location = New-Object System.Drawing.Size(200,80)
$objtekst2.Size = New-Object System.Drawing.Size(660,47)
$objtekst2.font = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$objtekst2.Text = ''

$objtekst2.ReadOnly = $true
$objtekst2.Multiline = $true
$objtekst2.BackColor  = 'white'
$objtekst2.Forecolor  = 'blue'
$objtekst2.WordWrap = $true
$objtekst2.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Hier zie je de huidige geselecteerde map." )
})
$Form2.controls.add($objtekst2)


# afbeeldingen declareren voor venster met inhoud van kandidaat-map
$imageList = Declareericoontjes

# Venster met inhoud van kandidaat-map
$global:listView1 = New-Object System.Windows.Forms.ListView
$listView1.View = 'Details'
$listView1.Height = 400
$listView1.Width = 660
$listView1.Font = New-Object System.Drawing.Font("MS Sans Serif",12)
# zorgen dat selectie zichtbaar blijft.
$listview1.HideSelection = $false
# Alleen 1 item kan geselecteert worden
$listview1.MultiSelect = $false
$listView1.FullRowSelect = $true
# locatie
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 200
$System_Drawing_Point.Y = 125
$listView1.Location = $System_Drawing_Point
# Naam
$listView1.Name = "listView1"
$listView1.Sorting = 'Ascending'
$listView1.Columns.Add('Inhoud geselecteerde RPC-nummer',300)| Out-Null
$listView1.Columns.Add('Gewijzigd op',200)| Out-Null
# $listView1.Columns.Add('Type',400)| Out-Null
$listView1.Columns.Add('Grootte',70)| Out-Null
# kolom 1 en 2 rechts centreren (kolom 1 mss toch niet doen?????)
$listView1.Columns[2].textalign=1
$listView1.Columns[1].textalign=1

$listView1.SmallImageList = $imageList
$listView1.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Hier zie je de inhoud van de geselecteerde RPC-nummer." )
})
$Form2.controls.add($listView1)

# bij dubbelklikken van een map, map selecteren en openen
$listView1.add_doubleClick( {
     # selecteert de gekozen map of submap
     $selectie = Selecteermap
     # toevoegen gekozen item aan selectie
     $selectie = -join ($selectie, '\', $listView1.SelectedItems.text)
      
     # Er moet een item geselecteerd zijn (je kan namelijk ook dubbelklikken op een lege plek) en de item moet een map zijn.
     if ( $listView1.selecteditems.count -eq 1) {
        # als het item een map is, deze openen.
        if ((test-path -path $selectie -pathtype container) -eq $true) {

            # toevoegen aan array
            $geselecteerdebronmap.Add($listView1.SelectedItems.text)
            # Vullen van rechter venster
            $listView1.items.clear()
            geselecteerdemap_vullen $selectie
            } else {
            # eerst bewaren naam van geselecteerde item in variabele, deze naam is nodig als het fout gaat bij de try catch.
            $selectie_naam = $listView1.SelectedItems.text
            # Als het item een bestand is, start-process gebruiken om deze te openen met bijbehorend programma. 
            try {
                # Het programma openen met start-process
                start-process "`"$selectie`""
                }
                catch {
                # melding geven
                $melding = -join ("Het is niet gelukt het bestand $selectie_naam te openen.","`r`n","De volgende foutmelding is gegeven :","`r`n", $_.exception.message )
                $null = venstermetvraag -titel "Bestand kan niet geopend worden" -vraag $melding -schuifbalk
                meldingnaarlogbestand -meldtekst $melding
                }

        } # einde if ((test-path -path $selectie -pathtype container) -eq $true) ... else ...
     } # einde if ( $listView1.selecteditems.count -eq 1)
} ) # einde $listView1.add_doubleClick

# Nodig voor sorteren op kolom bij dubbelklikken op kolomnaam. Anders wordt er niet gesorteerd als je op een kolom klikt.
$script:sortColumn = 0
$script:sortOrder = [System.Windows.Forms.SortOrder]::Ascending

# Sorteren op een kolom die je aanklikt
$listView1.add_ColumnClick( { SortListView -sender $listView1 -column $_.Column } )

$Btnescape = New-object System.Windows.Forms.Button 
$Btnescape.text= "Terug"
$Btnescape.location = "50,570" 
$Btnescape.size = "150,30"  
$Btnescape.BackColor = 'red'
$Btnescape.ForeColor = 'white'
$Btnescape.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$Btnescape.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})
$Form2.controls.add($Btnescape)

$Btwissen = New-object System.Windows.Forms.Button 
$Btwissen.text= "Wissen"
$Btwissen.location = "220,570" 
$Btwissen.size = "150,30"  
$Btwissen.BackColor = 'blue'
$Btwissen.ForeColor = 'white'
$Btwissen.Enabled= $false
# $Btwissen.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$Btwissen.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})
$Form2.controls.add($Btwissen)
    
$Btwissen.Add_Click({ 
    # alleen als minimaal 1 item is geselecteerd in de listbox
    if ($listBox.selecteditems.count -gt 0) {
        # naar overzichttaken gaan met de taak wissen en directe uitvoering
        # overzichttaken -taak "wissen" -directeuitvoering
        overzichttaken -taak "wissen"
        
        # wissen selecties in listbox, objtekst2 en doelselectie zodat je niet per ongeluk nogmaals op start kan klikken met dezelfde keuzes,
        # en dat je na het uitvoeren niet verkeerde inhoud ziet, bv van een map die al gewist is.
        $listBox.selecteditems.clear()
        $objtekst2.Clear()
        $doelselectie.selecteditem = $null
    }
    Knoppenklikbaar
}) # einde Btnverplaatsen.add_click

$Btnverplaatsen = New-object System.Windows.Forms.Button 
$Btnverplaatsen.text= "Verplaatsen naar ->"
$Btnverplaatsen.location = "390,570" 
$Btnverplaatsen.size = "200,30"  
$Btnverplaatsen.BackColor = 'blue'
$Btnverplaatsen.ForeColor = 'white'
$Btnverplaatsen.Enabled= $false
# $Btwissen.DialogResult = [System.Windows.Forms.DialogResult]::cancel
$Btnverplaatsen.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Ga terug naar het hoofdvenster." )
})
$Form2.controls.add($Btnverplaatsen)

$Btnverplaatsen.Add_Click({ 
  # alleen als 1 item is geselecteerd in de listbox
    if (($listBox.selecteditems.count -eq 1) -and ($null -ne $doelselectie.selecteditem)){
       overzichttaken -taak "verplaatsen"
       $listBox.selecteditems.clear()
       $objtekst2.Clear()
       $doelselectie.selecteditem = $null
    }   
    Knoppenklikbaar
}) # einde Btnverplaatsen.add_click

#  de selectie vd de doel rpc-nummer 
$doelselectie                     = New-Object system.Windows.Forms.ComboBox
$doelselectie.width               = 150
$doelselectie.autosize            = $true
$doelselectie.DropDownStyle       = "DropDownList"
$doelselectie.Font                = 'Microsoft Sans Serif,12'
$doelselectie.location = "600,570" 
$doelselectie.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Selecteer het rpc-nummer waar de bestanden naar toe moeten." )
})
$doelselectie = lijstrpcnrsaanmaken $keuzelocatie $doelselectie
$Form2.controls.add($doelselectie)

$doelselectie.add_SelectedIndexChanged({
    # als  bron en doel hetzelfde zijn dan deseleceteren
    if ($doelselectie.selecteditem -eq $listbox.selecteditem) {
        $doelselectie.selecteditem = $null
    }
    Knoppenklikbaar
})

# venster met uitleg over deze taak wordt gedeclareerd. 
declareren_uitlegvenster "Uitleg over het venster Verkenner." 680 320 800 570 "Hier kunt u de bestanden van de homemappen van de kandidaten controleren en openen.

Eventueel kunt u eerst kiezen om de standaardlocatie te wijzigen.
Links kiest u vervolgens het RPC-nummer van de betreffende homemap.
Rechts ziet u dan de mappen en bestanden van de homemap.

U kunt op een map dubbelklikken om de inhoud weer te geven.
U kunt op een bestand dubbelklikken om deze te openen met het standaardprogramma voor dit type bestand.
Met het terug-icoontje gaat u een map terug.
Met het home-icoontje gaat u terug naar het begin.

Door op de rode knop onderaan te klikken gaat u terug naar het hoofdscherm." 
$Form2.controls.add($Global:vraagtekenicoon)

# venster tonen
# $form2.Topmost = $false

Add-EscapeClose -Form $form2

$null = $form2.ShowDialog()

# venster sluiten    
$form2.close();

# De hoofdmenu zichtbaar maken
$form.show()

} # einde functie vensterverkenner

function Start-Pwsh7 {
        param($path)
        # $path wijst naar de locatie van pwsh.exe, deze is nodig om PowerShell 7 te starten.
        # $scriptnaam is de naam van het programma met .ps1 erachter, en het volledige pad naar dit script. 
        $scriptnaam = $global:programma.naam
        $scriptnaam = -join ($startmap, "\", $scriptnaam, ".ps1")

        Write-Host "Programma wordt nu met PowerShell 7 opgestart."
        Start-Sleep -Seconds 2
        Start-Process $path -ArgumentList '-File', "`"$scriptnaam`"" 
        
}


<# ---------------------      Start programma ---------------------------------------------------------------


#>


# Controleren of PowerShell 7 is geïnstalleerd en anders installeren en starten met PowerShell 7.

if ($PSVersionTable.PSVersion.Major -lt 7) {

    write-host "Programma is opgestart met een PowerShell versie die lager is dan 7." -ForegroundColor Yellow

    # eerst controleren of pwsh al ergens anders staat, bijvoorbeeld in de map van Microsoft Store apps.
    $cmd = Get-Command pwsh -ErrorAction SilentlyContinue
    if ($cmd) {
            $pwsh7_locatie = $cmd.Source
    } else {
            $pwsh7_locatie = "$env:LOCALAPPDATA\Microsoft\WindowsApps\pwsh.exe"
    }

    # als pwsh7 al gevonden is, deze starten. Zo niet, dan verder met controleren en installeren.
    if (Test-Path $pwsh7_locatie) {
        try {
            Start-Pwsh7 $pwsh7_locatie
            Exit # Exit hier zodat het programma niet verder gaat in PS5
        }
        catch {
        $melding = -join ("PowerShell 7 is aanwezig maar kan niet gestart worden.","`r`n","De volgende foutmelding is gegeven :","`r`n", $_)
        }

    } else {

    # Controleer winget
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        $melding = "Winget is niet beschikbaar. PowerShell 7 kan niet automatisch worden geïnstalleerd."

    } else {
        Write-Host "PowerShell 7 wordt geïnstalleerd." -ForegroundColor Green

        try {
            # winget install Microsoft.PowerShell --accept-source-agreements --accept-package-agreements --source winget --scope user
            winget install --id Microsoft.PowerShell --exact --source winget --accept-source-agreements --accept-package-agreements 

            # Opnieuw controleren of pwsh al ergens anders staat, bijvoorbeeld in de map van Microsoft Store apps.
            $cmd = Get-Command pwsh -ErrorAction SilentlyContinue
            if ($cmd) {
                $pwsh7_locatie = $cmd.Source
                } else {
                $pwsh7_locatie = "$env:LOCALAPPDATA\Microsoft\WindowsApps\pwsh.exe"
            }

            # als pwsh7 gevonden is, deze starten. Zo niet, dan foutmelding geven dat PowerShell 7 niet is gevonden na installatie.
            if (Test-Path $pwsh7_locatie) {
                Start-Pwsh7 $pwsh7_locatie
                Exit # Exit hier zodat het programma niet verder gaat in PS5
            } else {
                $melding = "PowerShell 7 is niet gevonden na installatie in de map $pwsh7_locatie. Controleer of PowerShell 7 handmatig kan worden gestart."
            }

        }
        catch {
            $melding = -join ("Er is een fout opgetreden bij het installeren van PowerShell 7 met Winget.","`r`n","De volgende foutmelding is gegeven :","`r`n", $_)
        }

    } # einde else van if (-not (get-command winget ....

    } # einde else van if test-path pwsh7_locatie

    $melding = -join ($melding,"`n","Het programma kan niet werken zonder PowerShell 7.0 of hoger.")
    Meldingnaarlogbestand -meldtekst $melding
    write-host $melding -ForegroundColor Red
    write-host "Installeer PowerShell 7.0 (of hoger) handmatig via de Microsoft Store of via de website.`nHet programma wordt afgesloten in 10 seconden." -ForegroundColor Red
    start-sleep -Seconds 10
    Exit # Exit hier zodat het programma niet verder gaat in PS5 

} # einde if ($PSVersionTable.PSVersion.Major -lt 7)

# Bepalen van de persoonlijke initialisatiebestand.
$gebruikersbestand = bepaalinitnaamgebruiker

write-host "Gebruikersinstellingen inlezen."

# inlezen van gebruikers instellingen
Inlezengebruikersinstellingen;

# controleren op een update. 
updateuitvoeren;

# deze waarde wordt alleen op Ja gezet bij venster Instellingen als de gebruiker heeft gekozen om een update uit te voeren. Handmatig dus.
if ($global:init.uitvoerennaopstarten.handmatigupdate -eq "Ja") {
    $global:init.uitvoerennaopstarten.handmatigupdate = "Nee"
    Bewareninstellingen
    Write-host "De handmatige controle op een update is uitgevoerd."
    $null = venstermetvraag -titel "Updatecontrole" -vraag "
De handmatige controle op een update is uitgevoerd. 
Lees de informatie in de console en druk op OK om verder te gaan."
}

# Einde controleren op update

# verbinden met Sharepoint ...........

# Eerst powershell module importeren als deze niet aanwezig is
if (!(Get-Module -name pnp.powershell -ListAvailable)) {
    # zorgen dat modules uit deze repository worden vertrouwd
    Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
    
    write-host "SharePoint module wordt geïnstalleerd."

    Install-Module -Name pnp.powershell -Scope CurrentUser

    # voor de veiligheid dit weer terugzetten!
    Set-PSRepository -Name 'PSGallery' -InstallationPolicy untrusted
    }

# dan verbinden ......
Write-Host "Verbinden met SharePoint. Meld u aan via de default browser." -f Yellow
$null = VerbindmetSharePoint;

#Overige controles en tijdelijke taken uitvoeren
write-host "Controleren of bestanden moeten worden opgeschoond of hersteld."

# verwijderen beheer.ini vanaf versie 4.6.0
if (test-path -path "$startmap\beheer.ini") { Remove-Item "$startmap\beheer.ini" }  
# verwijderen filetransfer.gif vanaf versie 4.6.0
if (test-path -path "$startmap\png\filetransfer.gif") { Remove-Item "$startmap\png\filetransfer.gif" }  
# verwijderen netwerkschijvencontroleren.exe vanaf versie 4.6.1
if (test-path -path "$startmap\netwerkschijvencontroleren.exe") { Remove-Item "$startmap\netwerkschijvencontroleren.exe" }  
# verwijderen 1 map en 2 bestanden vanaf versie 4.6.2
if (test-path -path "$startmap\png\controleren-2.gif") { Remove-Item "$startmap\png\controleren-2.gif" }  
if (test-path -path "$startmap\png\nieuwe map") { Remove-Item "$startmap\png\nieuwe map" -Force -Recurse }
if (test-path -path "$startmap\snelkoppeling_maken.exe") { Remove-Item "$startmap\snelkoppeling_maken.exe" }   
# verwijderen readme.txt en changelog.txt vanaf versie 4.7.1
if (test-path -path "$startmap\readme.txt") { Remove-Item "$startmap\readme.txt" }  
if (test-path -path "$startmap\changelog.txt") { Remove-Item "$startmap\changelog.txt" }  
# verwijderen beheren.ico vanaf versie 4.8.0
if (test-path -path "$startmap\beheren.ico") { Remove-Item "$startmap\beheren.ico" }


# Opnieuw snelkoppeling maken omdat programma alleen met PowerShell 7 kan werken. Eenmalig uitvoeren.
if (($Global:init.uitvoerennaopstarten.PS7snelkoppeling -eq 'Ja') -and ($Global:programma.mode -eq "release")) {

    # Maken van snelkoppeling
    # benodigde variabelen
    $linkbureaublad = [Environment]::GetFolderPath("Desktop")
    $ShortcutPath = "$linkbureaublad\Beheren bestanden.lnk"
    $snelkoppeling_script = "snelkoppeling_maken.ps1"

    # object aanmaken en bewaren. Alleen als er al een snelkoppeling is. 
    if (Test-Path $ShortcutPath) {
        # write-host "Snelkoppeling op bureaublad wordt opnieuw aangemaakt."
        # Dit wordt ook gelogd. 
        Meldingnaarlogbestand -meldtekst "Snelkoppeling op bureaublad is aangemaakt om met PowerShell 7 te starten." -type "MEDEDELING"
        & "$PSScriptRoot\$snelkoppeling_script" -auto
        
        # $lastexitcode bevat de errorcode van de laatst uitgevoerde code, in dit geval van snelkoppeling_maken.ps1
        if ($LASTEXITCODE -ne 0) {
            Meldingnaarlogbestand -meldtekst "Fout opgetreden bij het aanmaken van de snelkoppeling.
Startmap = $startmap
Bureaubladlink = $ShortcutPath" -type "FOUT"
        }
    } # einde if (Test-Path $ShortcutPath) 

    # De volgende keer niet uitvoeren.
    $Global:init.uitvoerennaopstarten.PS7snelkoppeling='Nee'
    Bewareninstellingen
} # einde if ($Global:init.uitvoerennaopstarten.PS7snelkoppeling -eq 'Ja')

# Einde controles en tijdelijke taken uitvoeren


# opschonen logbestanden als dit is ingesteld.
opschonenlogsbijstart;

write-host "Opstarten hoofdvenster."

# Hide Console. Alleen bij mode = release of release candidate
if (( ($global:programma.mode -eq 'release') -or ($global:programma.mode -eq 'rc')) -and ($global:init.algemeen.consolesluiten -eq 'Ja')) { 
    write-host "De console wordt afgesloten..."
    Toonofverbergconsole 0;
    }

# Hoofdvenster declareren --------------------------------------------------------------------

if ($global:programma.mode -eq 'release') {
    $koptekst = "Beheren bestanden versie " + $global:programma.versie
    } else {
    $koptekst = "Beheren bestanden versie " + $global:programma.versie + ". LET OP : Programma heeft de status " + $global:programma.mode
    }

$Form                            = New-Object system.Windows.Forms.Form
$Form.ClientSize                 = New-Object System.Drawing.Point(700,480) #575
$Form.text                       = $koptekst
$Form.TopMost                    = $false
$Form.StartPosition              = 'CenterScreen'
$form.BackColor                  = "white"
$form.MaximizeBox                = $False
$form.Icon                       = [System.Drawing.Icon]::ExtractAssociatedIcon($global:programma.icoon)

$Description                     = New-Object system.Windows.Forms.Label
$Description.text                = "Welkom " + $global:init.algemeen.gebruiker
$Description.AutoSize            = $false
$Description.width               = 500
$Description.height              = 35
$Description.location            = New-Object System.Drawing.Point(164,15)
$Description.Font                = 'Microsoft Sans Serif,12'
$Form.controls.add($Description)


$uitleg1                     = New-Object system.Windows.Forms.Label
$uitleg1.text                = "Bestanden klaarzetten"
$uitleg1.AutoSize            = $false
$uitleg1.width               = 160
$uitleg1.height              = 20
$uitleg1.location            = New-Object System.Drawing.Point(168, 215)
$uitleg1.Font                = 'Microsoft Sans Serif,11'
$uitleg1.ForeColor = [System.Drawing.Color]::Blue
$Form.controls.add($uitleg1)


$uitleg2                     = New-Object system.Windows.Forms.Label
$uitleg2.text                = "Back-up maken"
$uitleg2.AutoSize            = $false
$uitleg2.width               = 160
$uitleg2.height              = 20
$uitleg2.location            = New-Object System.Drawing.Point(402, 215)
$uitleg2.Font                = 'Microsoft Sans Serif,11'
$uitleg2.ForeColor = [System.Drawing.Color]::blue
$Form.controls.add($uitleg2)

$Button1                         = New-Object system.Windows.Forms.Button
$Button1.width                   = 160
$Button1.height                  = 160
$Button1.location                = New-Object System.Drawing.Point(164,50)
$Button1.Font                    = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$Button1.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icon bestanden klaarzetten.png")
$Button1.BackColor = [System.Drawing.Color]::green
$Button1.Add_Click({ vensterkopieren })
$Button1.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bestanden klaarzetten voor de geselecteerde homemappen van de kandidaten" )
})
$Form.controls.add($Button1)

$Button2                         = New-Object system.Windows.Forms.Button
$Button2.width                   = 160
$Button2.height                  = 160
$Button2.location                = New-Object System.Drawing.Point(376,50)
$Button2.Font                    = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$Button2.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icon backup maken.png")
$Button2.BackColor = [System.Drawing.Color]::green
$Button2.Add_Click({ vensterbackup })
$Button2.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Back-up maken van de geselecteerde homemappen van de kandidaten." )
})
$Form.controls.add($Button2)

# Buttons 3 en 4, verplaatsen en wissen, zijn verwijderd!


$Button9                         = New-Object system.Windows.Forms.Button
$Button9.width                   = 60
$Button9.height                  = 60
$Button9.location                = New-Object System.Drawing.Point(398,150)
$Button9.Font                    = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$Button9.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoon-settings.png")
$Button9.visible                 = $false # deze knop is alleen zichtbaar als subtaken worden weergeven
$Button9.Add_Click({ vensterinstellingen })
$Button9.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "De persoonlijke keuzes voor het programma wijzigen." )
})
$Form.controls.add($Button9)

$Button10                         = New-Object system.Windows.Forms.Button
$Button10.width                   = 60
$Button10.height                  = 60
$Button10.location                = New-Object System.Drawing.Point(510,50)
$Button10.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoon-clean.png")
$Button10.visible                = $false # deze knop is alleen zichtbaar als subtaken worden weergeven
$Button10.Add_Click({ vensteropschonen })
$Button10.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Oude back-ups verwijderen." )
})
$Form.controls.add($Button10)

$Button8  = New-Object system.Windows.Forms.Button
$Button8.Location = New-Object System.Drawing.Size(388,150) 
$Button8.Size = New-Object System.Drawing.Size(60,60)
$Button8.Image = [System.Drawing.Image]::FromFile("$icoontjesmap\icoon-updaten.png")
$Button8.visible = $false # deze knop is alleen zichtbaar als $subtaken = $true
$Button8.Add_Click({ 
     # function controleerupdate uitvoeren en resultaat in variabele plaatsen
    $resultaatcontrole = controleerupdate 
    if ($resultaatcontrole.fout) {
        # er is een fout opgetreden bij het controleren op een update. De foutmelding wordt gelogd en weergegeven.
        Meldingnaarlogbestand -meldtekst $resultaatcontrole.melding
        $null = venstermetvraag -titel "Fout tijdens de controle op een update" -vraag "
Er is iets mis gegaan bij het uitvoeren van de controle op een update.
Controleer het logboek voor meer informatie over de foutmelding." -knopok "OK" 
        } elseif (($resultaatcontrole.updateto -eq "gelijk") -or ($resultaatcontrole.updateto -eq "hoger")) {
        $null = venstermetvraag -titel "Geen update gevonden" -vraag "
Er is geen update beschikbaar.
Het programma heeft de laatste versie geïnstalleerd." -knopok "OK" 
        } else {
        $nieuweversie = $resultaatcontrole.updateto
        $result = venstermetvraag -titel "Update installeren?" -vraag "
Een nieuwe versie van het programma is beschikbaar.
Weet je zeker dat je versie $nieuweversie wilt installeren?
Het programma zal opnieuw opgestart worden." -knopok "Ja" -knopterug "Nee"
        if ($result -eq 'OK') {
            # instellen dat het programma gaat updaten na herstart
            $global:init["uitvoerennaopstarten"]["handmatigupdate"] = "Ja"
            Bewareninstellingen
            # huidige proces vh programma afsluiten
            $form.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

            # opnieuw opstarten
            $pwsh7_locatie = (Get-Command pwsh).Source
            Start-Pwsh7 $pwsh7_locatie
            # return
        }
    } # einde if ($resultaatcontrole.fout) ... elseif ..ese .
    
 })
$Button8.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Controleren en updaten van het programma" )
})
 $Form.controls.add($Button8)

$Button7                         = New-Object system.Windows.Forms.Button
$Button7.width                   = 60
$Button7.height                  = 60
$Button7.location                = New-Object System.Drawing.Point(52,50)
$Button7.Font                    = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$Button7.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoon-stoppen.png")
$Button7.Add_Click({ 
    # $result = programmaafsluiten
    $result = venstermetvraag -titel "Stoppen?" -vraag "`r`nWilt u het programma stoppen?" -knopok "Stoppen" -knopterug "Terug"

    if ($result -eq 'OK') {
        # programma sluiten
        $form.DialogResult = [System.Windows.Forms.DialogResult]::cancel
        # return
        } 
    })
$Button7.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Het programma afsluiten." )
})
$Form.controls.add($Button7)

$Button12 = New-Object system.Windows.Forms.Button
$Button12.Location = New-Object System.Drawing.Size(52,150) 
$Button12.Size = New-Object System.Drawing.Size(60,60)
$Button12.Image = [System.Drawing.Image]::FromFile("$icoontjesmap\icoon-opties.png")
$Button12.Add_Click({ 
    # switchen tussen de hoofdvenster en venster met subtaken.
    # uitvoeren via function zodat deze makkelijk weer kan worden gebruikt bij het teruggaan van een subtaken naar het hoofdmenu.
    if ($Button1.visible) {
        subtakentonen
    } else {
        subtakenverbergen
    }
    Start-Sleep -Milliseconds 200

 })
$Button12.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Schakelen tussen de hoofd- en overige taken" )
})
$Form.controls.add($Button12)

$Button11                         = New-Object system.Windows.Forms.Button
$Button11.width                   = 60
$Button11.height                  = 60
$Button11.location                = New-Object System.Drawing.Point(164,50)
$Button11.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoon-bestanden.png")
$Button11.visible                = $false # deze knop is alleen zichtbaar als $subtaken = $true
$Button11.Add_Click({ vensterverkenner })
$Button11.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Bestanden van de homemappen bekijken, openen, verwijderen of verplaatsen." )
})
$Form.controls.add($Button11)

$Button5                         = New-Object system.Windows.Forms.Button
$Button5.width                   = 60
$Button5.height                  = 60
$Button5.location                = New-Object System.Drawing.Point(164,150)
$Button5.Font                    = New-Object System.Drawing.Font('Microsoft Sans Serif',12)
$Button5.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoon-log.png")
$Button5.visible                = $false # deze knop is alleen zichtbaar als $subtaken = $true
$Button5.Add_Click({ vensterlogbestand })
$Button5.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "De logbestanden bekijken." )
})
$Form.controls.add($Button5)

$Button6                         = New-Object system.Windows.Forms.Button
$Button6.width                   = 60
$Button6.height                  = 60
$Button6.location                = New-Object System.Drawing.Point(398,50)
$Button6.Image=[System.Drawing.Image]::FromFile("$icoontjesmap\icoon-info.png")
$Button6.visible                = $false # deze knop is alleen zichtbaar als $subtaken = $true
$Button6.Add_Click({ informatieprogramma })
$Button6.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Algemene informatie over het programma bekijken." )
})
$Form.controls.add($Button6)

# declareren venster met uitleg over programma. verschijnt als de muis over de vraagteken gaat.

$Form_uitlegprog = declareren_standaardvenster "Uitleg over het programma" 690 540
$Form_uitlegprog.ControlBox = $False

# Bij Escape-toets het venster sluiten.
Add-EscapeClose -Form $Form_uitlegprog

$uitlegprogtekst                     = New-Object system.Windows.Forms.Label
$uitlegprogtekst.text                = "Met dit programma kunnen bestanden op meerdere pc's in een netwerk worden beheerd.
De twee belangrijkste taken van dit programma worden met een groene icoontje weergegeven.
Met het groene icoontje 
    - 'Bestanden klaarzetten' worden bestanden en volledige mappen overgezet naar 
       de geselecteerde homemappen van de kandidaten,
    - 'Back-up maken' wordt een back-up gemaakt van de geselecteerde homemappen 
       van de kandidaten.

De overige taken worden met een zwartwit icoontje weergegeven.
Met deze icoontjes kan je de volgende taken uitvoeren :
    - de bestanden in de homemappen van de kandidaten bekijken of openen,
    - de logbestanden van de uitgevoerde taken bekijken,
    - algemene informatie over het programma lezen,
    - het programma afsluiten,
    - de bestanden van een homemap verplaatsten of kopiëren naar een andere homemap,
    - de bestanden van de geselecteerde homemappen wissen,
    - de persoonlijke keuzes voor het programma instellen,    
    - oude back-ups verwijderen.

Als je gekozen hebt voor de nieuwe layout dan zijn de zwartwitte icoontjes niet meer zichtbaar in het
hoofdvenster, maar worden deze zichtbaar als je op het icoontje met de drie streepjes klikt.
Je gaat weer terug naar het hoofdvenster door op het huis-icoontje te klikken.

Informatie over een taak kan verkregen worden door met de muiscursor over een object te gaan.
"
$uitlegprogtekst.AutoSize            = $false
$uitlegprogtekst.width               = 680
$uitlegprogtekst.height              = 430
$uitlegprogtekst.location            = New-Object System.Drawing.Point(10,10)
$uitlegprogtekst.Font                = 'Microsoft Sans Serif,11'
$uitlegprogtekst.ForeColor = [System.Drawing.Color]::blue
$Form_uitlegprog.Controls.Add($uitlegprogtekst)

$knopsluiten = New-object System.Windows.Forms.Button 
$knopsluiten.text= 'Sluiten'
$knopsluiten.location = "250,440" 
$knopsluiten.size = "150,30"  
$knopsluiten.BackColor = 'red'
$knopsluiten.ForeColor = 'white'
$knopsluiten.DialogResult = [System.Windows.Forms.DialogResult]::ok
$Form_uitlegprog.Controls.Add($knopsluiten)

# einde declareren venster met uitleg over programma

# declareren vraag-icoontje om extra informatiete geven over het programma
$picturequestion = new-object Windows.Forms.PictureBox
$picturequestion.Location = New-Object System.Drawing.Size(610,430) 
$picturequestion.Size = New-Object System.Drawing.Size(30,60)
$picturequestion.Image = [System.Drawing.Image]::FromFile("$icoontjesmap\icoon-hulp.png")
$picturequestion.add_click( { $Form_uitlegprog.showdialog() } )
$picturequestion.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Klik hier voor uitleg over het programma." )
})
$Form.controls.add($picturequestion)

#GIF afbeelding toevoegen
$gifBox = New-Object Windows.Forms.picturebox

# standaard waarde geven voor het geval geen match gevonden is hieronder
$keuzeafbeelding = 'samenwerken.gif'
$keuze_xas = 130
$keuze_yas = 230

# een match zoeken met de gekozen afbeelding in je persoonlijke instellingen
$global:afbeeldingen.ForEach( {
    if ($_.naam -eq $global:init["algemeen"]["afbeelding"]) {
        $keuzeafbeelding = $_.bestand
        }
})
$gifBox.Image    = [System.Drawing.Image]::FromFile("$gifjesmap\$keuzeafbeelding")
$gifBox.location = New-Object System.Drawing.Point($keuze_xas,$keuze_yas)
$gifBox.AutoSize = $false
$gifbox.Size     = "440,250" 
$gifbox.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
# $gifbox.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Centerimage

$gifBox.add_click( { Venstermetgrap } )
$gifBox.add_MouseHover({
    $global:tooltip1.SetToolTip($this, "Klik hier voor een leuke grap." )
})

$Form.Controls.Add($gifbox)

# Kiezen tussen de standaard layout of de layout waarbij subtaken worden weergegeven. Standaard is dit laatste.
if ($global:init.algemeen.nieuwelayout -eq 'Ja') {
    # subtakentonen
    Nieuwelayoutgebruiken
    } else {
    Oudelayoutgebruiken
    $Button8.visible = $true
    $Button9.visible = $true
    $Button10.visible = $true
    $Button6.visible = $true
    $Button5.visible = $true
    $Button11.visible = $true
    $Button1.visible = $true
    $Button2.visible = $true
    $uitleg2.visible = $true
    $uitleg1.visible = $true
    }

# Einde hoofdvenster declareren

# Bij het tonen van het hoofdvenster, een aantal controles uitvoeren (Bijvoorbeeld een melding tonen als het programma nog in testfase is)
# En zorgen dat het venster op de voorgrond komt. Dit is nodig omdat het venster anders achter andere vensters kan komen te staan.
$form.add_Shown({ 
    # zorgen dat het venster op de voorgrond komt. Topmost = $true en dan weer terugzetten naar false. Anders blijft het venster altijd op de voorgrond.
    $form.Topmost = $true 
    $form.Activate()
    $form.Focus()
    start-sleep -Milliseconds 100
    $form.Topmost = $false

    # Als het programma in testfase is, dan venster tonen met melding
    $mode=$global:programma.mode
    if ($global:programma.mode -ne 'release') {
        $null = venstermetvraag -titel "Programma is nog in testfase" -vraag "`r`nLET OP : Programma is nog in testfase $mode.`r`nGebruik het programma nu alleen voor testdoeleinden."
    }

    # Als er een update is uitgevoerd of het programma is net geïnstalleerd, dan venster tonen met melding dat er een update is uitgevoerd of dat het programma net is geïnstalleerd.
    # Deze melding wordt alleen 1 keer getoond 
    $versie = $global:programma.versie
    if ($Global:init.uitvoerennaopstarten.updateinfo -eq 'Ja') {
        # Na elke update or bij nieuwe installatie is er een venster met informatie over de update. Deze wordt alleen 1 keer getoond.
        $null = venstermetvraag -titel "Informatie over uitgevoerde update" -vraag "`r`nHet programma heeft een update uitgevoerd en heeft nu versie $versie.`r`n
De belangrijkste wijzigingen zijn: 
- Het probleem van onjuiste programma icoon voor snelkoppeling is opgelost.
- De snelkoppeling kan worden ingesteld om te werken met PowerShell 7.
- Het probleem dat Powershell 7 niet werd geïnstalleerd als je dit bij Instellingen wijzigt is opgelost." -schuifbalk -bredevenster

        # Deze vraag niet meer stellen -> Waarde op nee zetten en bewaren
        $Global:init.uitvoerennaopstarten.updateinfo='Nee'
        Bewareninstellingen

    }
 } )

# Form wordt getoond. Dit is het hoofdvenster. Het programma is opgestart.
$null = $Form.ShowDialog()

# hoofdmenu sluiten
$Form.dispose()


# einde script.